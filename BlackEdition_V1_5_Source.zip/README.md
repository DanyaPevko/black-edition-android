# Black Edition V1.5

Visual refinement based on verified V1.4:
- Replaced emoji playback controls with custom-drawn vector-style icons.
- Previous and next controls use quiet burgundy surfaces and consistent line artwork.
- Play/pause uses a larger ruby gradient control with clean white glyphs.
- Added a subtle press-scale animation.
- Preserved the existing screen layout, weather and lunar display, album art, playback progress, and Yandex Music MediaSession integration.

Version: 1.5 (versionCode 8).
