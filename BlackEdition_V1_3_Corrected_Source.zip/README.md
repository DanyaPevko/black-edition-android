# Black Edition V1.3 (corrected)

- Midnight-blue outer background.
- Burgundy gradient cards.
- Restrained ruby-pink accent instead of orange.
- Lunar phase and approximate illumination in the weather panel.
- Clear-sky icon changes to the Moon at night; rain/snow/fog/storm retain their weather icons.
- Existing MediaSession controls, seek bar and weather proxy retained.

Build with GitHub Actions. Artifact: `black-edition-v1-apk`.
