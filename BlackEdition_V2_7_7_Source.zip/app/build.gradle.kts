plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ru.blackedition.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.blackedition.app"
        minSdk = 23
        targetSdk = 33
        versionCode = 25
        versionName = "2.7.7"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    signingConfigs {
        val releaseStoreFile = System.getenv("KEYSTORE_FILE")
        val releaseStorePassword = System.getenv("KEYSTORE_PASSWORD")
        val releaseKeyAlias = System.getenv("KEY_ALIAS")
        val releaseKeyPassword = System.getenv("KEY_PASSWORD")
        if (!releaseStoreFile.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
            !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
            create("release") {
                storeFile = file(releaseStoreFile)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (signingConfigs.findByName("release") != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }
    kotlinOptions { jvmTarget = "17" }
}


dependencies {
    implementation("com.alphacephei:vosk-android:0.3.75")
    implementation("com.caverock:androidsvg-aar:1.4")
    implementation("androidx.core:core-ktx:1.13.1")
}
