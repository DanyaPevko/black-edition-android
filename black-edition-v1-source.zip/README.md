# Black Edition V1.0

Native Android music-center interface for Samsung Galaxy Tab A SM-T510 / Android 11.

Features:
- Landscape dark dashboard with clock and date.
- Syzran weather from the existing Cloudflare Worker proxy.
- Yandex Music metadata and album artwork via Android MediaSession.
- Play/pause, previous/next and seek bar.
- Screen stays awake while the app is open.

Build: GitHub Actions -> Artifacts -> `black-edition-v1-apk`.

The app requires Notification Listener access to discover active media sessions and Internet access for weather. It does not read notification message text or send media metadata to a server.
