package ru.blackedition.app

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 11, 13)
    private val panel = Color.rgb(22, 24, 28)
    private val orange = Color.rgb(255, 126, 35)
    private val muted = Color.rgb(145, 151, 160)
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var controller: MediaController? = null
    private var durationMs = 0L
    private var currentPosition = 0L
    private var lastPositionAt = 0L
    private var isSeeking = false

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherTemp: TextView
    private lateinit var weatherDesc: TextView
    private lateinit var weatherExtra: TextView
    private lateinit var weatherIcon: TextView
    private lateinit var cover: ImageView
    private lateinit var track: TextView
    private lateinit var artist: TextView
    private lateinit var playbackLabel: TextView
    private lateinit var progress: SeekBar
    private lateinit var elapsed: TextView
    private lateinit var remaining: TextView
    private lateinit var accessHint: TextView
    private lateinit var playPause: Button

    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            updateProgress()
            refreshMedia()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        buildUi()
        updateClock()
        refreshWeather()
        refreshMedia()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    private fun rounded(color: Int, radius: Float = 22f) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            includeFontPadding = false
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 22, 30, 22)
            setBackgroundColor(bg)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("BLACK EDITION", 14f, orange, true))
        brand.addView(text("MUSIC CENTER  /  SYZRAN", 10f, muted, true))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        clock = text("--:--", 34f, Color.WHITE, true)
        date = text("Загрузка даты", 13f, muted)
        clockBox.addView(clock)
        clockBox.addView(date)
        top.addView(clockBox)
        root.addView(top)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 20, 0, 0)
        }

        val weatherCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(22, 20, 22, 20)
            background = rounded(panel)
        }
        weatherCard.addView(text("СЫЗРАНЬ  /  ПОГОДА", 11f, orange, true))
        val weatherRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 12, 0, 4)
        }
        weatherIcon = text("☁", 36f, Color.WHITE)
        weatherRow.addView(weatherIcon)
        weatherTemp = text("--°", 38f, Color.WHITE, true)
        weatherRow.addView(weatherTemp)
        weatherCard.addView(weatherRow)
        weatherDesc = text("Получаем прогноз…", 14f, Color.WHITE, true)
        weatherExtra = text("Влажность --%   ·   Ветер -- м/с", 11f, muted)
        weatherCard.addView(weatherDesc)
        weatherCard.addView(weatherExtra)
        content.addView(weatherCard, LinearLayout.LayoutParams(0, -1, 0.9f))

        val spacer = View(this)
        content.addView(spacer, LinearLayout.LayoutParams(18, 1))
        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(22, 20, 22, 20)
            background = rounded(panel)
        }
        cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(38, 40, 44), 16f)
        }
        playerCard.addView(cover, LinearLayout.LayoutParams(190, 190))
        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 0, 0, 0)
        }
        details.addView(text("NOW PLAYING", 11f, orange, true))
        track = text("Ожидание музыки", 25f, Color.WHITE, true)
        artist = text("Запусти Яндекс Музыку", 16f, muted)
        playbackLabel = text("●  НЕ ПОДКЛЮЧЕНО", 11f, muted, true)
        val spacerTop = View(this)
        details.addView(spacerTop, LinearLayout.LayoutParams(1, 10))
        details.addView(track)
        details.addView(artist)
        details.addView(playbackLabel)
        val progressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 18, 0, 0)
        }
        elapsed = text("00:00", 11f, muted)
        remaining = text("00:00", 11f, muted)
        progress = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(orange)
            thumbTintList = android.content.res.ColorStateList.valueOf(orange)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.DKGRAY)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { isSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser && durationMs > 0) {
                        val pos = durationMs * value / 1000
                        elapsed.text = formatTime(pos)
                    }
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val c = controller
                    if (c != null && durationMs > 0) {
                        c.transportControls.seekTo(durationMs * (seekBar?.progress ?: 0) / 1000)
                    }
                    isSeeking = false
                }
            })
        }
        progressRow.addView(elapsed)
        progressRow.addView(progress, LinearLayout.LayoutParams(0, -2, 1f).apply {
            setMargins(10, 0, 10, 0)
        })
        progressRow.addView(remaining)
        details.addView(progressRow)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 15, 0, 0)
        }
        controls.addView(control("⏮") { command { it.skipToPrevious() } })
        playPause = control("Ⅱ") { togglePlayback() }
        controls.addView(playPause)
        controls.addView(control("⏭") { command { it.skipToNext() } })
        details.addView(controls)
        playerCard.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(playerCard, LinearLayout.LayoutParams(0, -1, 1.5f))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(2, 12, 2, 0)
        }
        accessHint = text("Медиасессия: проверка…", 11f, muted)
        bottom.addView(accessHint, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = Button(this).apply {
            text = "НАСТРОЙКИ"
            textSize = 10f
            setTextColor(muted)
            setBackgroundColor(bg)
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        bottom.addView(settings)
        root.addView(bottom)
        setContentView(root)
    }

    private fun control(symbol: String, action: () -> Unit) = Button(this).apply {
        text = symbol
        textSize = 23f
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(38, 41, 46), 18f)
        minWidth = 72
        minHeight = 58
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(5, 0, 5, 0) }
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale("ru")).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now)
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
    }

    private fun refreshMedia() {
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(this, MediaAccessService::class.java))
            val active = sessions.firstOrNull { it.packageName.contains("yandex", true) }
            controller = active
            if (active == null) {
                track.text = "Ожидание музыки"
                artist.text = "Запусти Яндекс Музыку"
                playbackLabel.text = "●  МЕДИАСЕССИЯ НЕ НАЙДЕНА"
                accessHint.text = "Нет активной медиасессии"
                cover.setImageDrawable(null)
                durationMs = 0
                progress.progress = 0
                playPause.text = "▶"
                return
            }
            val meta = active.metadata
            track.text = meta?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Без названия"
            artist.text = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "Неизвестный исполнитель"
            val bitmap: Bitmap? = meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            if (bitmap != null) cover.setImageBitmap(bitmap)
            val state = active.playbackState
            val playing = state?.state == PlaybackState.STATE_PLAYING
            playbackLabel.text = if (playing) "●  ВОСПРОИЗВОДИТСЯ" else "Ⅱ  ПАУЗА"
            playbackLabel.setTextColor(if (playing) orange else muted)
            playPause.text = if (playing) "Ⅱ" else "▶"
            durationMs = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            currentPosition = state?.position ?: 0L
            lastPositionAt = System.currentTimeMillis()
            accessHint.text = "Яндекс Музыка подключена  ·  ${active.packageName}"
            updateProgress()
        } catch (e: SecurityException) {
            accessHint.text = "Нет доступа к медиасессии. Проверь разрешение."
        } catch (e: Exception) {
            accessHint.text = "Ошибка медиасессии: ${e.javaClass.simpleName}"
        }
    }

    private fun updateProgress() {
        if (durationMs <= 0) {
            elapsed.text = "00:00"
            remaining.text = "00:00"
            return
        }
        val state = controller?.playbackState
        val playing = state?.state == PlaybackState.STATE_PLAYING
        val pos = if (playing) {
            currentPosition + (System.currentTimeMillis() - lastPositionAt)
        } else currentPosition
        val safe = pos.coerceIn(0, durationMs)
        if (!isSeeking) progress.progress = (safe * 1000 / durationMs).toInt()
        elapsed.text = formatTime(safe)
        remaining.text = formatTime(durationMs)
    }

    private fun togglePlayback() {
        val state = controller?.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING) command { it.pause() }
        else command { it.play() }
    }

    private fun command(action: (MediaController.TransportControls) -> Unit) {
        val c = controller
        if (c == null) {
            accessHint.text = "Сначала запусти Яндекс Музыку"
            return
        }
        try {
            action(c.transportControls)
            handler.postDelayed({ refreshMedia() }, 450)
        } catch (e: Exception) {
            accessHint.text = "Команда не выполнена: ${e.javaClass.simpleName}"
        }
    }

    private fun refreshWeather() {
        io.execute {
            try {
                val url = URL("https://yandex-weather-proxy.mr-maloy163.workers.dev/")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                val raw = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val jsonText = raw.trim().let {
                    if (it.startsWith("{")) it
                    else it.substringAfter("(").substringBeforeLast(")").trim()
                }
                val json = JSONObject(jsonText)
                val current = json.optJSONObject("current") ?: json
                val temp = current.optDouble("temperature_2m", Double.NaN)
                    .takeIf { !it.isNaN() } ?: current.optDouble("temperature", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val wind = current.optDouble("wind_speed_10m", Double.NaN)
                val code = current.optInt("weather_code", current.optInt("weathercode", -1))
                val description = weatherDescription(code)
                val icon = weatherEmoji(code)
                runOnUiThread {
                    weatherTemp.text = if (temp.isNaN()) "--°" else "${temp.toInt()}°"
                    weatherDesc.text = description
                    weatherIcon.text = icon
                    weatherExtra.text = "Влажность ${if (humidity >= 0) "$humidity%" else "--"}   ·   Ветер ${if (wind.isNaN()) "--" else wind.toInt().toString()} м/с"
                }
            } catch (_: Exception) {
                runOnUiThread {
                    weatherTemp.text = "--°"
                    weatherDesc.text = "Погода временно недоступна"
                    weatherExtra.text = "Проверь подключение к интернету"
                    weatherIcon.text = "☁"
                }
            }
        }
    }

    private fun weatherDescription(code: Int) = when (code) {
        0 -> "Ясно"
        1, 2 -> "Переменная облачность"
        3 -> "Облачно"
        45, 48 -> "Туман"
        51, 53, 55, 56, 57 -> "Морось"
        61, 63, 65, 66, 67 -> "Дождь"
        71, 73, 75, 77 -> "Снег"
        80, 81, 82 -> "Ливень"
        85, 86 -> "Снегопад"
        95, 96, 99 -> "Гроза"
        else -> "Текущая погода"
    }

    private fun weatherEmoji(code: Int) = when (code) {
        0 -> "☀"
        1, 2 -> "🌤"
        3 -> "☁"
        45, 48 -> "🌫"
        in 51..67 -> "🌧"
        in 71..86 -> "❄"
        in 95..99 -> "⛈"
        else -> "☁"
    }

    private fun formatTime(ms: Long): String {
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0))
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    companion object {
        @Volatile private var current: MainActivity? = null
        fun requestRefresh() { current?.runOnUiThread { current?.refreshMedia() } }
    }

    override fun onStart() { super.onStart(); current = this }
    override fun onStop() { if (current === this) current = null; super.onStop() }
}
