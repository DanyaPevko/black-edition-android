plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ru.blackedition.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.blackedition.app"
        minSdk = 23
        targetSdk = 32
        versionCode = 6
        versionName = "1.3.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
