# Black Edition V1.3.1

Verified visual update:
- Midnight navy background.
- Burgundy gradient cards.
- Ruby-pink accent instead of orange.
- Lunar phase and approximate illumination.
- Clear-sky icon switches to the moon at night.
- Existing media-session controls and weather integration retained.

The build version is 1.3.1 (versionCode 6).
