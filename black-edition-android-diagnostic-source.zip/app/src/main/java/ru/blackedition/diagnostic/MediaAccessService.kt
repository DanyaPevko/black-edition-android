package ru.blackedition.diagnostic

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MediaAccessService : NotificationListenerService() {
    companion object {
        @Volatile var instance: MediaAccessService? = null
            private set
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        MainActivity.requestRefresh()
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        MainActivity.requestRefresh()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        MainActivity.requestRefresh()
    }
}
