package ru.blackedition.diagnostic

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var packageView: TextView
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var stateView: TextView
    private lateinit var timeView: TextView
    private lateinit var artwork: ImageView
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refreshMedia()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 8, 8)
        window.navigationBarColor = Color.rgb(8, 8, 8)
        buildUi()
        refreshMedia()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 18, 26, 18)
            setBackgroundColor(Color.rgb(12, 12, 12))
        }
        root.addView(label("BLACK EDITION  /  MEDIA SESSION TEST", 22f, Color.rgb(255, 132, 35), true))
        status = label("Проверка доступа…", 16f, Color.LTGRAY)
        root.addView(status)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 14, 0, 10)
        }
        artwork = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(35, 35, 35))
        }
        row.addView(artwork, LinearLayout.LayoutParams(142, 142))
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 0, 0)
        }
        titleView = label("Название трека: —", 24f, Color.WHITE, true)
        artistView = label("Исполнитель: —", 19f, Color.LTGRAY)
        packageView = label("Пакет приложения: —", 13f, Color.GRAY)
        info.addView(titleView)
        info.addView(artistView)
        info.addView(packageView)
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        stateView = label("Состояние: —", 17f, Color.WHITE)
        timeView = label("Позиция / длительность: —", 17f, Color.WHITE)
        root.addView(stateView)
        root.addView(timeView)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        controls.addView(button("◀ Назад") { sendCommand { it.skipToPrevious() } })
        controls.addView(button("Ⅱ Пауза") { sendCommand { it.pause() } })
        controls.addView(button("▶ Старт") { sendCommand { it.play() } })
        controls.addView(button("Вперёд ▶") { sendCommand { it.skipToNext() } })
        root.addView(controls)
        root.addView(button("ОБНОВИТЬ ДАННЫЕ") { refreshMedia() })
        root.addView(button("ОТКРЫТЬ ДОСТУП К УВЕДОМЛЕНИЯМ") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(label(
            "Разрешение используется для поиска активных медиасессий. Приложение не читает текст сообщений и не отправляет данные в сеть.",
            13f, Color.GRAY
        ))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 6, 0, 6)
        }

    private fun button(caption: String, action: () -> Unit) = Button(this).apply {
        text = caption
        textSize = 11f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(48, 48, 48))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply {
            setMargins(4, 6, 4, 6)
        }
    }

    private fun sendCommand(command: (MediaController.TransportControls) -> Unit) {
        val active = controller
        if (active == null) {
            status.text = "Нет активной медиасессии. Сначала включи музыку."
            return
        }
        try {
            command(active.transportControls)
            handler.postDelayed({ refreshMedia() }, 400)
        } catch (e: Exception) {
            status.text = "Команда не выполнена: ${e.javaClass.simpleName}"
        }
    }

    private fun refreshMedia() {
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val listener = ComponentName(this, MediaAccessService::class.java)
            val sessions = manager.getActiveSessions(listener)
            val active = sessions.firstOrNull {
                it.packageName.contains("yandex", ignoreCase = true)
            } ?: sessions.firstOrNull()
            controller = active

            if (active == null) {
                status.text = "Медиасессия не найдена. Запусти Яндекс Музыку и проверь доступ."
                packageView.text = "Активных сессий: ${sessions.size}"
                titleView.text = "Название трека: —"
                artistView.text = "Исполнитель: —"
                stateView.text = "Состояние: —"
                timeView.text = "Позиция / длительность: —"
                artwork.setImageDrawable(null)
                return
            }

            val metadata = active.metadata
            val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Не передано"
            val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "Не передан"
            titleView.text = "Название: $title"
            artistView.text = "Исполнитель: $artist"
            packageView.text = "Пакет: ${active.packageName}  |  Всего сессий: ${sessions.size}"

            val playback = active.playbackState
            stateView.text = "Состояние: ${when (playback?.state) {
                PlaybackState.STATE_PLAYING -> "Воспроизводится"
                PlaybackState.STATE_PAUSED -> "Пауза"
                PlaybackState.STATE_BUFFERING -> "Буферизация"
                PlaybackState.STATE_STOPPED -> "Остановлено"
                else -> "Неизвестно"
            }}"
            val position = playback?.position ?: 0L
            val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            timeView.text = "Позиция / длительность: ${formatTime(position)} / ${formatTime(duration)}"

            val bitmap = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            if (bitmap != null) artwork.setImageBitmap(bitmap)
            else artwork.setImageDrawable(null)

            status.text = "Доступ получен. Активная медиасессия обнаружена."
        } catch (e: SecurityException) {
            controller = null
            status.text = "Нет доступа. Включи Black Edition в настройках доступа к уведомлениям."
        } catch (e: Exception) {
            status.text = "Ошибка чтения: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun formatTime(ms: Long): String {
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0))
        return String.format("%02d:%02d", seconds / 60, seconds % 60)
    }

    companion object {
        @Volatile private var current: MainActivity? = null
        fun requestRefresh() {
            current?.runOnUiThread { current?.refreshMedia() }
        }
    }

    override fun onStart() {
        super.onStart()
        current = this
    }

    override fun onStop() {
        if (current === this) current = null
        super.onStop()
    }
}
