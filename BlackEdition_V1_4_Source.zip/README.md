# Black Edition V1.4

Visual polish update based on verified V1.3.1:
- Weather symbol now sits in a dedicated burgundy tile.
- Lunar phase is presented as a compact highlighted pill.
- Album art has a subtle ruby border and elevation.
- Playback progress uses a softer rose palette.
- Previous/next controls are quieter; play/pause is the primary ruby gradient control.
- Settings control matches the burgundy UI.
- Existing weather, lunar calculation and Yandex Music MediaSession logic retained.

Version: 1.4 (versionCode 7).
