package ru.blackedition.app

import android.app.Activity
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Settings.Secure
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 14, 29)
    private val panel = Color.rgb(43, 13, 27)
    private val orange = Color.rgb(239, 78, 111)
    private val muted = Color.rgb(190, 174, 185)
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var controller: MediaController? = null
    private var durationMs = 0L
    private var currentPosition = 0L
    private var lastPositionAt = 0L
    private var isSeeking = false
    private var lastMediaSignature = ""
    private val requestLogFolder = 2701

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherTemp: TextView
    private lateinit var weatherDesc: TextView
    private lateinit var weatherExtra: TextView
    private lateinit var moonInfo: TextView
    private lateinit var weatherIcon: TextView
    private lateinit var cover: ImageView
    private lateinit var track: TextView
    private lateinit var artist: TextView
    private lateinit var playbackLabel: TextView
    private lateinit var progress: SeekBar
    private lateinit var volumeSeek: SeekBar
    private lateinit var volumeValue: TextView
    private var updatingVolume = false
    private lateinit var elapsed: TextView
    private lateinit var remaining: TextView
    private lateinit var accessHint: TextView
    private lateinit var playPause: IconControlView
    private lateinit var voiceStatus: TextView
    private lateinit var voiceButton: Button
    private var voiceReceiverRegistered = false
    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BlackVoiceService.ACTION_STATUS) {
                val value = intent.getStringExtra(BlackVoiceService.EXTRA_STATUS) ?: ""
                AppLogger.log("VOICE", "Статус Black Voice: $value")
                voiceStatus.text = "BLACK VOICE: $value"
                voiceButton.text = if (value == "ВЫКЛЮЧЕН") "ВКЛЮЧИТЬ BLACK" else "ВЫКЛЮЧИТЬ BLACK"
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            updateProgress()
            refreshMedia()
            syncVolumeSlider()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLogger.init(this)
        AppLogger.installCrashHandler(this)
        AppLogger.log("LIFECYCLE", "MainActivity onCreate")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        buildUi()
        registerVoiceReceiver()
        showFirstRunSetupIfNeeded()
        updateClock()
        refreshWeather()
        refreshMedia()
    }

    override fun onResume() {
        super.onResume()
        AppLogger.log("LIFECYCLE", "MainActivity onResume")
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        AppLogger.log("LIFECYCLE", "MainActivity onPause")
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        AppLogger.log("LIFECYCLE", "MainActivity onDestroy")
        if (voiceReceiverRegistered) { try { unregisterReceiver(voiceReceiver) } catch (_: Exception) {} }
        io.shutdownNow()
        super.onDestroy()
    }

    private fun registerVoiceReceiver() {
        val filter = IntentFilter(BlackVoiceService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(voiceReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(voiceReceiver, filter)
        voiceReceiverRegistered = true
    }

    private fun isMediaAccessGranted(): Boolean {
        return try {
            val enabled = Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
            enabled.split(":").any { ComponentName.unflattenFromString(it) == ComponentName(this, MediaAccessService::class.java) }
        } catch (e: Exception) {
            AppLogger.log("PERMISSIONS", "Не удалось проверить доступ к медиасессиям", e)
            false
        }
    }

    private fun showFirstRunSetupIfNeeded() {
        val prefs = getSharedPreferences("black_setup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("intro_shown", false)) return
        android.app.AlertDialog.Builder(this)
            .setTitle("Первичная настройка Black Edition")
            .setMessage("Для голосового управления нужен доступ к микрофону. Для управления Яндекс Музыкой нужен специальный доступ к уведомлениям и медиасессиям. Android попросит включить его отдельно в системных настройках. Интернет используется для загрузки голосовой модели и погоды.")
            .setCancelable(false)
            .setPositiveButton("НАСТРОИТЬ") { _, _ ->
                prefs.edit().putBoolean("intro_shown", true).apply()
                if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1601)
                } else {
                    openMediaAccessSettingsIfNeeded()
                }
            }
            .setNegativeButton("ПОЗЖЕ") { _, _ -> prefs.edit().putBoolean("intro_shown", true).apply() }
            .show()
    }

    private fun openMediaAccessSettingsIfNeeded() {
        if (isMediaAccessGranted()) {
            AppLogger.log("PERMISSIONS", "Доступ к уведомлениям и медиасессиям уже включён")
            refreshMedia()
            return
        }
        AppLogger.log("PERMISSIONS", "Открываем системную настройку доступа к уведомлениям")
        voiceStatus.text = "BLACK VOICE: НУЖЕН ДОСТУП К МЕДИАСЕССИЯМ"
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            AppLogger.log("PERMISSIONS", "Не удалось открыть настройки доступа к уведомлениям", e)
        }
    }

    private fun toggleBlackVoice() {
        AppLogger.log("VOICE", "Нажата кнопка управления Black Voice")
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1601)
            return
        }
        val stopping = voiceButton.text.toString().contains("ВЫКЛЮЧИТЬ")
        if (!stopping && !isMediaAccessGranted()) {
            openMediaAccessSettingsIfNeeded()
            return
        }
        if (!stopping && Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            voiceStatus.text = "BLACK VOICE: НУЖНО РАЗРЕШЕНИЕ ДЛЯ ЯРКОСТИ"
            val settingsIntent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = android.net.Uri.parse("package:$packageName")
            }
            startActivity(settingsIntent)
            return
        }
        val intent = Intent(this, BlackVoiceService::class.java)
        if (voiceButton.text.toString().contains("ВЫКЛЮЧИТЬ")) {
            AppLogger.log("VOICE", "Запрошена остановка голосового сервиса")
            intent.action = BlackVoiceService.ACTION_STOP
            startService(intent)
            voiceButton.text = "ВКЛЮЧИТЬ BLACK"
            voiceStatus.text = "BLACK VOICE: ВЫКЛЮЧЕН"
        } else {
            AppLogger.log("VOICE", "Запрошен запуск голосового сервиса")
            intent.action = BlackVoiceService.ACTION_START
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            voiceButton.text = "ВЫКЛЮЧИТЬ BLACK"
            voiceStatus.text = "BLACK VOICE: ЗАПУСКАЮСЬ"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1601 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AppLogger.log("PERMISSIONS", "Доступ к микрофону выдан")
            openMediaAccessSettingsIfNeeded()
        } else if (requestCode == 1601) {
            voiceStatus.text = "BLACK VOICE: НУЖЕН ДОСТУП К МИКРОФОНУ"
            AppLogger.log("PERMISSIONS", "Пользователь не выдал доступ к микрофону")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestLogFolder && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val grantedFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                AppLogger.setFolder(uri, grantedFlags)
                val testOk = AppLogger.testFolder(this)
                android.widget.Toast.makeText(this,
                    if (testOk) "Папка выбрана и проверена: тестовый TXT сохранён" else "Доступ сохранён, но тестовая запись не удалась. Проверь папку через «ЛОГИ»",
                    android.widget.Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                AppLogger.log("DIAGNOSTICS", "Ошибка выбора папки", e)
                android.widget.Toast.makeText(this, "Не удалось сохранить папку", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showDiagnostics() {
        val options = arrayOf("Выбрать папку для логов", "Проверить запись в папку", "Сохранить журнал в выбранную папку", "Очистить журнал")
        android.app.AlertDialog.Builder(this)
            .setTitle("Диагностика Black Edition")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                        startActivityForResult(intent, requestLogFolder)
                    }
                    1 -> {
                        val ok = AppLogger.testFolder(this)
                        android.widget.Toast.makeText(this, if (ok) "Проверка успешна: TXT-файл создан" else "Не удалось записать тестовый файл. Проверь разрешение и выбранную папку.", android.widget.Toast.LENGTH_LONG).show()
                    }
                    2 -> {
                        val ok = AppLogger.export(this)
                        android.widget.Toast.makeText(this, if (ok) "Журнал сохранён" else "Ошибка сохранения. Выбери папку заново или проверь разрешение.", android.widget.Toast.LENGTH_LONG).show()
                    }
                    3 -> android.app.AlertDialog.Builder(this)
                        .setMessage("Очистить текущий журнал диагностики?")
                        .setNegativeButton("Отмена", null)
                        .setPositiveButton("Очистить") { _, _ -> AppLogger.clear() }
                        .show()
                }
            }.show()
    }

    private fun rounded(color: Int, radius: Float = 22f) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun burgundyCard(radius: Float = 26f) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(35, 10, 22), Color.rgb(69, 17, 39), Color.rgb(37, 14, 31))
    ).apply {
        cornerRadius = radius
        setStroke(1, Color.rgb(91, 35, 54))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            includeFontPadding = false
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 22)
            setBackgroundColor(bg)
        }

        // Верхняя половина: два равных самостоятельных блока.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val dateCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(28, 22, 28, 22)
            background = burgundyCard(26f)
        }
        dateCard.addView(text("BLACK EDITION  /  SYZRAN", 13f, orange, true))
        clock = text("--:--", 76f, Color.WHITE, true)
        date = text("Загрузка даты", 21f, muted)
        dateCard.addView(clock)
        dateCard.addView(date)
        top.addView(dateCard, LinearLayout.LayoutParams(0, -1, 1f))

        val gap = View(this)
        top.addView(gap, LinearLayout.LayoutParams(18, 1))

        val weatherCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(28, 22, 28, 22)
            background = burgundyCard(26f)
        }
        weatherCard.addView(text("ПОГОДА СЕЙЧАС  /  СЫЗРАНЬ", 13f, orange, true))
        val weatherMain = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 6)
        }
        val weatherIconTile = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(78, 28, 48), 24f)
            elevation = 3f
        }
        weatherIcon = text("☁", 52f, Color.WHITE)
        weatherIconTile.addView(weatherIcon)
        weatherMain.addView(weatherIconTile, LinearLayout.LayoutParams(88, 88))
        weatherTemp = text("--°", 66f, Color.WHITE, true)
        weatherTemp.setPadding(16, 0, 0, 0)
        weatherMain.addView(weatherTemp)
        weatherCard.addView(weatherMain)
        weatherDesc = text("Получаем прогноз…", 20f, Color.WHITE, true)
        weatherExtra = text("Влажность --%   ·   Ветер -- м/с", 15f, muted)
        moonInfo = text("ЛУНА  ·  --", 12f, Color.rgb(246, 190, 205), true).apply {
            setPadding(14, 9, 14, 9)
            background = rounded(Color.rgb(73, 28, 48), 18f)
        }
        weatherCard.addView(weatherDesc)
        weatherCard.addView(weatherExtra)
        val moonGap = View(this)
        weatherCard.addView(moonGap, LinearLayout.LayoutParams(1, 9))
        weatherCard.addView(moonInfo, LinearLayout.LayoutParams(-2, -2))
        top.addView(weatherCard, LinearLayout.LayoutParams(0, -1, 1f))

        root.addView(top, LinearLayout.LayoutParams(-1, 0, 0.92f))

        // Нижняя половина: музыкальный центр занимает всю ширину.
        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(30, 26, 30, 26)
            background = burgundyCard(28f)
        }
        cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(Color.rgb(42, 23, 34))
                cornerRadius = 22f
                setStroke(2, Color.rgb(139, 58, 83))
            }
            clipToOutline = true
            elevation = 5f
        }
        playerCard.addView(cover, LinearLayout.LayoutParams(250, 250))

        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(32, 0, 8, 0)
        }
        details.addView(text("СЕЙЧАС ИГРАЕТ", 13f, orange, true))
        track = text("Ожидание музыки", 32f, Color.WHITE, true)
        artist = text("Запусти Яндекс Музыку", 21f, muted)
        playbackLabel = text("●  НЕ ПОДКЛЮЧЕНО", 13f, muted, true)
        details.addView(track)
        details.addView(artist)
        val statusGap = View(this)
        details.addView(statusGap, LinearLayout.LayoutParams(1, 12))
        details.addView(playbackLabel)

        val progressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 18, 0, 0)
        }
        elapsed = text("00:00", 13f, muted)
        remaining = text("00:00", 13f, muted)
        progress = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(238, 111, 145))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 190, 207))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(105, 65, 80))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { isSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser && durationMs > 0) {
                        elapsed.text = formatTime(durationMs * value / 1000)
                    }
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val c = controller
                    if (c != null && durationMs > 0) {
                        c.transportControls.seekTo(durationMs * (seekBar?.progress ?: 0) / 1000)
                    }
                    isSeeking = false
                }
            })
        }
        progressRow.addView(elapsed)
        progressRow.addView(progress, LinearLayout.LayoutParams(0, -2, 1f).apply {
            setMargins(14, 0, 14, 0)
        })
        progressRow.addView(remaining)
        details.addView(progressRow)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 17, 0, 0)
        }
        controls.addView(control("previous", false) { command { it.skipToPrevious() } })
        playPause = control("pause", true) { togglePlayback() }
        controls.addView(playPause)
        controls.addView(control("next", false) { command { it.skipToNext() } })
        details.addView(controls)

        playerCard.addView(details, LinearLayout.LayoutParams(0, -1, 1f))

        // Separate vertical media-volume panel beside the player.
        val volumeCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 14, 12, 14)
            background = burgundyCard(24f)
        }
        val volumeIcon = text("♫", 25f, orange, true)
        volumeCard.addView(volumeIcon)
        volumeValue = text("--%", 17f, Color.WHITE, true)
        volumeValue.setPadding(0, 7, 0, 8)
        volumeCard.addView(volumeValue)
        val verticalFrame = FrameLayout(this)
        val streamMax = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        volumeSeek = SeekBar(this).apply {
            max = 100
            rotation = -90f
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(238, 111, 145))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 190, 207))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(105, 65, 80))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    volumeValue.text = "$value%"
                    if (fromUser && !updatingVolume) {
                        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        val target = (max * value / 100.0).toInt().coerceIn(0, max)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                    }
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) { syncVolumeSlider() }
            })
        }
        verticalFrame.addView(volumeSeek, FrameLayout.LayoutParams(220, 48, Gravity.CENTER))
        volumeCard.addView(verticalFrame, LinearLayout.LayoutParams(58, 220))
        volumeCard.addView(text("ГРОМКОСТЬ", 9f, muted, true))
        playerCard.addView(volumeCard, LinearLayout.LayoutParams(92, -1).apply { leftMargin = 18 })

        root.addView(playerCard, LinearLayout.LayoutParams(-1, 0, 1.08f).apply {
            topMargin = 18
        })
        syncVolumeSlider()

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(2, 8, 2, 0)
        }
        val bottomInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        accessHint = text("Медиасессия: проверка…", 11f, muted)
        voiceStatus = text("BLACK VOICE: ВЫКЛЮЧЕН", 11f, Color.rgb(242, 143, 174), true)
        bottomInfo.addView(accessHint)
        bottomInfo.addView(voiceStatus)
        bottom.addView(bottomInfo, LinearLayout.LayoutParams(0, -2, 1f))
        voiceButton = Button(this).apply {
            text = "ВКЛЮЧИТЬ BLACK"
            textSize = 10f
            setTextColor(Color.rgb(255, 220, 231))
            background = rounded(Color.rgb(91, 30, 55), 16f)
            setPadding(14, 8, 14, 8)
            setOnClickListener { toggleBlackVoice() }
        }
        bottom.addView(voiceButton)
        val diagnostics = Button(this).apply {
            text = "ЛОГИ"
            textSize = 10f
            setTextColor(Color.rgb(255, 220, 231))
            background = rounded(Color.rgb(91, 30, 55), 16f)
            setPadding(14, 8, 14, 8)
            setOnClickListener { showDiagnostics() }
        }
        bottom.addView(diagnostics)
        val settings = Button(this).apply {
            text = "НАСТРОЙКИ"
            textSize = 10f
            setTextColor(Color.rgb(231, 177, 193))
            background = rounded(Color.rgb(42, 20, 34), 16f)
            setPadding(18, 8, 18, 8)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        bottom.addView(settings)
        root.addView(bottom)
        setContentView(root)
    }

    private fun control(icon: String, primary: Boolean = false, action: () -> Unit) = IconControlView(icon, primary, action)

    private inner class IconControlView(icon: String, private val primary: Boolean, private val action: () -> Unit) : View(this@MainActivity) {
        private var iconName = icon
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = if (primary) 3.2f else 2.8f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        init {
            background = if (primary) GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(207, 66, 119), Color.rgb(126, 39, 79))).apply {
                cornerRadius = 24f; setStroke(1, Color.rgb(239, 142, 177))
            } else GradientDrawable().apply {
                setColor(Color.rgb(57, 26, 42)); cornerRadius = 22f; setStroke(1, Color.rgb(112, 61, 82))
            }
            isClickable = true; isFocusable = true; elevation = if (primary) 5f else 2f
            contentDescription = when (icon) { "previous" -> "Предыдущий трек"; "next" -> "Следующий трек"; else -> "Воспроизведение" }
            setOnClickListener {
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(75).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                }.start()
                action()
            }
            layoutParams = LinearLayout.LayoutParams(if (primary) 82 else 68, if (primary) 68 else 60).apply { setMargins(7, 0, 7, 0) }
        }
        fun setIcon(value: String) { iconName = value; contentDescription = if (value == "pause") "Пауза" else "Воспроизведение"; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); canvas.save(); canvas.translate(width / 2f, height / 2f)
            val scale = if (primary) 1f else 0.88f; canvas.scale(scale, scale)
            paint.color = if (primary) Color.WHITE else Color.rgb(244, 218, 229)
            val path = Path()
            when (iconName) {
                "previous" -> { canvas.drawLine(-13f, -13f, -13f, 13f, paint); path.moveTo(11f,-14f); path.lineTo(-5f,0f); path.lineTo(11f,14f); canvas.drawPath(path,paint) }
                "next" -> { canvas.drawLine(13f, -13f, 13f, 13f, paint); path.moveTo(-11f,-14f); path.lineTo(5f,0f); path.lineTo(-11f,14f); canvas.drawPath(path,paint) }
                "pause" -> { paint.style=Paint.Style.FILL; canvas.drawRoundRect(-9f,-14f,-3f,14f,2f,2f,paint); canvas.drawRoundRect(3f,-14f,9f,14f,2f,2f,paint) }
                else -> { paint.style=Paint.Style.FILL; path.moveTo(-7f,-15f); path.lineTo(14f,0f); path.lineTo(-7f,15f); path.close(); canvas.drawPath(path,paint) }
            }
            paint.style = Paint.Style.STROKE; canvas.restore()
        }
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale("ru")).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now)
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
    }

    private fun syncVolumeSlider() {
        if (!::volumeSeek.isInitialized || volumeSeek.isPressed) return
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            val percent = current * 100 / max
            updatingVolume = true
            volumeSeek.progress = percent
            volumeValue.text = "$percent%"
            updatingVolume = false
        } catch (_: Exception) { updatingVolume = false }
    }

    private fun refreshMedia() {
        if (!isMediaAccessGranted()) {
            controller = null
            if (lastMediaSignature != "permission_missing") {
                AppLogger.log("PERMISSIONS", "Нет специального доступа к медиасессиям; опрос приостановлен")
                lastMediaSignature = "permission_missing"
            }
            track.text = "Ожидание доступа"
            artist.text = "Разреши Black Edition доступ к уведомлениям"
            playbackLabel.text = "●  НЕТ ДОСТУПА К МЕДИАСЕССИЯМ"
            accessHint.text = "Открой настройки и включи Black Edition"
            cover.setImageDrawable(null)
            durationMs = 0
            progress.progress = 0
            playPause.setIcon("play")
            return
        }
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(this, MediaAccessService::class.java))
            val active = sessions.firstOrNull { it.packageName.contains("yandex", true) }
            controller = active
            if (active == null) {
                if (lastMediaSignature != "none") AppLogger.log("MEDIA", "Активная медиасессия Яндекс Музыки не найдена")
                lastMediaSignature = "none"
                track.text = "Ожидание музыки"
                artist.text = "Запусти Яндекс Музыку"
                playbackLabel.text = "●  МЕДИАСЕССИЯ НЕ НАЙДЕНА"
                accessHint.text = "Нет активной медиасессии"
                cover.setImageDrawable(null)
                durationMs = 0
                progress.progress = 0
                playPause.setIcon("play")
                return
            }
            val meta = active.metadata
            track.text = meta?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Без названия"
            artist.text = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "Неизвестный исполнитель"
            val bitmap: Bitmap? = meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            if (bitmap != null) cover.setImageBitmap(bitmap)
            val state = active.playbackState
            val playing = state?.state == PlaybackState.STATE_PLAYING
            val signature = "${active.packageName}|${track.text}|${artist.text}|${state?.state}"
            if (signature != lastMediaSignature) {
                AppLogger.log("MEDIA", "Плеер=${active.packageName}; трек=${track.text}; исполнитель=${artist.text}; состояние=${state?.state}")
                lastMediaSignature = signature
            }
            playbackLabel.text = if (playing) "●  ВОСПРОИЗВОДИТСЯ" else "Ⅱ  ПАУЗА"
            playbackLabel.setTextColor(if (playing) orange else muted)
            playPause.setIcon(if (playing) "pause" else "play")
            durationMs = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            currentPosition = state?.position ?: 0L
            lastPositionAt = System.currentTimeMillis()
            accessHint.text = "Яндекс Музыка подключена  ·  ${active.packageName}"
            updateProgress()
        } catch (e: SecurityException) {
            AppLogger.log("MEDIA", "Нет разрешения на чтение медиасессии", e)
            accessHint.text = "Нет доступа к медиасессии. Проверь разрешение."
        } catch (e: Exception) {
            AppLogger.log("MEDIA", "Ошибка обновления медиасессии", e)
            accessHint.text = "Ошибка медиасессии: ${e.javaClass.simpleName}"
        }
    }

    private fun updateProgress() {
        if (durationMs <= 0) {
            elapsed.text = "00:00"
            remaining.text = "00:00"
            return
        }
        val state = controller?.playbackState
        val playing = state?.state == PlaybackState.STATE_PLAYING
        val pos = if (playing) {
            currentPosition + (System.currentTimeMillis() - lastPositionAt)
        } else currentPosition
        val safe = pos.coerceIn(0, durationMs)
        if (!isSeeking) progress.progress = (safe * 1000 / durationMs).toInt()
        elapsed.text = formatTime(safe)
        remaining.text = formatTime(durationMs)
    }

    private fun togglePlayback() {
        val state = controller?.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING) command { it.pause() }
        else command { it.play() }
    }

    private fun command(action: (MediaController.TransportControls) -> Unit) {
        AppLogger.log("MEDIA", "Отправлена команда управления воспроизведением")
        val c = controller
        if (c == null) {
            accessHint.text = "Сначала запусти Яндекс Музыку"
            return
        }
        try {
            action(c.transportControls)
            handler.postDelayed({ refreshMedia() }, 450)
        } catch (e: Exception) {
            AppLogger.log("MEDIA", "Ошибка команды управления плеером", e)
            accessHint.text = "Команда не выполнена: ${e.javaClass.simpleName}"
        }
    }

    private fun refreshWeather() {
        io.execute {
            try {
                val url = URL("https://yandex-weather-proxy.mr-maloy163.workers.dev/")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                val raw = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val jsonText = raw.trim().let {
                    if (it.startsWith("{")) it
                    else it.substringAfter("(").substringBeforeLast(")").trim()
                }
                val json = JSONObject(jsonText)
                val current = json.optJSONObject("current") ?: json
                val temp = current.optDouble("temperature_2m", Double.NaN)
                    .takeIf { !it.isNaN() } ?: current.optDouble("temperature", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val wind = current.optDouble("wind_speed_10m", Double.NaN)
                val code = current.optInt("weather_code", current.optInt("weathercode", -1))
                val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                val isDay = if (current.has("is_day")) current.optInt("is_day") == 1 else hour in 7..18
                val phase = moonPhase(System.currentTimeMillis())
                runOnUiThread {
                    weatherTemp.text = if (temp.isNaN()) "--°" else "${temp.toInt()}°"
                    weatherDesc.text = weatherDescription(code)
                    weatherIcon.text = weatherEmoji(code, isDay, phase.icon)
                    weatherExtra.text = "Влажность ${if (humidity >= 0) "$humidity%" else "--"}   ·   Ветер ${if (wind.isNaN()) "--" else wind.toInt().toString()} м/с"
                    moonInfo.text = "${phase.icon} ${phase.name} · освещённость ${phase.illumination}%"
                }
            } catch (_: Exception) {
                val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                val isDay = hour in 7..18
                val phase = moonPhase(System.currentTimeMillis())
                runOnUiThread {
                    weatherTemp.text = "--°"
                    weatherDesc.text = "Погода временно недоступна"
                    weatherExtra.text = "Проверь подключение к интернету"
                    weatherIcon.text = if (isDay) "☁" else phase.icon
                    moonInfo.text = "${phase.icon} ${phase.name} · ${phase.illumination}%"
                }
            }
        }
    }

    private data class MoonPhase(val name: String, val icon: String, val illumination: Int)

    // Approximate lunar phase from the synodic month.
    private fun moonPhase(nowMs: Long): MoonPhase {
        val synodicMonth = 29.530588853
        val knownNewMoon = 947182440000.0
        val days = (nowMs - knownNewMoon) / 86400000.0
        val phase = ((days % synodicMonth) + synodicMonth) % synodicMonth / synodicMonth
        val illumination = ((1.0 - kotlin.math.cos(2.0 * Math.PI * phase)) / 2.0 * 100.0).toInt()
        return when {
            phase < 0.035 || phase >= 0.965 -> MoonPhase("Новолуние", "🌑", illumination)
            phase < 0.215 -> MoonPhase("Растущий серп", "🌒", illumination)
            phase < 0.285 -> MoonPhase("Первая четверть", "🌓", illumination)
            phase < 0.465 -> MoonPhase("Растущая Луна", "🌔", illumination)
            phase < 0.535 -> MoonPhase("Полнолуние", "🌕", illumination)
            phase < 0.715 -> MoonPhase("Убывающая Луна", "🌖", illumination)
            phase < 0.785 -> MoonPhase("Последняя четверть", "🌗", illumination)
            else -> MoonPhase("Убывающий серп", "🌘", illumination)
        }
    }

    private fun weatherDescription(code: Int) = when (code) {
        0 -> "Ясно"
        1, 2 -> "Переменная облачность"
        3 -> "Облачно"
        45, 48 -> "Туман"
        51, 53, 55, 56, 57 -> "Морось"
        61, 63, 65, 66, 67 -> "Дождь"
        71, 73, 75, 77 -> "Снег"
        80, 81, 82 -> "Ливень"
        85, 86 -> "Снегопад"
        95, 96, 99 -> "Гроза"
        else -> "Текущая погода"
    }

    private fun weatherEmoji(code: Int, isDay: Boolean, moon: String) = when (code) {
        0 -> if (isDay) "☀" else moon
        1, 2 -> if (isDay) "🌤" else "☁"
        3 -> "☁"
        45, 48 -> "🌫"
        in 51..67 -> "🌧"
        in 71..86 -> "❄"
        in 95..99 -> "⛈"
        else -> if (isDay) "☁" else moon
    }

    private fun formatTime(ms: Long): String {
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0))
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    companion object {
        @Volatile private var current: MainActivity? = null
        fun requestRefresh() { current?.runOnUiThread { current?.refreshMedia() } }
    }

    override fun onStart() { super.onStart(); current = this }
    override fun onStop() { if (current === this) current = null; super.onStop() }
}
