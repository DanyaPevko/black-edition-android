# Black Edition V1.3

Visual redesign inspired by the supplied reference:
- Deep midnight-blue outer background.
- Burgundy / wine-red gradient cards.
- Restrained ruby-pink accent instead of orange.
- Large readable clock and weather blocks.
- Dedicated lower music-player area.
- Night-aware clear-sky moon icon based on calculated lunar phase.
- Moon phase label and approximate illumination percentage.
- Rain, snow, fog and storm icons remain weather-driven.

Moon phase is calculated locally from the synodic month. It is an approximation, not an ephemeris-grade astronomical calculation. Night/day uses the weather API `is_day` field when available, otherwise local clock fallback.
