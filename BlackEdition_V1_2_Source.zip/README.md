# Black Edition V1.2

Design direction: two-zone landscape dashboard.
- Upper half split evenly between large clock/date and current weather.
- Lower half dedicated to the music player, album art, metadata, seek bar and transport controls.
- Existing Yandex Music MediaSession integration and Syzran weather proxy retained.

Build using GitHub Actions. Artifact: `black-edition-v1-apk`.
