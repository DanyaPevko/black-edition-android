# Black Edition V1.1

Design update for landscape tablet layout:
- Large clock and date at the top left.
- Larger current weather card at the top right.
- Music player fills the lower area with album art, track info, seek bar and controls.
- Existing Android MediaSession controls and weather proxy integration retained.

Build with GitHub Actions. Artifact: `black-edition-v1-apk`.
