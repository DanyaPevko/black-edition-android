package ru.blackedition.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioFocusRequest
import android.media.ToneGenerator
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

class BlackVoiceService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_START = "ru.blackedition.app.voice.START"
        const val ACTION_STOP = "ru.blackedition.app.voice.STOP"
        const val ACTION_STATUS = "ru.blackedition.app.voice.STATUS"
        const val EXTRA_STATUS = "status"
        private const val CHANNEL_ID = "black_voice_channel"
        private const val NOTIFICATION_ID = 1601
        private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip"
        private const val MODEL_DIR = "vosk-model-small-ru-0.22"
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: String? = null
    private var speaking = false
    private var speechWatchdog: Runnable? = null
    private var toneGenerator: ToneGenerator? = null
    private var duckFocusRequest: AudioFocusRequest? = null
    private var hasDuckFocus = false
    private var commandMode = false
    private var stoppedByVoice = false
    // Each recognizer gets its own generation. Late callbacks from a stopped
    // recognizer are ignored instead of being treated as a new command.
    @Volatile private var recognitionSession = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
        startForeground(NOTIFICATION_ID, notification("Загрузка голосового модуля"))
        broadcastStatus("ЗАГРУЗКА МОДЕЛИ")
        worker.execute { prepareModel() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stoppedByVoice = true
            stopListening()
            broadcastStatus("ВЫКЛЮЧЕН")
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            broadcastStatus("ОШИБКА ГОЛОСОВОГО ДВИЖКА")
            return
        }
        val engine = tts ?: return
        try {
            engine.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            val languageResult = engine.setLanguage(Locale("ru", "RU"))
            ttsReady = languageResult >= TextToSpeech.LANG_AVAILABLE
            if (!ttsReady) {
                broadcastStatus("НЕТ РУССКОГО ГОЛОСА")
                Log.w("BlackVoice", "Russian TTS voice is unavailable: $languageResult")
                return
            }
            engine.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    main.post { broadcastStatus("ОТВЕЧАЮ") }
                }
                override fun onDone(utteranceId: String?) {
                    main.post { finishSpeech() }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    main.post {
                        broadcastStatus("ОШИБКА ВОСПРОИЗВЕДЕНИЯ ГОЛОСА")
                        finishSpeech()
                    }
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    main.post {
                        Log.e("BlackVoice", "TTS playback error: $errorCode")
                        broadcastStatus("ОШИБКА ВОСПРОИЗВЕДЕНИЯ ГОЛОСА")
                        finishSpeech()
                    }
                }
            })
            pendingSpeech?.let { text ->
                pendingSpeech = null
                speak(text)
            }
        } catch (e: Exception) {
            ttsReady = false
            Log.e("BlackVoice", "TTS initialization failed", e)
            broadcastStatus("ОШИБКА ГОЛОСОВОГО ДВИЖКА")
        }
    }

    private fun prepareModel() {
        try {
            val target = File(filesDir, MODEL_DIR)
            if (!File(target, "am").exists()) {
                val archive = File(cacheDir, "vosk-model.zip")
                val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000
                    readTimeout = 60000
                    instanceFollowRedirects = true
                }
                connection.connect()
                if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
                BufferedInputStream(connection.inputStream).use { input ->
                    FileOutputStream(archive).use { output -> input.copyTo(output) }
                }
                connection.disconnect()
                val unpackRoot = File(filesDir, "vosk-unpack")
                unpackRoot.deleteRecursively()
                unpackRoot.mkdirs()
                ZipInputStream(archive.inputStream().buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val out = File(unpackRoot, entry.name)
                        if (!out.canonicalPath.startsWith(unpackRoot.canonicalPath + File.separator)) error("Invalid model archive")
                        if (entry.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { zip.copyTo(it) }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
                val extracted = File(unpackRoot, MODEL_DIR)
                if (!extracted.exists()) error("Модель не найдена в архиве")
                extracted.copyRecursively(target, overwrite = true)
                archive.delete()
                unpackRoot.deleteRecursively()
            }
            model = Model(target.absolutePath)
            main.post {
                updateNotification("Слушаю фразу «Эй, Блэк»")
                broadcastStatus("ОЖИДАНИЕ · ЭЙ, БЛЭК")
                startWakeListening()
            }
        } catch (e: Exception) {
            Log.e("BlackVoice", "Model init failed", e)
            main.post {
                broadcastStatus("ОШИБКА ЗАГРУЗКИ МОДЕЛИ")
                speak("Не удалось загрузить голосовую модель. Проверь интернет и перезапусти Black Voice.")
            }
        }
    }

    private fun startWakeListening() {
        if (stoppedByVoice || model == null) return
        try {
            stopListening()
            commandMode = false
            val session = ++recognitionSession
            val recognizer = Recognizer(model, 16000.0f, "[\"эй блэк\", \"эй блек\", \"блэк\"]")
            speech = SpeechService(recognizer, 16000.0f)
            speech?.startListening(createListener(session, false))
        } catch (e: Exception) {
            Log.e("BlackVoice", "Wake listener failed", e)
            broadcastStatus("ОШИБКА МИКРОФОНА")
        }
    }

    private fun startCommandListening() {
        if (stoppedByVoice || model == null) return
        try {
            stopListening()
            val session = ++recognitionSession
            val grammar = "[\"который час\", \"сколько времени\", \"какая сегодня дата\", \"следующий трек\", \"предыдущий трек\", \"пауза\", \"останови музыку\", \"продолжи\", \"воспроизведение\", \"что сейчас играет\", \"какая погода\", \"будет дождь\", \"громче\", \"сделай громче\", \"тише\", \"сделай тише\", \"громкость двадцать процентов\", \"громкость на двадцать процентов\", \"громкость тридцать процентов\", \"громкость на тридцать процентов\", \"громкость сорок процентов\", \"громкость на сорок процентов\", \"громкость пятьдесят процентов\", \"громкость на пятьдесят процентов\", \"громкость шестьдесят процентов\", \"громкость на шестьдесят процентов\", \"громкость семьдесят процентов\", \"громкость на семьдесят процентов\", \"громкость восемьдесят процентов\", \"громкость на восемьдесят процентов\", \"громкость девяносто процентов\", \"громкость на девяносто процентов\", \"громкость сто процентов\", \"громкость на сто процентов\", \"без звука\", \"включи звук\", \"я спать\", \"спокойной ночи\", \"режим сна\", \"я проснулся\", \"доброе утро\", \"отключи прослушивание\", \"блэк отключи прослушивание\", \"выключи блэк\"]"
            val recognizer = Recognizer(model, 16000.0f, grammar)
            speech = SpeechService(recognizer, 16000.0f)
            commandMode = true
            broadcastStatus("СЛУШАЮ КОМАНДУ")
            updateNotification("Слушаю команду")
            speech?.startListening(createListener(session, true))
            main.postDelayed({
                if (session == recognitionSession && commandMode && !stoppedByVoice) {
                    stopListening()
                    commandMode = false
                    speak("Я не расслышал команду")
                }
            }, 7000)
        } catch (e: Exception) {
            Log.e("BlackVoice", "Command listener failed", e)
            commandMode = false
            returnToWake()
        }
    }

    /** Listener bound to one recognizer generation and one explicit mode. */
    private fun createListener(session: Long, isCommandListener: Boolean) = object : RecognitionListener {
        @Volatile private var completed = false
        private fun isCurrent(): Boolean = session == recognitionSession && !stoppedByVoice && !completed

        override fun onPartialResult(hypothesis: String?) {
            if (!isCurrent() || isCommandListener) return
            val text = parsePartial(hypothesis)
            if (text.contains("эй блэк") || text.contains("эй блек") || text == "блэк") {
                // Invalidate this wake recognizer BEFORE stopping it. Any final
                // callback it emits after this point will be ignored.
                recognitionSession++
                commandMode = true
                acquireMusicDuck()
                stopListening()
                playActivationTone()
                broadcastStatus("РАСПОЗНАЮ")
                main.postDelayed({ if (!stoppedByVoice) startCommandListening() }, 220)
            }
        }

        override fun onResult(hypothesis: String?) {
            if (!isCurrent()) return
            val recognized = parseText(hypothesis)
            if (isCommandListener) {
                completed = true
                if (recognized.isNotBlank()) {
                    commandMode = false
                    stopListening()
                    handleCommand(recognized)
                } else {
                    commandMode = false
                    stopListening()
                    speak("Я не расслышал команду")
                }
            } else if (recognized.contains("эй блэк") || recognized.contains("эй блек") || recognized == "блэк") {
                // Some recognizers deliver the wake phrase only as a final result.
                recognitionSession++
                commandMode = true
                acquireMusicDuck()
                stopListening()
                playActivationTone()
                broadcastStatus("РАСПОЗНАЮ")
                main.postDelayed({ if (!stoppedByVoice) startCommandListening() }, 220)
            }
        }

        override fun onFinalResult(hypothesis: String?) = onResult(hypothesis)

        override fun onError(exception: Exception?) {
            if (!isCurrent()) return
            completed = true
            Log.e("BlackVoice", "Recognition error", exception)
            main.postDelayed({
                if (isCurrent()) {
                    if (isCommandListener) {
                        commandMode = false
                        speak("Не удалось распознать команду")
                    } else startWakeListening()
                }
            }, 900)
        }

        override fun onTimeout() {
            if (!isCurrent()) return
            completed = true
            if (isCommandListener) {
                commandMode = false
                stopListening()
                speak("Не расслышал")
            } else startWakeListening()
        }
    }

    private fun parseText(raw: String?): String = try {
        JSONObject(raw ?: "{}").optString("text").lowercase(Locale("ru")).trim()
    } catch (_: Exception) { "" }

    private fun parsePartial(raw: String?): String = try {
        JSONObject(raw ?: "{}").optString("partial").lowercase(Locale("ru")).trim()
    } catch (_: Exception) { "" }

    private fun handleCommand(command: String) {
        broadcastStatus("ОТВЕЧАЮ")
        updateNotification("Выполняю команду")
        when {
            command.contains("отключи прослушивание") || command.contains("выключи блэк") -> {
                speak("Прослушивание отключено")
                main.postDelayed({
                    stoppedByVoice = true
                    stopListening()
                    broadcastStatus("ВЫКЛЮЧЕН")
                    stopForeground(true)
                    stopSelf()
                }, 1500)
                return
            }
            command.contains("который час") || command.contains("сколько времени") -> {
                val time = java.text.SimpleDateFormat("H:mm", Locale("ru")).format(Date())
                speak("Сейчас $time")
            }
            command.contains("какая сегодня дата") -> {
                val date = java.text.SimpleDateFormat("d MMMM yyyy года", Locale("ru")).format(Date())
                speak("Сегодня $date")
            }
            command.contains("следующий трек") -> { mediaCommand { it.skipToNext() }; speak("Следующий трек") }
            command.contains("предыдущий трек") -> { mediaCommand { it.skipToPrevious() }; speak("Предыдущий трек") }
            command.contains("пауза") || command.contains("останови музыку") -> { mediaCommand { it.pause() }; speak("Музыка на паузе") }
            command.contains("продолжи") || command.contains("воспроизведение") -> { mediaCommand { it.play() }; speak("Продолжаю воспроизведение") }
            command.contains("что сейчас играет") -> speak(currentTrack())
            command.contains("громче") -> changeMusicVolume(1)
            command.contains("тише") -> changeMusicVolume(-1)
            command.contains("двадцать процентов") -> setMusicVolumePercent(20)
            command.contains("тридцать процентов") -> setMusicVolumePercent(30)
            command.contains("сорок процентов") -> setMusicVolumePercent(40)
            command.contains("пятьдесят процентов") -> setMusicVolumePercent(50)
            command.contains("шестьдесят процентов") -> setMusicVolumePercent(60)
            command.contains("семьдесят процентов") -> setMusicVolumePercent(70)
            command.contains("восемьдесят процентов") -> setMusicVolumePercent(80)
            command.contains("девяносто процентов") -> setMusicVolumePercent(90)
            command.contains("сто процентов") -> setMusicVolumePercent(100)
            command.contains("без звука") -> setMusicVolumePercent(0)
            command.contains("включи звук") -> restoreMusicVolume()
            command == "я спать" || command.contains("спокойной ночи") || command.contains("режим сна") -> setSleepMode()
            command.contains("я проснулся") || command.contains("доброе утро") -> restoreBrightness()
            command.contains("какая погода") -> speak("Погода сейчас отображается на главном экране Black Edition.")
            command.contains("будет дождь") -> speak("Прогноз дождя пока не подключён.")
            else -> speak("Команда пока не поддерживается")
        }
    }


    private fun restoreMusicVolume() {
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val prefs = getSharedPreferences("black_voice_settings", Context.MODE_PRIVATE)
            val saved = prefs.getInt("volume_before_mute", -1)
            val target = if (saved > 0) saved.coerceAtMost(max) else (max * 35 / 100.0).toInt().coerceAtLeast(1)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            speak("Звук включён")
        } catch (e: Exception) {
            Log.e("BlackVoice", "Volume restore failed", e)
            speak("Не удалось включить звук")
        }
    }

    private fun changeMusicVolume(direction: Int) {
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            val next = (current + direction).coerceIn(0, max)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0)
            val percent = if (max == 0) 0 else next * 100 / max
            speak(if (direction > 0) "Громкость увеличена. Сейчас $percent процентов" else "Громкость уменьшена. Сейчас $percent процентов")
        } catch (e: Exception) {
            Log.e("BlackVoice", "Volume change failed", e)
            speak("Не удалось изменить громкость")
        }
    }

    private fun setMusicVolumePercent(percent: Int) {
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val prefs = getSharedPreferences("black_voice_settings", Context.MODE_PRIVATE)
            val target = (max * percent / 100.0).toInt().coerceIn(0, max)
            if (percent == 0) {
                val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                if (current > 0) prefs.edit().putInt("volume_before_mute", current).apply()
            } else {
                prefs.edit().putInt("volume_before_mute", target).apply()
            }
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            speak("Громкость установлена на $percent процентов")
        } catch (e: Exception) {
            Log.e("BlackVoice", "Volume set failed", e)
            speak("Не удалось установить громкость")
        }
    }

    private fun setSleepMode() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            speak("Чтобы управлять яркостью, разреши Black Edition изменять системные настройки")
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = android.net.Uri.parse("package:$packageName")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try { startActivity(intent) } catch (e: Exception) { Log.e("BlackVoice", "Cannot open brightness permission", e) }
            return
        }
        try {
            val prefs = getSharedPreferences("black_voice_settings", Context.MODE_PRIVATE)
            val current = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            val currentMode = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            if (!prefs.contains("brightness_before_sleep")) {
                prefs.edit().putInt("brightness_before_sleep", current)
                    .putInt("brightness_mode_before_sleep", currentMode).apply()
            }
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 77)
            speak("Спокойной ночи. Яркость экрана установлена на тридцать процентов")
        } catch (e: Exception) {
            Log.e("BlackVoice", "Sleep mode failed", e)
            speak("Не удалось изменить яркость экрана")
        }
    }

    private fun restoreBrightness() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            speak("Нет разрешения на изменение яркости")
            return
        }
        try {
            val prefs = getSharedPreferences("black_voice_settings", Context.MODE_PRIVATE)
            val previous = prefs.getInt("brightness_before_sleep", -1)
            if (previous >= 0) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    prefs.getInt("brightness_mode_before_sleep", Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL))
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, previous)
                prefs.edit().remove("brightness_before_sleep").remove("brightness_mode_before_sleep").apply()
                speak("Доброе утро. Вернул прежнюю яркость экрана")
            } else {
                speak("Предыдущая яркость не сохранена")
            }
        } catch (e: Exception) {
            Log.e("BlackVoice", "Brightness restore failed", e)
            speak("Не удалось восстановить яркость")
        }
    }

    private fun mediaCommand(action: (MediaController.TransportControls) -> Unit) {
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(this, MediaAccessService::class.java))
            val controller = sessions.firstOrNull { it.packageName.contains("yandex", true) }
            if (controller == null) speak("Яндекс Музыка не подключена") else action(controller.transportControls)
        } catch (e: Exception) { Log.e("BlackVoice", "Media command failed", e) }
    }

    private fun currentTrack(): String {
        return try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val c = manager.getActiveSessions(ComponentName(this, MediaAccessService::class.java))
                .firstOrNull { it.packageName.contains("yandex", true) }
            val title = c?.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
            val artist = c?.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
            if (title.isNullOrBlank()) "Сейчас ничего не играет" else "Сейчас играет $title, исполнитель $artist"
        } catch (_: Exception) { "Не удалось получить информацию о треке" }
    }

    /** Ask the active music player to duck its media while Black listens/responds. */
    private fun acquireMusicDuck() {
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val result = if (Build.VERSION.SDK_INT >= 26) {
                val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAcceptsDelayedFocusGain(false)
                    .setOnAudioFocusChangeListener { }
                    .build()
                duckFocusRequest = request
                audio.requestAudioFocus(request)
            } else {
                @Suppress("DEPRECATION")
                audio.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            }
            hasDuckFocus = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            Log.d("BlackVoice", "Duck audio focus granted=$hasDuckFocus")
        } catch (e: Exception) {
            Log.w("BlackVoice", "Could not request duck audio focus", e)
        }
    }

    private fun releaseMusicDuck() {
        if (!hasDuckFocus) return
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) {
                duckFocusRequest?.let { audio.abandonAudioFocusRequest(it) }
                duckFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audio.abandonAudioFocus(null)
            }
        } catch (e: Exception) {
            Log.w("BlackVoice", "Could not release duck audio focus", e)
        } finally {
            hasDuckFocus = false
        }
    }

    private fun speak(text: String) {
        broadcastStatus("ГОТОВЛЮ ОТВЕТ")
        if (!ttsReady || tts == null) {
            pendingSpeech = text
            return
        }
        try {
            speaking = true
            val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "black_voice_${System.currentTimeMillis()}")
            if (result == TextToSpeech.ERROR) {
                speaking = false
                pendingSpeech = null
                broadcastStatus("ОШИБКА ЗАПУСКА ГОЛОСА")
                returnToWake()
                return
            }
            speechWatchdog?.let { main.removeCallbacks(it) }
            val watchdog = Runnable {
                if (speaking) {
                    Log.w("BlackVoice", "TTS watchdog expired")
                    broadcastStatus("ТАЙМ-АУТ ГОЛОСОВОГО ОТВЕТА")
                    finishSpeech()
                }
            }
            speechWatchdog = watchdog
            main.postDelayed(watchdog, (text.length * 110L + 5000L).coerceIn(8000L, 20000L))
        } catch (e: Exception) {
            speaking = false
            Log.e("BlackVoice", "Unable to speak", e)
            broadcastStatus("ОШИБКА ВОСПРОИЗВЕДЕНИЯ ГОЛОСА")
            returnToWake()
        }
    }

    private fun finishSpeech() {
        if (!speaking) return
        speaking = false
        speechWatchdog?.let { main.removeCallbacks(it) }
        speechWatchdog = null
        returnToWake()
    }

    private fun playActivationTone() {
        try {
            toneGenerator?.release()
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 75)
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 160)
            main.postDelayed({
                try { toneGenerator?.release() } catch (_: Exception) {}
                toneGenerator = null
            }, 260)
        } catch (e: Exception) {
            Log.w("BlackVoice", "Activation tone unavailable", e)
        }
    }

    private fun returnToWake() {
        releaseMusicDuck()
        if (stoppedByVoice) return
        broadcastStatus("ОЖИДАНИЕ · ЭЙ, БЛЭК")
        updateNotification("Слушаю фразу «Эй, Блэк»")
        main.postDelayed({ startWakeListening() }, 500)
    }

    private fun stopListening() {
        val old = speech
        speech = null
        try { old?.stop() } catch (e: Exception) { Log.w("BlackVoice", "Recognizer stop failed", e) }
        try { old?.shutdown() } catch (e: Exception) { Log.w("BlackVoice", "Recognizer shutdown failed", e) }
    }

    private fun broadcastStatus(value: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_STATUS, value))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Black Voice", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Постоянное прослушивание фразы активации Эй, Блэк"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Black Voice активен").setContentText(message)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(open).setOngoing(true).build()
    }

    private fun updateNotification(message: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(message))
    }

    override fun onDestroy() {
        stoppedByVoice = true
        stopListening()
        model?.close()
        speechWatchdog?.let { main.removeCallbacks(it) }
        try { toneGenerator?.release() } catch (_: Exception) {}
        toneGenerator = null
        releaseMusicDuck()
        tts?.stop(); tts?.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }
}
