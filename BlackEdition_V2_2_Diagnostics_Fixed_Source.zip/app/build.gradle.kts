plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ru.blackedition.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.blackedition.app"
        minSdk = 23
        targetSdk = 32
        versionCode = 15
        versionName = "2.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}


dependencies {
    implementation("com.alphacephei:vosk-android:0.3.75")
}
