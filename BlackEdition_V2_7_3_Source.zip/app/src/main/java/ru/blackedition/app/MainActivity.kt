package ru.blackedition.app

import android.app.Activity
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Settings.Secure
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ProgressBar
import android.widget.TextView
import org.json.JSONObject
import com.caverock.androidsvg.SVG
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 14, 29)
    private val panel = Color.rgb(43, 13, 27)
    private val orange = Color.rgb(239, 78, 111)
    private val muted = Color.rgb(190, 174, 185)
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var controller: MediaController? = null
    private var durationMs = 0L
    private var currentPosition = 0L
    private var lastPositionAt = 0L
    private var isSeeking = false
    private var lastMediaSignature = ""
    private val requestLogFolder = 2701

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherTemp: TextView
    private lateinit var weatherDesc: TextView
    private lateinit var weatherExtra: TextView
    private lateinit var moonInfo: TextView
    private lateinit var weatherIcon: GlyphView
    private lateinit var cover: ImageView
    private lateinit var track: TextView
    private lateinit var artist: TextView
    private lateinit var playbackLabel: TextView
    private lateinit var progress: SeekBar
    private lateinit var volumeFill: VolumeFillView
    private lateinit var elapsed: TextView
    private lateinit var remaining: TextView
    private lateinit var accessHint: TextView
    private lateinit var playPause: IconControlView
    private lateinit var voiceStatus: TextView
    private lateinit var voiceButton: Button
    private var voiceReceiverRegistered = false
    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BlackVoiceService.ACTION_STATUS) {
                val value = intent.getStringExtra(BlackVoiceService.EXTRA_STATUS) ?: ""
                AppLogger.log("VOICE", "Статус Black Voice: $value")
                voiceStatus.text = "BLACK VOICE: $value"
                voiceButton.text = if (value == "ВЫКЛЮЧЕН") "ВКЛЮЧИТЬ BLACK" else "ВЫКЛЮЧИТЬ BLACK"
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            updateProgress()
            refreshMedia()
            syncVolumeSlider()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLogger.init(this)
        AppLogger.installCrashHandler(this)
        AppLogger.log("LIFECYCLE", "MainActivity onCreate")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        buildUi()
        registerVoiceReceiver()
        showFirstRunSetupIfNeeded()
        updateClock()
        refreshWeather()
        refreshMedia()
        maybeCheckForUpdates(false)
    }

    override fun onResume() {
        super.onResume()
        AppLogger.log("LIFECYCLE", "MainActivity onResume")
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        tryPendingUpdateInstall()
    }

    override fun onPause() {
        AppLogger.log("LIFECYCLE", "MainActivity onPause")
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        AppLogger.log("LIFECYCLE", "MainActivity onDestroy")
        if (voiceReceiverRegistered) { try { unregisterReceiver(voiceReceiver) } catch (_: Exception) {} }
        io.shutdownNow()
        super.onDestroy()
    }

    private fun registerVoiceReceiver() {
        val filter = IntentFilter(BlackVoiceService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(voiceReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(voiceReceiver, filter)
        voiceReceiverRegistered = true
    }

    private fun isMediaAccessGranted(): Boolean {
        return try {
            val enabled = Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
            enabled.split(":").any { ComponentName.unflattenFromString(it) == ComponentName(this, MediaAccessService::class.java) }
        } catch (e: Exception) {
            AppLogger.log("PERMISSIONS", "Не удалось проверить доступ к медиасессиям", e)
            false
        }
    }

    private fun showFirstRunSetupIfNeeded() {
        val prefs = getSharedPreferences("black_setup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("intro_shown", false)) return
        android.app.AlertDialog.Builder(this)
            .setTitle("Первичная настройка Black Edition")
            .setMessage("Для голосового управления нужен доступ к микрофону. Для управления Яндекс Музыкой нужен специальный доступ к уведомлениям и медиасессиям. Android попросит включить его отдельно в системных настройках. Интернет используется для загрузки голосовой модели и погоды.")
            .setCancelable(false)
            .setPositiveButton("НАСТРОИТЬ") { _, _ ->
                prefs.edit().putBoolean("intro_shown", true).apply()
                if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1601)
                } else {
                    openMediaAccessSettingsIfNeeded()
                }
            }
            .setNegativeButton("ПОЗЖЕ") { _, _ -> prefs.edit().putBoolean("intro_shown", true).apply() }
            .show()
    }

    private fun openMediaAccessSettingsIfNeeded() {
        if (isMediaAccessGranted()) {
            AppLogger.log("PERMISSIONS", "Доступ к уведомлениям и медиасессиям уже включён")
            refreshMedia()
            return
        }
        AppLogger.log("PERMISSIONS", "Открываем системную настройку доступа к уведомлениям")
        voiceStatus.text = "BLACK VOICE: НУЖЕН ДОСТУП К МЕДИАСЕССИЯМ"
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            AppLogger.log("PERMISSIONS", "Не удалось открыть настройки доступа к уведомлениям", e)
        }
    }

    private fun toggleBlackVoice() {
        AppLogger.log("VOICE", "Нажата кнопка управления Black Voice")
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1601)
            return
        }
        val stopping = voiceButton.text.toString().contains("ВЫКЛЮЧИТЬ")
        if (!stopping && !isMediaAccessGranted()) {
            openMediaAccessSettingsIfNeeded()
            return
        }
        if (!stopping && Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            voiceStatus.text = "BLACK VOICE: НУЖНО РАЗРЕШЕНИЕ ДЛЯ ЯРКОСТИ"
            val settingsIntent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = android.net.Uri.parse("package:$packageName")
            }
            startActivity(settingsIntent)
            return
        }
        val intent = Intent(this, BlackVoiceService::class.java)
        if (voiceButton.text.toString().contains("ВЫКЛЮЧИТЬ")) {
            AppLogger.log("VOICE", "Запрошена остановка голосового сервиса")
            intent.action = BlackVoiceService.ACTION_STOP
            startService(intent)
            voiceButton.text = "ВКЛЮЧИТЬ BLACK"
            voiceStatus.text = "BLACK VOICE: ВЫКЛЮЧЕН"
        } else {
            AppLogger.log("VOICE", "Запрошен запуск голосового сервиса")
            intent.action = BlackVoiceService.ACTION_START
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            voiceButton.text = "ВЫКЛЮЧИТЬ BLACK"
            voiceStatus.text = "BLACK VOICE: ЗАПУСКАЮСЬ"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1601 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AppLogger.log("PERMISSIONS", "Доступ к микрофону выдан")
            openMediaAccessSettingsIfNeeded()
        } else if (requestCode == 1601) {
            voiceStatus.text = "BLACK VOICE: НУЖЕН ДОСТУП К МИКРОФОНУ"
            AppLogger.log("PERMISSIONS", "Пользователь не выдал доступ к микрофону")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestLogFolder && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val grantedFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                AppLogger.setFolder(uri, grantedFlags)
                val testOk = AppLogger.testFolder(this)
                android.widget.Toast.makeText(this,
                    if (testOk) "Папка выбрана и проверена: тестовый TXT сохранён" else "Доступ сохранён, но тестовая запись не удалась. Проверь папку через «ЛОГИ»",
                    android.widget.Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                AppLogger.log("DIAGNOSTICS", "Ошибка выбора папки", e)
                android.widget.Toast.makeText(this, "Не удалось сохранить папку", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showDiagnostics() {
        val options = arrayOf("Выбрать папку для логов", "Проверить запись в папку", "Сохранить журнал в выбранную папку", "Очистить журнал")
        android.app.AlertDialog.Builder(this)
            .setTitle("Диагностика Black Edition")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                        startActivityForResult(intent, requestLogFolder)
                    }
                    1 -> {
                        val ok = AppLogger.testFolder(this)
                        android.widget.Toast.makeText(this, if (ok) "Проверка успешна: TXT-файл создан" else "Не удалось записать тестовый файл. Проверь разрешение и выбранную папку.", android.widget.Toast.LENGTH_LONG).show()
                    }
                    2 -> {
                        val ok = AppLogger.export(this)
                        android.widget.Toast.makeText(this, if (ok) "Журнал сохранён" else "Ошибка сохранения. Выбери папку заново или проверь разрешение.", android.widget.Toast.LENGTH_LONG).show()
                    }
                    3 -> android.app.AlertDialog.Builder(this)
                        .setMessage("Очистить текущий журнал диагностики?")
                        .setNegativeButton("Отмена", null)
                        .setPositiveButton("Очистить") { _, _ -> AppLogger.clear() }
                        .show()
                }
            }.show()
    }

    private fun rounded(color: Int, radius: Float = 22f) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun burgundyCard(radius: Float = 26f) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(35, 10, 22), Color.rgb(69, 17, 39), Color.rgb(37, 14, 31))
    ).apply {
        cornerRadius = radius
        setStroke(1, Color.rgb(91, 35, 54))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            includeFontPadding = false
        }


    private fun showSettingsDialog() {
        val items = arrayOf("Проверить обновления", "Доступ к медиасессиям", "Диагностика и журналы")
        android.app.AlertDialog.Builder(this)
            .setTitle("Настройки Black Edition")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> maybeCheckForUpdates(true)
                    1 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    2 -> showDiagnostics()
                }
            }
            .show()
    }

    private fun installedVersionCode(): Int {
        return try {
            val info = packageManager.getPackageInfo(packageName, 0)
            @Suppress("DEPRECATION")
            val legacyCode = info.versionCode
            if (Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt() else legacyCode
        } catch (_: Exception) { 0 }
    }

    private fun maybeCheckForUpdates(force: Boolean) {
        val prefs = getSharedPreferences("black_updates", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong("last_check", 0L)
        if (!force && now - last < 24L * 60L * 60L * 1000L) return
        AppLogger.log("UPDATER", if (force) "Ручная проверка обновлений" else "Автоматическая проверка обновлений")
        if (force) android.widget.Toast.makeText(this, "Проверяем обновления…", android.widget.Toast.LENGTH_SHORT).show()
        AppUpdater.check { result ->
            result.onFailure { error ->
                AppLogger.log("UPDATER", "Ошибка проверки обновления", error)
                if (force && !isFinishing) android.app.AlertDialog.Builder(this)
                    .setTitle("Не удалось проверить обновления")
                    .setMessage(error.message ?: "Проверь подключение к интернету")
                    .setPositiveButton("ПОНЯТНО", null).show()
            }
            result.onSuccess { update ->
                prefs.edit().putLong("last_check", System.currentTimeMillis()).apply()
                if (update == null) return@onSuccess
                val current = installedVersionCode()
                AppLogger.log("UPDATER", "Найдена версия ${update.versionName}, code=${update.versionCode}; установлена code=$current")
                if (update.versionCode <= current) {
                    if (force && !isFinishing) android.app.AlertDialog.Builder(this)
                        .setTitle("Обновлений нет")
                        .setMessage("Установлена актуальная версия Black Edition.")
                        .setPositiveButton("ОТЛИЧНО", null).show()
                    return@onSuccess
                }
                if (!isFinishing) showUpdateAvailable(update)
            }
        }
    }

    private fun showUpdateAvailable(update: AppUpdater.UpdateInfo) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Доступно обновление ${update.versionName}")
            .setMessage(update.notes.ifBlank { "Доступна новая версия Black Edition." })
            .setNegativeButton("ПОЗЖЕ", null)
            .setPositiveButton("СКАЧАТЬ") { _, _ -> downloadUpdate(update) }
            .show()
    }

    private fun downloadUpdate(update: AppUpdater.UpdateInfo) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 8)
        }
        val label = text("Подготовка загрузки…", 14f, Color.WHITE)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0 }
        layout.addView(label)
        layout.addView(bar, LinearLayout.LayoutParams(-1, 18).apply { topMargin = 16 })
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Загрузка Black Edition ${update.versionName}")
            .setView(layout)
            .create()
        dialog.setCancelable(false)
        dialog.show()
        AppUpdater.download(this, update, { percent ->
            if (dialog.isShowing) {
                bar.progress = percent
                label.text = "Загрузка: $percent%"
            }
        }) { result ->
            if (!dialog.isShowing && result.isSuccess) return@download
            result.onFailure { error ->
                if (dialog.isShowing) dialog.dismiss()
                AppLogger.log("UPDATER", "Ошибка загрузки или проверки APK", error)
                if (!isFinishing) android.app.AlertDialog.Builder(this)
                    .setTitle("Ошибка обновления")
                    .setMessage(error.message ?: "Не удалось загрузить APK")
                    .setPositiveButton("ЗАКРЫТЬ", null).show()
            }
            result.onSuccess { apk ->
                if (dialog.isShowing) dialog.dismiss()
                getSharedPreferences("black_updates", Context.MODE_PRIVATE).edit()
                    .putString("pending_apk", apk.absolutePath).apply()
                launchUpdateInstaller(apk)
            }
        }
    }

    private fun launchUpdateInstaller(apk: java.io.File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Разрешение на установку")
                .setMessage("Разреши Black Edition устанавливать обновления из этого источника. Android откроет системную настройку. После возвращения установка продолжится.")
                .setNegativeButton("ПОЗЖЕ", null)
                .setPositiveButton("ОТКРЫТЬ НАСТРОЙКИ") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                            data = android.net.Uri.parse("package:$packageName")
                        })
                    } catch (e: Exception) {
                        AppLogger.log("UPDATER", "Не удалось открыть настройку установки неизвестных приложений", e)
                    }
                }.show()
            return
        }
        try {
            AppLogger.log("UPDATER", "Передаём проверенный APK системному установщику: ${apk.name}")
            startActivity(AppUpdater.installerIntent(this, apk))
        } catch (e: Exception) {
            AppLogger.log("UPDATER", "Не удалось открыть системный установщик", e)
            android.app.AlertDialog.Builder(this).setTitle("Не удалось открыть установщик")
                .setMessage(e.message ?: "Проверь разрешение на установку приложений")
                .setPositiveButton("ЗАКРЫТЬ", null).show()
        }
    }

    private fun tryPendingUpdateInstall() {
        val prefs = getSharedPreferences("black_updates", Context.MODE_PRIVATE)
        val path = prefs.getString("pending_apk", null) ?: return
        val apk = java.io.File(path)
        if (!apk.exists()) {
            prefs.edit().remove("pending_apk").apply()
            return
        }
        if (Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls()) {
            prefs.edit().remove("pending_apk").apply()
            launchUpdateInstaller(apk)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 22)
            setBackgroundColor(bg)
        }

        // Верхняя половина: два равных самостоятельных блока.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val dateCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(28, 22, 28, 22)
            background = burgundyCard(26f)
        }
        dateCard.addView(text("BLACK EDITION  /  SYZRAN", 13f, orange, true))
        clock = text("--:--", 76f, Color.WHITE, true)
        date = text("Загрузка даты", 21f, muted)
        dateCard.addView(clock)
        dateCard.addView(date)
        top.addView(dateCard, LinearLayout.LayoutParams(0, -1, 1f))

        val gap = View(this)
        top.addView(gap, LinearLayout.LayoutParams(18, 1))

        val weatherCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(28, 22, 28, 22)
            background = burgundyCard(26f)
        }
        weatherCard.addView(text("ПОГОДА СЕЙЧАС  /  СЫЗРАНЬ", 13f, orange, true))
        val weatherMain = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 6)
        }
        val weatherIconTile = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(78, 28, 48), 24f)
            elevation = 3f
        }
        weatherIcon = GlyphView("cloud", Color.WHITE, 52f)
        weatherIconTile.addView(weatherIcon, LinearLayout.LayoutParams(66, 66))
        weatherMain.addView(weatherIconTile, LinearLayout.LayoutParams(88, 88))
        weatherTemp = text("--°", 66f, Color.WHITE, true)
        weatherTemp.setPadding(16, 0, 0, 0)
        weatherMain.addView(weatherTemp)
        weatherCard.addView(weatherMain)
        weatherDesc = text("Получаем прогноз…", 20f, Color.WHITE, true)
        weatherExtra = text("Влажность --%   ·   Ветер -- м/с", 15f, muted)
        moonInfo = text("ЛУНА  ·  --", 12f, Color.rgb(246, 190, 205), true).apply {
            setPadding(14, 9, 14, 9)
            background = rounded(Color.rgb(73, 28, 48), 18f)
        }
        weatherCard.addView(weatherDesc)
        weatherCard.addView(weatherExtra)
        val moonGap = View(this)
        weatherCard.addView(moonGap, LinearLayout.LayoutParams(1, 9))
        weatherCard.addView(moonInfo, LinearLayout.LayoutParams(-2, -2))
        top.addView(weatherCard, LinearLayout.LayoutParams(0, -1, 1f))

        root.addView(top, LinearLayout.LayoutParams(-1, 0, 0.92f))

        // Нижняя половина: музыкальный центр занимает всю ширину.
        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(30, 26, 30, 26)
            background = burgundyCard(28f)
        }
        cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(Color.rgb(42, 23, 34))
                cornerRadius = 22f
                setStroke(2, Color.rgb(139, 58, 83))
            }
            clipToOutline = true
            elevation = 5f
        }
        playerCard.addView(cover, LinearLayout.LayoutParams(250, 250))

        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(32, 0, 8, 0)
        }
        details.addView(text("СЕЙЧАС ИГРАЕТ", 13f, orange, true))
        track = text("Ожидание музыки", 32f, Color.WHITE, true)
        artist = text("Запусти Яндекс Музыку", 21f, muted)
        playbackLabel = text("●  НЕ ПОДКЛЮЧЕНО", 13f, muted, true)
        details.addView(track)
        details.addView(artist)
        val statusGap = View(this)
        details.addView(statusGap, LinearLayout.LayoutParams(1, 12))
        details.addView(playbackLabel)

        val progressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 18, 0, 0)
        }
        elapsed = text("00:00", 13f, muted)
        remaining = text("00:00", 13f, muted)
        progress = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(238, 111, 145))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 190, 207))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(105, 65, 80))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { isSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser && durationMs > 0) {
                        elapsed.text = formatTime(durationMs * value / 1000)
                    }
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val c = controller
                    if (c != null && durationMs > 0) {
                        c.transportControls.seekTo(durationMs * (seekBar?.progress ?: 0) / 1000)
                    }
                    isSeeking = false
                }
            })
        }
        progressRow.addView(elapsed)
        progressRow.addView(progress, LinearLayout.LayoutParams(0, -2, 1f).apply {
            setMargins(14, 0, 14, 0)
        })
        progressRow.addView(remaining)
        details.addView(progressRow)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 17, 0, 0)
        }
        controls.addView(control("previous", false) { command { it.skipToPrevious() } })
        playPause = control("pause", true) { togglePlayback() }
        controls.addView(playPause)
        controls.addView(control("next", false) { command { it.skipToNext() } })
        details.addView(controls)

        playerCard.addView(details, LinearLayout.LayoutParams(0, -1, 1f))

        // Full-surface volume control: the panel itself fills from bottom to top.
        volumeFill = VolumeFillView()
        playerCard.addView(volumeFill, LinearLayout.LayoutParams(88, -1).apply {
            leftMargin = 16
        })
        syncVolumeSlider()

        root.addView(playerCard, LinearLayout.LayoutParams(-1, 0, 1.08f).apply {
            topMargin = 18
        })
        syncVolumeSlider()

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(2, 8, 2, 0)
        }
        val bottomInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        accessHint = text("Медиасессия: проверка…", 11f, muted)
        voiceStatus = text("BLACK VOICE: ВЫКЛЮЧЕН", 11f, Color.rgb(242, 143, 174), true)
        bottomInfo.addView(accessHint)
        bottomInfo.addView(voiceStatus)
        bottom.addView(bottomInfo, LinearLayout.LayoutParams(0, -2, 1f))
        voiceButton = Button(this).apply {
            text = "ВКЛЮЧИТЬ BLACK"
            textSize = 10f
            setTextColor(Color.rgb(255, 220, 231))
            background = rounded(Color.rgb(91, 30, 55), 16f)
            setPadding(14, 8, 14, 8)
            setOnClickListener { toggleBlackVoice() }
        }
        bottom.addView(voiceButton)
        val diagnostics = Button(this).apply {
            text = "ЛОГИ"
            textSize = 10f
            setTextColor(Color.rgb(255, 220, 231))
            background = rounded(Color.rgb(91, 30, 55), 16f)
            setPadding(14, 8, 14, 8)
            setOnClickListener { showDiagnostics() }
        }
        bottom.addView(diagnostics)
        val settings = Button(this).apply {
            text = "НАСТРОЙКИ"
            textSize = 10f
            setTextColor(Color.rgb(231, 177, 193))
            background = rounded(Color.rgb(42, 20, 34), 16f)
            setPadding(18, 8, 18, 8)
            setOnClickListener { showSettingsDialog() }
        }
        bottom.addView(settings)
        root.addView(bottom)
        setContentView(root)
    }

    private fun control(icon: String, primary: Boolean = false, action: () -> Unit) = IconControlView(icon, primary, action)

    private inner class GlyphView(
        private var glyph: String,
        private val tint: Int,
        private val nominalSize: Float
    ) : View(this@MainActivity) {
        private var moonPhaseFraction: Double = 0.25
        private var cachedSvgGlyph: String? = null
        private var cachedSvg: SVG? = null

        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint; style = Paint.Style.STROKE; strokeWidth = 3.8f
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tint; style = Paint.Style.FILL }
        private val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(133, 205, 244); style = Paint.Style.FILL }
        private val cloudFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(154, 163, 176); style = Paint.Style.FILL }
        fun setGlyph(value: String, phaseFraction: Double? = null) {
            if (glyph != value) {
                cachedSvgGlyph = null
                cachedSvg = null
            }
            glyph = value
            if (phaseFraction != null) moonPhaseFraction = phaseFraction.coerceIn(0.0, 1.0)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // Static weather illustrations are rendered from the bundled SVG assets.
            // Moon phases remain procedural so the terminator matches the live illumination percentage.
            if (glyph != "speaker" && glyph != "moon" && glyph != "moon_cloud" && !glyph.startsWith("moon_")) {
                try {
                    if (cachedSvgGlyph != glyph || cachedSvg == null) {
                        cachedSvg = SVG.getFromAsset(this@MainActivity.assets, "weather/$glyph.svg")
                        cachedSvgGlyph = glyph
                    }
                    cachedSvg?.renderToCanvas(canvas, android.graphics.RectF(0f, 0f, width.toFloat(), height.toFloat()))
                    return
                } catch (e: Exception) {
                    AppLogger.log("WEATHER", "Не удалось загрузить SVG $glyph", e)
                }
            }
            val scale = minOf(width, height) / 76f
            canvas.save(); canvas.translate(width / 2f, height / 2f); canvas.scale(scale, scale)
            when {
                glyph == "speaker" -> drawSpeaker(canvas)
                glyph == "moon" || glyph.startsWith("moon_") -> drawMoon(canvas, moonPhaseFraction)
                glyph == "sun" -> drawSun(canvas, 0f, -7f, 13f)
                glyph == "mainly_clear" -> { drawSun(canvas, 0f, -8f, 12f); drawSmallCloud(canvas, 12f, 12f) }
                glyph == "partly" -> { drawSun(canvas, 15f, -20f, 11f); drawCloud(canvas) }
                glyph == "moon_mainly_cloud" -> { drawMoon(canvas, moonPhaseFraction, -12f, -17f, 27f); drawSmallCloud(canvas, 13f, 13f) }
                glyph == "moon_cloud" -> { drawMoon(canvas, moonPhaseFraction, -12f, -17f, 27f); drawCloud(canvas) }
                glyph == "cloud" -> drawCloud(canvas)
                glyph == "fog" -> { drawCloud(canvas); for (y in 18..30 step 7) canvas.drawLine(-24f, y.toFloat(), 24f, y.toFloat(), stroke) }
                glyph == "drizzle_light" -> { drawCloud(canvas); drawRain(canvas, 2) }
                glyph == "drizzle" || glyph == "rain" || glyph == "rain_light" -> { drawCloud(canvas); drawRain(canvas, 3) }
                glyph == "rain_moderate" || glyph == "heavy_rain" || glyph == "rain_heavy" -> { drawCloud(canvas); drawRain(canvas, 5) }
                glyph == "freezing_drizzle" || glyph == "freezing_rain" || glyph == "sleet" -> { drawCloud(canvas); drawRain(canvas, 2); drawSnow(canvas, 2) }
                glyph == "snow_light" || glyph == "snow_grains" -> { drawCloud(canvas); drawSnow(canvas, 2) }
                glyph == "snow" || glyph == "snow_moderate" -> { drawCloud(canvas); drawSnow(canvas, 3) }
                glyph == "snow_heavy" || glyph == "heavy_snow" -> { drawCloud(canvas); drawSnow(canvas, 5) }
                glyph == "storm" || glyph == "storm_heavy" -> { drawCloud(canvas); drawLightning(canvas); if (glyph == "storm_heavy") drawRain(canvas, 3) }
                glyph == "storm_hail" || glyph == "storm_hail_heavy" -> { drawCloud(canvas); drawLightning(canvas); drawHail(canvas, if (glyph == "storm_hail_heavy") 5 else 3) }
                glyph == "hail" -> { drawCloud(canvas); for (x in listOf(-13f, 0f, 13f)) canvas.drawCircle(x, 24f, 3.2f, blue) }
                else -> drawCloud(canvas)
            }
            canvas.restore()
        }

        private fun drawSpeaker(c: Canvas) {
            val p = stroke
            val path = Path().apply { moveTo(-22f,-10f); lineTo(-12f,-10f); lineTo(2f,-22f); lineTo(2f,22f); lineTo(-12f,10f); lineTo(-22f,10f); close() }
            c.drawPath(path, p); c.drawArc(0f,-17f,32f,17f,-58f,116f,false,p)
        }
        private fun drawSun(c: Canvas, cx: Float, cy: Float, r: Float) {
            c.drawCircle(cx,cy,r,fill)
            for (a in 0..7) { val rad=Math.toRadians(a*45.0); c.drawLine(cx+(r+7)*kotlin.math.cos(rad).toFloat(),cy+(r+7)*kotlin.math.sin(rad).toFloat(),cx+(r+14)*kotlin.math.cos(rad).toFloat(),cy+(r+14)*kotlin.math.sin(rad).toFloat(),stroke) }
        }
        private fun drawSmallCloud(c: Canvas, cx: Float, cy: Float) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(154, 163, 176); style = Paint.Style.FILL }
            c.drawOval(cx - 16f, cy - 5f, cx + 17f, cy + 10f, p)
            c.drawCircle(cx - 7f, cy - 4f, 9f, p)
            c.drawCircle(cx + 5f, cy - 7f, 11f, p)
            c.drawOval(cx - 17f, cy + 3f, cx + 18f, cy + 12f, p)
            c.drawArc(cx - 18f, cy - 14f, cx + 19f, cy + 14f, 0f, 180f, false, stroke)
        }

        private fun drawCloud(c: Canvas) {
            val path=Path().apply { moveTo(-25f,9f); cubicTo(-34f,7f,-32f,-7f,-21f,-10f); cubicTo(-19f,-27f,4f,-31f,12f,-15f); cubicTo(29f,-18f,34f,1f,22f,10f); close() }
            c.drawPath(path, cloudFill); c.drawPath(path, stroke)
        }
        private fun drawRain(c: Canvas, count: Int) {
            val xs=when(count){2->listOf(-10f,10f);5->listOf(-22f,-11f,0f,11f,22f);else->listOf(-15f,0f,15f)}
            xs.forEach { x -> val p=Path().apply { moveTo(x+3f,16f); cubicTo(x+5f,21f,x+1f,29f,x-2f,28f); cubicTo(x-7f,26f,x-1f,19f,x+3f,16f); close() }; c.drawPath(p,blue); c.drawPath(p,stroke) }
        }
        private fun drawSnow(c: Canvas, count: Int) {
            val xs=when(count){2->listOf(-11f,13f);5->listOf(-22f,-11f,0f,11f,22f);else->listOf(-16f,0f,16f)}
            xs.forEach { x -> c.drawLine(x-4f,20f,x+4f,28f,blue); c.drawLine(x+4f,20f,x-4f,28f,blue); c.drawLine(x,18f,x,30f,blue) }
        }
        private fun drawHail(c: Canvas, count: Int) {
            val positions = if (count >= 5) listOf(-22f to 24f, -11f to 31f, 0f to 22f, 11f to 31f, 22f to 24f) else listOf(-15f to 25f, 0f to 31f, 15f to 25f)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(145, 215, 255); style = Paint.Style.FILL }
            val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 1.8f }
            positions.forEach { (x, y) -> c.drawCircle(x, y, 3.8f, p); c.drawCircle(x, y, 3.8f, edge) }
        }

        private fun drawLightning(c: Canvas) {
            val p=Path().apply { moveTo(5f,14f); lineTo(-8f,29f); lineTo(1f,29f); lineTo(-5f,42f); lineTo(13f,23f); lineTo(4f,23f); close() }
            c.drawPath(p,blue); c.drawPath(p,stroke)
        }
        // Draw the illuminated lunar disk from the actual illumination fraction and waxing/waning direction.
        // The terminator is an ellipse; this avoids the old overlapping-circle approximation.
        private fun drawMoon(c: Canvas, phaseFraction: Double, cx: Float = 0f, cy: Float = 0f, radius: Float = 25f) {
            val phase = ((phaseFraction % 1.0) + 1.0) % 1.0
            val angle = 2.0 * Math.PI * phase
            val terminator = kotlin.math.cos(angle).toFloat()
            val waxing = phase < 0.5
            val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(65, 73, 86); style = Paint.Style.FILL }
            val light = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(239, 242, 248); style = Paint.Style.FILL }
            val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(248, 249, 252); style = Paint.Style.STROKE; strokeWidth = 2.8f }
            val bounds = android.graphics.RectF(cx-radius, cy-radius, cx+radius, cy+radius)
            c.drawCircle(cx, cy, radius, dark)

            if (phase < 0.002 || phase > 0.998) {
                // New moon: leave the disk dark.
            } else if (phase in 0.498..0.502) {
                c.drawCircle(cx, cy, radius, light)
            } else {
                val path = Path()
                path.moveTo(cx, cy - radius)
                if (waxing) {
                    path.arcTo(bounds, -90f, 180f, false) // bright outer right half
                    path.cubicTo(
                        cx + terminator * radius, cy + radius * 0.55f,
                        cx + terminator * radius, cy - radius * 0.55f,
                        cx, cy - radius
                    )
                } else {
                    path.arcTo(bounds, -90f, -180f, false) // bright outer left half
                    path.cubicTo(
                        cx - terminator * radius, cy + radius * 0.55f,
                        cx - terminator * radius, cy - radius * 0.55f,
                        cx, cy - radius
                    )
                }
                path.close()
                c.drawPath(path, light)
            }
            // Subtle lunar maria keep the icon close to the supplied monochrome moon set.
            val maria = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(38, 70, 78, 91); style = Paint.Style.FILL }
            c.drawCircle(cx - radius * 0.30f, cy - radius * 0.20f, radius * 0.17f, maria)
            c.drawCircle(cx + radius * 0.22f, cy + radius * 0.28f, radius * 0.12f, maria)
            c.drawCircle(cx + radius * 0.30f, cy - radius * 0.36f, radius * 0.08f, maria)
            c.drawCircle(cx, cy, radius, outline)
        }

    }

    private inner class IconControlView(icon: String, private val primary: Boolean, private val action: () -> Unit) : View(this@MainActivity) {
        private var iconName = icon
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = if (primary) 3.2f else 2.8f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        init {
            background = if (primary) GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(207, 66, 119), Color.rgb(126, 39, 79))).apply {
                cornerRadius = 24f; setStroke(1, Color.rgb(239, 142, 177))
            } else GradientDrawable().apply {
                setColor(Color.rgb(57, 26, 42)); cornerRadius = 22f; setStroke(1, Color.rgb(112, 61, 82))
            }
            isClickable = true; isFocusable = true; elevation = if (primary) 5f else 2f
            contentDescription = when (icon) { "previous" -> "Предыдущий трек"; "next" -> "Следующий трек"; else -> "Воспроизведение" }
            setOnClickListener {
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(75).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                }.start()
                action()
            }
            layoutParams = LinearLayout.LayoutParams(if (primary) 82 else 68, if (primary) 68 else 60).apply { setMargins(7, 0, 7, 0) }
        }
        fun setIcon(value: String) { iconName = value; contentDescription = if (value == "pause") "Пауза" else "Воспроизведение"; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); canvas.save(); canvas.translate(width / 2f, height / 2f)
            val scale = if (primary) 1f else 0.88f; canvas.scale(scale, scale)
            paint.color = if (primary) Color.WHITE else Color.rgb(244, 218, 229)
            val path = Path()
            when (iconName) {
                "previous" -> { canvas.drawLine(-13f, -13f, -13f, 13f, paint); path.moveTo(11f,-14f); path.lineTo(-5f,0f); path.lineTo(11f,14f); canvas.drawPath(path,paint) }
                "next" -> { canvas.drawLine(13f, -13f, 13f, 13f, paint); path.moveTo(-11f,-14f); path.lineTo(5f,0f); path.lineTo(-11f,14f); canvas.drawPath(path,paint) }
                "pause" -> { paint.style=Paint.Style.FILL; canvas.drawRoundRect(-9f,-14f,-3f,14f,2f,2f,paint); canvas.drawRoundRect(3f,-14f,9f,14f,2f,2f,paint) }
                else -> { paint.style=Paint.Style.FILL; path.moveTo(-7f,-15f); path.lineTo(14f,0f); path.lineTo(-7f,15f); path.close(); canvas.drawPath(path,paint) }
            }
            paint.style = Paint.Style.STROKE; canvas.restore()
        }
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale("ru")).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now)
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
    }

    private fun syncVolumeSlider() {
        if (!::volumeFill.isInitialized || volumeFill.isTrackingTouch) return
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            volumeFill.setVolumePercent(current * 100f / max)
        } catch (_: Exception) { }
    }

    /**
     * The complete rounded panel is the volume control. Touching anywhere on it
     * changes STREAM_MUSIC volume; the colored area grows upward from the bottom.
     */
    private inner class VolumeFillView : View(this@MainActivity) {
        private val density = resources.displayMetrics.density
        private var volumePercent = 0f
        var isTrackingTouch = false
            private set

        private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(53, 18, 37)
            style = Paint.Style.FILL
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(207, 91, 128)
            style = Paint.Style.STROKE
            strokeWidth = 1.2f * density
        }
        private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 2.2f * density
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val percentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = 13f * density
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        private val bounds = android.graphics.RectF()
        private val clipPath = Path()

        init {
            elevation = 4f * density
            isClickable = true
            contentDescription = "Регулятор громкости"
        }

        fun setVolumePercent(value: Float) {
            volumePercent = value.coerceIn(0f, 100f)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val inset = 1f * density
            bounds.set(inset, inset, width - inset, height - inset)
            val radius = 30f * density
            canvas.drawRoundRect(bounds, radius, radius, panelPaint)

            clipPath.reset()
            clipPath.addRoundRect(bounds, radius, radius, Path.Direction.CW)
            val save = canvas.save()
            canvas.clipPath(clipPath)
            val fillTop = bounds.bottom - bounds.height() * (volumePercent / 100f)
            fillPaint.shader = android.graphics.LinearGradient(
                0f, bounds.bottom, 0f, fillTop.coerceAtMost(bounds.bottom),
                intArrayOf(Color.rgb(177, 39, 83), Color.rgb(244, 91, 139), Color.rgb(255, 160, 190)),
                null, android.graphics.Shader.TileMode.CLAMP
            )
            if (volumePercent > 0f) canvas.drawRect(bounds.left, fillTop, bounds.right, bounds.bottom, fillPaint)
            fillPaint.shader = null
            canvas.restoreToCount(save)
            canvas.drawRoundRect(bounds, radius, radius, borderPaint)

            // Speaker symbol and level remain legible over both filled and empty areas.
            val cx = width / 2f
            val iconCy = 35f * density
            val speaker = Path().apply {
                moveTo(cx - 13f * density, iconCy - 6f * density)
                lineTo(cx - 6f * density, iconCy - 6f * density)
                lineTo(cx + 2f * density, iconCy - 13f * density)
                lineTo(cx + 2f * density, iconCy + 13f * density)
                lineTo(cx - 6f * density, iconCy + 6f * density)
                lineTo(cx - 13f * density, iconCy + 6f * density)
                close()
            }
            canvas.drawPath(speaker, iconPaint)
            val wave = Path().apply {
                moveTo(cx + 7f * density, iconCy - 7f * density)
                quadTo(cx + 17f * density, iconCy, cx + 7f * density, iconCy + 7f * density)
            }
            canvas.drawPath(wave, iconPaint)
            canvas.drawText("${volumePercent.toInt()}%", cx, iconCy + 36f * density, percentPaint)
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN,
                android.view.MotionEvent.ACTION_MOVE -> {
                    isTrackingTouch = true
                    val percent = ((height - event.y) / height.coerceAtLeast(1) * 100f).coerceIn(0f, 100f)
                    setVolumePercent(percent)
                    val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    val target = (max * percent / 100f).toInt().coerceIn(0, max)
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                    return true
                }
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> {
                    isTrackingTouch = false
                    syncVolumeSlider()
                    performClick()
                    return true
                }
            }
            return true
        }

        override fun performClick(): Boolean {
            super.performClick()
            return true
        }
    }

    private fun refreshMedia() {
        if (!isMediaAccessGranted()) {
            controller = null
            if (lastMediaSignature != "permission_missing") {
                AppLogger.log("PERMISSIONS", "Нет специального доступа к медиасессиям; опрос приостановлен")
                lastMediaSignature = "permission_missing"
            }
            track.text = "Ожидание доступа"
            artist.text = "Разреши Black Edition доступ к уведомлениям"
            playbackLabel.text = "●  НЕТ ДОСТУПА К МЕДИАСЕССИЯМ"
            accessHint.text = "Открой настройки и включи Black Edition"
            cover.setImageDrawable(null)
            durationMs = 0
            progress.progress = 0
            playPause.setIcon("play")
            return
        }
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(this, MediaAccessService::class.java))
            val active = sessions.firstOrNull { it.packageName.contains("yandex", true) }
            controller = active
            if (active == null) {
                if (lastMediaSignature != "none") AppLogger.log("MEDIA", "Активная медиасессия Яндекс Музыки не найдена")
                lastMediaSignature = "none"
                track.text = "Ожидание музыки"
                artist.text = "Запусти Яндекс Музыку"
                playbackLabel.text = "●  МЕДИАСЕССИЯ НЕ НАЙДЕНА"
                accessHint.text = "Нет активной медиасессии"
                cover.setImageDrawable(null)
                durationMs = 0
                progress.progress = 0
                playPause.setIcon("play")
                return
            }
            val meta = active.metadata
            track.text = meta?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Без названия"
            artist.text = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "Неизвестный исполнитель"
            val bitmap: Bitmap? = meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            if (bitmap != null) cover.setImageBitmap(bitmap)
            val state = active.playbackState
            val playing = state?.state == PlaybackState.STATE_PLAYING
            val signature = "${active.packageName}|${track.text}|${artist.text}|${state?.state}"
            if (signature != lastMediaSignature) {
                AppLogger.log("MEDIA", "Плеер=${active.packageName}; трек=${track.text}; исполнитель=${artist.text}; состояние=${state?.state}")
                lastMediaSignature = signature
            }
            playbackLabel.text = if (playing) "●  ВОСПРОИЗВОДИТСЯ" else "Ⅱ  ПАУЗА"
            playbackLabel.setTextColor(if (playing) orange else muted)
            playPause.setIcon(if (playing) "pause" else "play")
            durationMs = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            currentPosition = state?.position ?: 0L
            lastPositionAt = System.currentTimeMillis()
            accessHint.text = "Яндекс Музыка подключена  ·  ${active.packageName}"
            updateProgress()
        } catch (e: SecurityException) {
            AppLogger.log("MEDIA", "Нет разрешения на чтение медиасессии", e)
            accessHint.text = "Нет доступа к медиасессии. Проверь разрешение."
        } catch (e: Exception) {
            AppLogger.log("MEDIA", "Ошибка обновления медиасессии", e)
            accessHint.text = "Ошибка медиасессии: ${e.javaClass.simpleName}"
        }
    }

    private fun updateProgress() {
        if (durationMs <= 0) {
            elapsed.text = "00:00"
            remaining.text = "00:00"
            return
        }
        val state = controller?.playbackState
        val playing = state?.state == PlaybackState.STATE_PLAYING
        val pos = if (playing) {
            currentPosition + (System.currentTimeMillis() - lastPositionAt)
        } else currentPosition
        val safe = pos.coerceIn(0, durationMs)
        if (!isSeeking) progress.progress = (safe * 1000 / durationMs).toInt()
        elapsed.text = formatTime(safe)
        remaining.text = formatTime(durationMs)
    }

    private fun togglePlayback() {
        val state = controller?.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING) command { it.pause() }
        else command { it.play() }
    }

    private fun command(action: (MediaController.TransportControls) -> Unit) {
        AppLogger.log("MEDIA", "Отправлена команда управления воспроизведением")
        val c = controller
        if (c == null) {
            accessHint.text = "Сначала запусти Яндекс Музыку"
            return
        }
        try {
            action(c.transportControls)
            handler.postDelayed({ refreshMedia() }, 450)
        } catch (e: Exception) {
            AppLogger.log("MEDIA", "Ошибка команды управления плеером", e)
            accessHint.text = "Команда не выполнена: ${e.javaClass.simpleName}"
        }
    }

    private fun refreshWeather() {
        io.execute {
            try {
                val url = URL("https://yandex-weather-proxy.mr-maloy163.workers.dev/")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                val raw = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val jsonText = raw.trim().let {
                    if (it.startsWith("{")) it
                    else it.substringAfter("(").substringBeforeLast(")").trim()
                }
                val json = JSONObject(jsonText)
                val current = json.optJSONObject("current") ?: json
                val temp = current.optDouble("temperature_2m", Double.NaN)
                    .takeIf { !it.isNaN() } ?: current.optDouble("temperature", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val wind = current.optDouble("wind_speed_10m", Double.NaN)
                val code = current.optInt("weather_code", current.optInt("weathercode", -1))
                val now = System.currentTimeMillis()
                val isDay = resolveDaylight(current, now)
                val phase = moonPhase(now)
                AppLogger.log("WEATHER", "WMO=$code, is_day=$isDay, moon=${phase.name} ${phase.illumination}%, phase=${String.format(Locale.US, "%.3f", phase.fraction)}")
                runOnUiThread {
                    weatherTemp.text = if (temp.isNaN()) "--°" else "${temp.toInt()}°"
                    val presentation = weatherPresentation(code, isDay)
                    weatherDesc.text = presentation.description
                    weatherIcon.setGlyph(presentation.glyph, phase.fraction)
                    weatherExtra.text = "Влажность ${if (humidity >= 0) "$humidity%" else "--"}   ·   Ветер ${if (wind.isNaN()) "--" else wind.toInt().toString()} м/с"
                    moonInfo.text = "ЛУНА  ·  ${phase.name}  ·  ${phase.illumination}%"
                }
            } catch (e: Exception) {
                AppLogger.log("WEATHER", "Не удалось получить текущую погоду", e)
                val now = System.currentTimeMillis()
                val isDay = resolveDaylight(JSONObject(), now)
                val phase = moonPhase(now)
                runOnUiThread {
                    weatherTemp.text = "--°"
                    weatherDesc.text = "Погода временно недоступна"
                    weatherExtra.text = "Проверь подключение к интернету"
                    weatherIcon.setGlyph(if (isDay) "cloud" else "moon", phase.fraction)
                    moonInfo.text = "ЛУНА  ·  ${phase.name}  ·  ${phase.illumination}%"
                }
            }
        }
    }

    private data class MoonPhase(
        val name: String,
        val illumination: Int,
        val fraction: Double
    )

    // Synodic phase estimate anchored to the known 2000-01-06 new moon.
    // Illumination is calculated continuously; the icon uses the same phase fraction.
    private fun moonPhase(nowMs: Long): MoonPhase {
        val synodicMonth = 29.530588853
        val knownNewMoon = 947182440000.0 // 2000-01-06 18:14 UTC
        val days = (nowMs - knownNewMoon) / 86400000.0
        val fraction = (((days % synodicMonth) + synodicMonth) % synodicMonth) / synodicMonth
        val illuminationValue = ((1.0 - kotlin.math.cos(2.0 * Math.PI * fraction)) / 2.0 * 100.0)
        val illumination = illuminationValue.toInt().coerceIn(0, 100)
        val name = when {
            illumination <= 1 -> "Новолуние"
            illumination >= 99 -> "Полнолуние"
            fraction < 0.5 && illumination in 48..52 -> "Первая четверть"
            fraction < 0.5 && illumination < 50 -> "Растущий серп"
            fraction < 0.5 -> "Растущая выпуклая"
            illumination in 48..52 -> "Последняя четверть"
            illumination < 50 -> "Убывающий серп"
            else -> "Убывающая выпуклая"
        }
        return MoonPhase(name, illumination, fraction)
    }

    private data class WeatherPresentation(val description: String, val glyph: String)

    // One source of truth: every WMO code selects both the Russian description and its SVG family.
    private fun weatherPresentation(code: Int, isDay: Boolean): WeatherPresentation = when (code) {
        0 -> WeatherPresentation("Ясно", if (isDay) "sun" else "moon")
        1 -> WeatherPresentation("Преимущественно ясно", if (isDay) "mainly_clear" else "moon_mainly_cloud")
        2 -> WeatherPresentation("Переменная облачность", if (isDay) "partly" else "moon_cloud")
        3 -> WeatherPresentation("Пасмурно", "cloud")
        45 -> WeatherPresentation("Туман", "fog")
        48 -> WeatherPresentation("Переохлаждённый туман", "fog")
        51 -> WeatherPresentation("Слабая морось", "drizzle_light")
        53 -> WeatherPresentation("Умеренная морось", "drizzle")
        55 -> WeatherPresentation("Сильная морось", "rain")
        56 -> WeatherPresentation("Слабая ледяная морось", "freezing_drizzle_light")
        57 -> WeatherPresentation("Сильная ледяная морось", "freezing_drizzle_heavy")
        61 -> WeatherPresentation("Небольшой дождь", "rain_light")
        63 -> WeatherPresentation("Умеренный дождь", "rain_moderate")
        65 -> WeatherPresentation("Сильный дождь", "rain_heavy")
        66 -> WeatherPresentation("Слабый ледяной дождь", "freezing_rain_light")
        67 -> WeatherPresentation("Сильный ледяной дождь", "freezing_rain_heavy")
        71 -> WeatherPresentation("Небольшой снег", "snow_light")
        73 -> WeatherPresentation("Умеренный снегопад", "snow_moderate")
        75 -> WeatherPresentation("Сильный снегопад", "snow_heavy")
        77 -> WeatherPresentation("Снежная крупа", "snow_grains")
        80 -> WeatherPresentation("Небольшой ливень", "rain_shower_light")
        81 -> WeatherPresentation("Умеренный ливень", "rain_shower_moderate")
        82 -> WeatherPresentation("Сильный ливень", "rain_shower_heavy")
        85 -> WeatherPresentation("Небольшой снежный заряд", "snow_shower_light")
        86 -> WeatherPresentation("Сильный снежный заряд", "snow_shower_heavy")
        95 -> WeatherPresentation("Гроза", "storm")
        96 -> WeatherPresentation("Гроза с небольшим градом", "storm_hail")
        97 -> WeatherPresentation("Сильная гроза", "storm_heavy")
        99 -> WeatherPresentation("Гроза с сильным градом", "storm_hail_heavy")
        else -> WeatherPresentation("Погодные условия не определены", "cloud")
    }

    // Open-Meteo is_day follows the local sunrise/sunset and seasonal daylight duration.
    private fun resolveDaylight(current: JSONObject, nowMs: Long): Boolean {
        if (current.has("is_day") && !current.isNull("is_day")) {
            return current.optInt("is_day", 1) == 1
        }
        val sunrise = current.optString("sunrise", "")
        val sunset = current.optString("sunset", "")
        if (sunrise.length >= 16 && sunset.length >= 16) {
            val local = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(Date(nowMs))
            val now = local.substring(11, 16)
            return now >= sunrise.substring(11, 16) && now < sunset.substring(11, 16)
        }
        // If the source omits daylight data, avoid fixed seasonal hours: use civil solar elevation approximation.
        val calendar = java.util.Calendar.getInstance()
        val hour = calendar.get(java.util.Calendar.HOUR_OF_DAY) + calendar.get(java.util.Calendar.MINUTE) / 60.0
        val dayOfYear = calendar.get(java.util.Calendar.DAY_OF_YEAR)
        val latitude = 53.1 // Syzran latitude, fallback only; normal path uses provider is_day.
        val declination = Math.toRadians(23.44) * kotlin.math.sin(2.0 * Math.PI * (284 + dayOfYear) / 365.0)
        val hourAngle = Math.toRadians((hour - 12.0) * 15.0)
        val lat = Math.toRadians(latitude)
        val sinElevation = kotlin.math.sin(lat) * kotlin.math.sin(declination) + kotlin.math.cos(lat) * kotlin.math.cos(declination) * kotlin.math.cos(hourAngle)
        return sinElevation > 0.0
    }

    private fun formatTime(ms: Long): String {
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0))
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    companion object {
        @Volatile private var current: MainActivity? = null
        fun requestRefresh() { current?.runOnUiThread { current?.refreshMedia() } }
    }

    override fun onStart() { super.onStart(); current = this }
    override fun onStop() { if (current === this) current = null; super.onStop() }
}
