package ru.blackedition.app

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lightweight diagnostic journal. Keeps a private rolling log and can export it to a user folder. */
object AppLogger {
    private const val PREFS = "black_diagnostics"
    private const val TREE_URI = "log_tree_uri"
    private const val TAG = "BlackDiagnostics"
    private const val MAX_BYTES = 1024L * 1024L
    @Volatile private var app: Context? = null
    private val lock = Any()

    fun init(context: Context) {
        app = context.applicationContext
        log("APP", "Logger initialized; version=${runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull()}")
    }

    fun setFolder(uri: Uri) {
        val c = app ?: return
        c.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(TREE_URI, uri.toString()).apply()
        log("DIAGNOSTICS", "Папка для экспорта логов выбрана")
    }

    fun log(category: String, message: String, error: Throwable? = null) {
        val c = app ?: return
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val line = buildString {
            append(stamp).append(" [").append(category).append("] ").append(message)
            if (error != null) {
                append("\n").append(Log.getStackTraceString(error))
            }
            append('\n')
        }
        synchronized(lock) {
            try {
                val file = File(c.filesDir, "black-edition-diagnostics.txt")
                if (file.exists() && file.length() > MAX_BYTES) {
                    val old = File(c.filesDir, "black-edition-diagnostics-prev.txt")
                    old.delete()
                    file.renameTo(old)
                }
                file.appendText(line)
            } catch (e: Exception) { Log.e(TAG, "Cannot write internal log", e) }
        }
        if (error != null) Log.e(TAG, message, error) else Log.d(TAG, "[$category] $message")
    }

    fun export(context: Context, destinationTree: Uri? = null): Boolean {
        val c = context.applicationContext
        val file = File(c.filesDir, "black-edition-diagnostics.txt")
        if (!file.exists()) log("DIAGNOSTICS", "Экспорт запрошен, журнал пока пуст")
        val tree = destinationTree ?: c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TREE_URI, null)?.let { Uri.parse(it) }
            ?: return false
        return try {
            val name = "BlackEdition_Log_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
            val doc = DocumentsContract.createDocument(c.contentResolver, tree, "text/plain", name) ?: return false
            c.contentResolver.openOutputStream(doc, "w")?.use { out ->
                if (file.exists()) file.inputStream().use { it.copyTo(out) }
                else out.write("Black Edition diagnostic log is empty\n".toByteArray())
            } ?: return false
            true
        } catch (e: Exception) {
            log("DIAGNOSTICS", "Не удалось экспортировать журнал", e)
            false
        }
    }

    fun clear() {
        val c = app ?: return
        synchronized(lock) { File(c.filesDir, "black-edition-diagnostics.txt").delete() }
        log("DIAGNOSTICS", "Журнал очищен пользователем")
    }

    fun installCrashHandler(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            log("FATAL", "Необработанное исключение в потоке ${thread.name}", error)
            try { export(context) } catch (_: Exception) {}
            previous?.uncaughtException(thread, error)
        }
    }
}
