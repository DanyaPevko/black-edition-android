package ru.blackedition.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

class BlackVoiceService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_START = "ru.blackedition.app.voice.START"
        const val ACTION_STOP = "ru.blackedition.app.voice.STOP"
        const val ACTION_STATUS = "ru.blackedition.app.voice.STATUS"
        const val EXTRA_STATUS = "status"
        private const val CHANNEL_ID = "black_voice_channel"
        private const val NOTIFICATION_ID = 1601
        private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip"
        private const val MODEL_DIR = "vosk-model-small-ru-0.22"
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var commandMode = false
    private var stoppedByVoice = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
        startForeground(NOTIFICATION_ID, notification("Загрузка голосового модуля"))
        broadcastStatus("ЗАГРУЗКА МОДЕЛИ")
        worker.execute { prepareModel() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stoppedByVoice = true
            stopListening()
            broadcastStatus("ВЫКЛЮЧЕН")
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("ru", "RU")
    }

    private fun prepareModel() {
        try {
            val target = File(filesDir, MODEL_DIR)
            if (!File(target, "am").exists()) {
                val archive = File(cacheDir, "vosk-model.zip")
                val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000
                    readTimeout = 60000
                    instanceFollowRedirects = true
                }
                connection.connect()
                if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
                BufferedInputStream(connection.inputStream).use { input ->
                    FileOutputStream(archive).use { output -> input.copyTo(output) }
                }
                connection.disconnect()
                val unpackRoot = File(filesDir, "vosk-unpack")
                unpackRoot.deleteRecursively()
                unpackRoot.mkdirs()
                ZipInputStream(archive.inputStream().buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val out = File(unpackRoot, entry.name)
                        if (!out.canonicalPath.startsWith(unpackRoot.canonicalPath + File.separator)) error("Invalid model archive")
                        if (entry.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { zip.copyTo(it) }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
                val extracted = File(unpackRoot, MODEL_DIR)
                if (!extracted.exists()) error("Модель не найдена в архиве")
                extracted.copyRecursively(target, overwrite = true)
                archive.delete()
                unpackRoot.deleteRecursively()
            }
            model = Model(target.absolutePath)
            main.post {
                updateNotification("Слушаю фразу «Эй, Блэк»")
                broadcastStatus("ОЖИДАНИЕ · ЭЙ, БЛЭК")
                startWakeListening()
            }
        } catch (e: Exception) {
            Log.e("BlackVoice", "Model init failed", e)
            main.post {
                broadcastStatus("ОШИБКА ЗАГРУЗКИ МОДЕЛИ")
                speak("Не удалось загрузить голосовую модель. Проверь интернет и перезапусти Black Voice.")
            }
        }
    }

    private fun startWakeListening() {
        if (stoppedByVoice || model == null) return
        try {
            speech?.stop()
            speech?.shutdown()
            val recognizer = Recognizer(model, 16000.0f, "[\"эй блэк\", \"эй блек\", \"блэк\"]")
            speech = SpeechService(recognizer, 16000.0f)
            commandMode = false
            speech?.startListening(listener)
        } catch (e: Exception) {
            Log.e("BlackVoice", "Wake listener failed", e)
            broadcastStatus("ОШИБКА МИКРОФОНА")
        }
    }

    private fun startCommandListening() {
        if (stoppedByVoice || model == null) return
        try {
            speech?.stop()
            speech?.shutdown()
            val grammar = "[\"который час\", \"сколько времени\", \"какая сегодня дата\", \"следующий трек\", \"предыдущий трек\", \"пауза\", \"останови музыку\", \"продолжи\", \"воспроизведение\", \"что сейчас играет\", \"какая погода\", \"будет дождь\", \"отключи прослушивание\", \"блэк отключи прослушивание\", \"выключи блэк\"]"
            val recognizer = Recognizer(model, 16000.0f, grammar)
            speech = SpeechService(recognizer, 16000.0f)
            commandMode = true
            broadcastStatus("СЛУШАЮ КОМАНДУ")
            updateNotification("Слушаю команду")
            speech?.startListening(listener)
            main.postDelayed({
                if (commandMode && !stoppedByVoice) {
                    speech?.stop()
                    speech?.shutdown()
                    speak("Я не расслышал команду")
                    returnToWake()
                }
            }, 7000)
        } catch (e: Exception) {
            Log.e("BlackVoice", "Command listener failed", e)
            returnToWake()
        }
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            if (!commandMode && !stoppedByVoice) {
                val text = parsePartial(hypothesis)
                if (text.contains("эй блэк") || text.contains("эй блек") || text == "блэк") {
                    commandMode = true
                    speech?.stop()
                    speech?.shutdown()
                    val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 65)
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
                    tone.release()
                    broadcastStatus("РАСПОЗНАЮ")
                    main.postDelayed({ startCommandListening() }, 180)
                }
            }
        }
        override fun onResult(hypothesis: String?) {
            if (commandMode && !stoppedByVoice) {
                val recognized = parseText(hypothesis)
                if (recognized.isNotBlank()) {
                    commandMode = false
                    speech?.stop()
                    speech?.shutdown()
                    handleCommand(recognized)
                }
            } else if (!commandMode && !stoppedByVoice) {
                val recognized = parseText(hypothesis)
                if (recognized.contains("эй блэк") || recognized.contains("эй блек")) {
                    commandMode = true
                    startCommandListening()
                }
            }
        }
        override fun onFinalResult(hypothesis: String?) { onResult(hypothesis) }
        override fun onError(exception: Exception?) {
            Log.e("BlackVoice", "Recognition error", exception)
            if (!stoppedByVoice) main.postDelayed({ if (commandMode) startCommandListening() else startWakeListening() }, 900)
        }
        override fun onTimeout() {
            if (!stoppedByVoice) {
                if (commandMode) { speak("Не расслышал") ; returnToWake() }
                else startWakeListening()
            }
        }
    }

    private fun parseText(raw: String?): String = try {
        JSONObject(raw ?: "{}").optString("text").lowercase(Locale("ru")).trim()
    } catch (_: Exception) { "" }

    private fun parsePartial(raw: String?): String = try {
        JSONObject(raw ?: "{}").optString("partial").lowercase(Locale("ru")).trim()
    } catch (_: Exception) { "" }

    private fun handleCommand(command: String) {
        broadcastStatus("ОТВЕЧАЮ")
        updateNotification("Выполняю команду")
        when {
            command.contains("отключи прослушивание") || command.contains("выключи блэк") -> {
                speak("Прослушивание отключено")
                main.postDelayed({
                    stoppedByVoice = true
                    stopListening()
                    broadcastStatus("ВЫКЛЮЧЕН")
                    stopForeground(true)
                    stopSelf()
                }, 1500)
                return
            }
            command.contains("который час") || command.contains("сколько времени") -> {
                val time = java.text.SimpleDateFormat("H:mm", Locale("ru")).format(Date())
                speak("Сейчас $time")
            }
            command.contains("какая сегодня дата") -> {
                val date = java.text.SimpleDateFormat("d MMMM yyyy года", Locale("ru")).format(Date())
                speak("Сегодня $date")
            }
            command.contains("следующий трек") -> { mediaCommand { it.skipToNext() }; speak("Следующий трек") }
            command.contains("предыдущий трек") -> { mediaCommand { it.skipToPrevious() }; speak("Предыдущий трек") }
            command.contains("пауза") || command.contains("останови музыку") -> { mediaCommand { it.pause() }; speak("Музыка на паузе") }
            command.contains("продолжи") || command.contains("воспроизведение") -> { mediaCommand { it.play() }; speak("Продолжаю воспроизведение") }
            command.contains("что сейчас играет") -> speak(currentTrack())
            command.contains("какая погода") -> speak("Чтобы назвать погоду, открой Black Edition. Данные погоды отображаются на главном экране.")
            command.contains("будет дождь") -> speak("Прогноз дождя пока не подключён. Эта команда появится в следующем обновлении.")
            else -> speak("Команда пока не поддерживается")
        }
    }

    private fun mediaCommand(action: (MediaController.TransportControls) -> Unit) {
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(this, MediaAccessService::class.java))
            val controller = sessions.firstOrNull { it.packageName.contains("yandex", true) }
            if (controller == null) speak("Яндекс Музыка не подключена") else action(controller.transportControls)
        } catch (e: Exception) { Log.e("BlackVoice", "Media command failed", e) }
    }

    private fun currentTrack(): String {
        return try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val c = manager.getActiveSessions(ComponentName(this, MediaAccessService::class.java))
                .firstOrNull { it.packageName.contains("yandex", true) }
            val title = c?.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
            val artist = c?.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
            if (title.isNullOrBlank()) "Сейчас ничего не играет" else "Сейчас играет $title, исполнитель $artist"
        } catch (_: Exception) { "Не удалось получить информацию о треке" }
    }

    private fun speak(text: String) {
        broadcastStatus("ОТВЕЧАЮ")
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "black_voice_reply")
        val delay = (text.length * 65L).coerceIn(1800L, 5000L)
        main.postDelayed({ returnToWake() }, delay)
    }

    private fun returnToWake() {
        if (stoppedByVoice) return
        broadcastStatus("ОЖИДАНИЕ · ЭЙ, БЛЭК")
        updateNotification("Слушаю фразу «Эй, Блэк»")
        main.postDelayed({ startWakeListening() }, 500)
    }

    private fun stopListening() {
        try { speech?.stop(); speech?.shutdown() } catch (_: Exception) {}
        speech = null
    }

    private fun broadcastStatus(value: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_STATUS, value))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Black Voice", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Постоянное прослушивание фразы активации Эй, Блэк"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Black Voice активен").setContentText(message)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(open).setOngoing(true).build()
    }

    private fun updateNotification(message: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(message))
    }

    override fun onDestroy() {
        stoppedByVoice = true
        stopListening()
        model?.close()
        tts?.stop(); tts?.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }
}
