package ru.blackedition.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors

/** Checks public GitHub Releases and downloads a verified APK. Android still asks the user to confirm installation. */
object AppUpdater {
    private const val RELEASE_API = "https://api.github.com/repos/DanyaPevko/black-edition-android/releases/latest"
    private const val UPDATE_MANIFEST = "black-edition-update.json"
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val apkAsset: String,
        val sha256: String,
        val notes: String,
        val downloadUrl: String
    )

    fun check(callback: (Result<UpdateInfo?>) -> Unit) {
        executor.execute {
            val result = runCatching {
                val release = getJson(RELEASE_API)
                val assets = release.optJSONArray("assets") ?: error("В релизе нет файлов")
                var manifestUrl: String? = null
                var apkUrl: String? = null
                for (i in 0 until assets.length()) {
                    val asset = assets.getJSONObject(i)
                    when (asset.optString("name")) {
                        UPDATE_MANIFEST -> manifestUrl = asset.optString("browser_download_url")
                    }
                }
                val url = manifestUrl ?: error("В релизе отсутствует $UPDATE_MANIFEST")
                val manifest = getJson(url)
                val apkName = manifest.getString("apkAsset")
                for (i in 0 until assets.length()) {
                    val asset = assets.getJSONObject(i)
                    if (asset.optString("name") == apkName) apkUrl = asset.optString("browser_download_url")
                }
                UpdateInfo(
                    versionCode = manifest.getInt("versionCode"),
                    versionName = manifest.getString("versionName"),
                    apkAsset = apkName,
                    sha256 = manifest.getString("sha256").lowercase(Locale.US),
                    notes = manifest.optString("notes", "Исправления и улучшения Black Edition"),
                    downloadUrl = apkUrl ?: error("APK $apkName отсутствует в релизе")
                )
            }
            main.post { callback(result) }
        }
    }

    fun download(context: Context, update: UpdateInfo, onProgress: (Int) -> Unit, callback: (Result<File>) -> Unit) {
        executor.execute {
            val result = runCatching {
                val directory = File(context.cacheDir, "updates").apply { mkdirs() }
                val target = File(directory, update.apkAsset)
                val connection = (URL(update.downloadUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000
                    readTimeout = 30000
                    setRequestProperty("User-Agent", "BlackEdition-Android-Updater")
                    instanceFollowRedirects = true
                }
                try {
                    connection.connect()
                    if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode} при загрузке APK")
                    val total = connection.contentLengthLong
                    var received = 0L
                    connection.inputStream.use { input ->
                        FileOutputStream(target).use { output ->
                            val buffer = ByteArray(16 * 1024)
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                                received += count
                                if (total > 0) {
                                    val percent = ((received * 100) / total).toInt().coerceIn(0, 100)
                                    main.post { onProgress(percent) }
                                }
                            }
                            output.fd.sync()
                        }
                    }
                } finally {
                    connection.disconnect()
                }
                val actual = sha256(target)
                if (!actual.equals(update.sha256, ignoreCase = true)) {
                    target.delete()
                    error("Контрольная сумма APK не совпала. Файл удалён")
                }
                target
            }
            main.post { callback(result) }
        }
    }

    fun installerIntent(context: Context, apk: File): Intent {
        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun getJson(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "BlackEdition-Android-Updater")
            instanceFollowRedirects = true
        }
        try {
            if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode} при проверке обновления")
            return JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
        } finally {
            connection.disconnect()
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(16 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
