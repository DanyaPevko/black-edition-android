package ru.blackedition.app

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lightweight diagnostic journal. Keeps a private rolling log and can export it to a user folder. */
object AppLogger {
    private const val PREFS = "black_diagnostics"
    private const val TREE_URI = "log_tree_uri"
    private const val TAG = "BlackDiagnostics"
    private const val MAX_BYTES = 1024L * 1024L
    @Volatile private var app: Context? = null
    private val lock = Any()

    fun init(context: Context) {
        app = context.applicationContext
        log("APP", "Logger initialized; version=${runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull()}")
    }

    fun setFolder(uri: Uri, grantedFlags: Int) {
        val c = app ?: throw IllegalStateException("Logger is not initialized")
        val persistableFlags = grantedFlags and (android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        if (persistableFlags == 0) throw SecurityException("Android не выдал доступ к выбранной папке")
        c.contentResolver.takePersistableUriPermission(uri, persistableFlags)
        val saved = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(TREE_URI, uri.toString()).commit()
        if (!saved) throw IllegalStateException("Не удалось сохранить URI папки")
        val persisted = c.contentResolver.persistedUriPermissions.any { it.uri == uri && (it.isReadPermission || it.isWritePermission) }
        if (!persisted) throw SecurityException("Android не сохранил постоянное разрешение")
        log("DIAGNOSTICS", "Папка для экспорта логов выбрана: $uri; flags=$persistableFlags")
    }

    fun selectedFolder(context: Context): Uri? {
        val c = context.applicationContext
        val raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TREE_URI, null) ?: return null
        val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return null
        return if (c.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isWritePermission }) uri else null
    }

    fun log(category: String, message: String, error: Throwable? = null) {
        val c = app ?: return
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val line = buildString {
            append(stamp).append(" [").append(category).append("] ").append(message)
            if (error != null) {
                append("\n").append(Log.getStackTraceString(error))
            }
            append('\n')
        }
        synchronized(lock) {
            try {
                val file = File(c.filesDir, "black-edition-diagnostics.txt")
                if (file.exists() && file.length() > MAX_BYTES) {
                    val old = File(c.filesDir, "black-edition-diagnostics-prev.txt")
                    old.delete()
                    file.renameTo(old)
                }
                file.appendText(line)
            } catch (e: Exception) { Log.e(TAG, "Cannot write internal log", e) }
        }
        if (error != null) Log.e(TAG, message, error) else Log.d(TAG, "[$category] $message")
    }

    fun export(context: Context, destinationTree: Uri? = null): Boolean {
        val c = context.applicationContext
        val file = File(c.filesDir, "black-edition-diagnostics.txt")
        val tree = destinationTree ?: selectedFolder(c) ?: run {
            log("DIAGNOSTICS", "Экспорт невозможен: папка не выбрана или нет постоянного разрешения")
            return false
        }
        return try {
            val treeId = DocumentsContract.getTreeDocumentId(tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, treeId)
            val name = "BlackEdition_Log_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
            val doc = DocumentsContract.createDocument(c.contentResolver, parent, "text/plain", name)
                ?: throw IllegalStateException("Провайдер файлов не создал TXT-файл")
            val output = c.contentResolver.openOutputStream(doc, "w")
                ?: throw IllegalStateException("Не удалось открыть созданный TXT-файл")
            output.use { out ->
                if (file.exists()) file.inputStream().use { it.copyTo(out) }
                else out.write("Black Edition diagnostic log is empty\n".toByteArray())
            }
            log("DIAGNOSTICS", "Журнал экспортирован: $doc")
            true
        } catch (e: Exception) {
            log("DIAGNOSTICS", "Ошибка экспорта журнала: ${e.javaClass.simpleName}: ${e.message}", e)
            false
        }
    }

    fun testFolder(context: Context): Boolean {
        log("DIAGNOSTICS", "Проверка выбранной папки начата")
        return export(context)
    }

    fun clear() {
        val c = app ?: return
        synchronized(lock) { File(c.filesDir, "black-edition-diagnostics.txt").delete() }
        log("DIAGNOSTICS", "Журнал очищен пользователем")
    }

    fun installCrashHandler(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            log("FATAL", "Необработанное исключение в потоке ${thread.name}", error)
            try { export(context) } catch (_: Exception) {}
            previous?.uncaughtException(thread, error)
        }
    }
}
