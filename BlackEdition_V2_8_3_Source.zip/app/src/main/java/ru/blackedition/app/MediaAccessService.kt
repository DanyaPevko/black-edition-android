package ru.blackedition.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MediaAccessService : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        MainActivity.requestRefresh()
    }
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        MainActivity.requestRefresh()
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        MainActivity.requestRefresh()
    }
}
