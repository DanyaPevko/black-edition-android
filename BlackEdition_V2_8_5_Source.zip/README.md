# Black Edition 2.8.5

- Исправлена адаптация интерфейса в альбомной ориентации телефона.
- Главный экран: увеличены регулятор громкости и нижние кнопки в горизонтальном режиме телефона.
- Календарь: в горизонтальном режиме телефона используется широкая компоновка с календарём и выбранной датой в отдельных колонках.
- Погода: в горизонтальном режиме телефона текущая погода и прогноз на 7 дней размещаются рядом; список прогноза компактнее и прокручивается независимо.
- Версия обновлена до 2.8.5 (`versionCode = 33`).

# Black Edition 2.8.3

- Версия обновлена до 2.8.3 (`versionCode = 26`).
- Добавлен полноэкранный экран прогноза погоды на 7 дней.
- Нажатие на погодную карточку главного экрана открывает прогноз.
- Экран показывает текущую погоду и дневной прогноз: погодное описание, максимальную/минимальную температуру, вероятность осадков и ветер.
- База: исходники Black Edition 2.7.7.

- Добавлена нижняя подпись `PEVKO_PROD` на главном экране.
- Версия обновлена до 2.7.6 (`versionCode = 24`).
- Остальные функции без изменений относительно 2.7.5.

# Black Edition V2.7 — встроенное обновление

Версия приложения: `2.7.6` (`versionCode = 24`). База: Black Edition V2.7.5.

## Что добавлено

- Автоматическая проверка опубликованного GitHub Release не чаще одного раза в 24 часа.
- Ручная проверка через `НАСТРОЙКИ → Проверить обновления`.
- Диалог с номером версии и описанием изменений.
- Загрузка APK внутри приложения с отображением прогресса.
- Проверка SHA-256 до передачи файла установщику Android.
- Установка через системный установщик Android. Подтверждение пользователя обязательно; приложение не пытается обходить системную защиту.
- APK хранится в приватном cache каталоге и передаётся установщику через AndroidX FileProvider.
- Публикация подписанных APK в GitHub Releases по тегам `v*`.

## ВАЖНО: постоянная подпись

Для обновления поверх уже установленного приложения Android требует, чтобы APK был подписан тем же ключом, что и установленная версия. До V2.7 workflow собирал `assembleDebug` на GitHub-hosted runner. Временный debug-ключ runner не является постоянным. Поэтому первый переход на V2.7 Release требует однократной миграции: экспортировать нужные журналы, удалить старую установку Black Edition и установить новый подписанный APK. Локальные данные приложения при удалении будут очищены (`allowBackup=false`). После этой миграции все будущие APK должны подписываться только сохранённым Release-ключом.

## Настройка GitHub Actions secrets (один раз)

В репозитории `DanyaPevko/black-edition-android` открой:

`Settings → Secrets and variables → Actions → New repository secret`

Создай четыре Actions secrets. Значения находятся в отдельном файле `BlackEdition_GitHub_Secrets.txt`, который передан отдельно от исходников:

- `KEYSTORE_BASE64`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

`KEYSTORE_BASE64` — это всё содержимое строки после соответствующего имени в файле секретов. Остальные три значения копируются целиком.

**Никогда не загружай `BlackEdition_Release_Keystore.jks` или `BlackEdition_GitHub_Secrets.txt` в репозиторий.** Храни резервную копию JKS и секретов отдельно. Потеря ключа означает невозможность выпускать совместимые обновления для уже установленной версии.

## Как выпускать обновления

1. Загрузить ZIP исходников в корень репозитория (старый ZIP перед этим удалить), commit в `main`.
2. Обычный push в `main` собирает Debug APK как тестовый артефакт.
3. Для пользовательского обновления создать и опубликовать GitHub Release с тегом вида `v2.7`, `v2.8` и т.д. Тег должен указывать на commit, содержащий соответствующие исходники и `versionCode`/`versionName`.
4. Push тега запускает Release-сборку. Workflow подписывает APK, рассчитывает SHA-256, создаёт `black-edition-update.json` и прикрепляет оба файла к GitHub Release.
5. Приложение проверяет `https://api.github.com/repos/DanyaPevko/black-edition-android/releases/latest`, скачивает manifest и APK из последнего публичного релиза.

Для каждой следующей версии обязательно увеличивать `versionCode`. `versionName` — отображаемая версия.

## Разрешение на установку

На Android 8+ пользователь один раз разрешает Black Edition установку неизвестных приложений в системных настройках. Каждая установка/обновление затем требует подтверждения Android Package Installer. Это штатное ограничение Android.

## Проверки, выполненные при подготовке

- Проверена структура проекта и наличие `FileProvider` paths.
- Проверены имена секретов и согласованность имён release assets/manifest в workflow и клиенте.
- Проверены целостность JKS и соответствие alias.
- Полная Gradle-сборка здесь не запускалась: в рабочей среде нет Android SDK/Gradle toolchain. Итоговую компиляцию нужно проверить GitHub Actions.


## 2.8.3 — Adaptive layouts
- Added responsive tablet layout for calendar: calendar and selected-date panel side by side.
- Added responsive tablet layout for weather: current conditions and 7-day forecast in two columns.
- Phone layout remains vertically stacked.


## 2.8.3 — Global adaptive UI
- Added centralized screen metrics/profile (compact phone, phone, tablet, large tablet).
- Added adaptive density-based sizing helpers and global text scaling.
- Main dashboard, calendar and weather use the centralized adaptive profile.
- Tablet sizing scales spacing, typography and key components; future screens can use the same helpers.


## 2.8.3 — Sensor landscape orientation
- App is locked to landscape, but supports both landscape directions (rotation 180°) based on device sensor.
- Portrait orientation is not supported for the app UI.

## 2.8.3 — Main screen adaptive layout
- Adaptive classification now uses smallestScreenWidthDp, preventing phones in landscape from being treated as tablets.
- Main screen compact profile for phones: reduced clock/weather typography, card padding, player cover, player controls, volume panel, and footer controls.
- Tablet layout retains its existing spacious profile.
- Calendar and weather screens are intentionally unchanged.
