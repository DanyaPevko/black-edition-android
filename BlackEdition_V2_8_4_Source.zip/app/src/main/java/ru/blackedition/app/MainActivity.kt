package ru.blackedition.app

import android.app.Activity
import android.app.Dialog
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Settings.Secure
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CalendarView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ProgressBar
import android.widget.TextView
import org.json.JSONObject
import com.caverock.androidsvg.SVG
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 14, 29)
    private val panel = Color.rgb(43, 13, 27)
    private val orange = Color.rgb(239, 78, 111)
    private val muted = Color.rgb(190, 174, 185)
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var controller: MediaController? = null
    private var durationMs = 0L
    private var currentPosition = 0L
    private var lastPositionAt = 0L
    private var isSeeking = false
    private var lastMediaSignature = ""
    private val requestLogFolder = 2701

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherTemp: TextView
    private lateinit var weatherDesc: TextView
    private lateinit var weatherExtra: TextView
    private lateinit var moonInfo: TextView
    private lateinit var weatherIcon: GlyphView
    private var forecastDaily: JSONObject? = null
    private lateinit var cover: ImageView
    private lateinit var track: TextView
    private lateinit var artist: TextView
    private lateinit var playbackLabel: TextView
    private lateinit var progress: SeekBar
    private lateinit var volumeFill: VolumeFillView
    private lateinit var elapsed: TextView
    private lateinit var remaining: TextView
    private lateinit var accessHint: TextView
    private lateinit var playPause: IconControlView
    private lateinit var voiceStatus: TextView
    private lateinit var voiceButton: IconActionView
    private var voiceEnabled = false
    private var voiceReceiverRegistered = false
    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BlackVoiceService.ACTION_STATUS) {
                val value = intent.getStringExtra(BlackVoiceService.EXTRA_STATUS) ?: ""
                AppLogger.log("VOICE", "Статус Black Voice: $value")
                voiceStatus.text = "BLACK VOICE: $value"
                voiceEnabled = value != "ВЫКЛЮЧЕН"
                voiceButton.invalidate()
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            updateProgress()
            refreshMedia()
            syncVolumeSlider()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLogger.init(this)
        AppLogger.installCrashHandler(this)
        AppLogger.log("LIFECYCLE", "MainActivity onCreate")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        buildUi()
        registerVoiceReceiver()
        showFirstRunSetupIfNeeded()
        updateClock()
        refreshWeather()
        refreshMedia()
        maybeCheckForUpdates(false)
    }

    override fun onResume() {
        super.onResume()
        AppLogger.log("LIFECYCLE", "MainActivity onResume")
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        tryPendingUpdateInstall()
    }

    override fun onPause() {
        AppLogger.log("LIFECYCLE", "MainActivity onPause")
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        AppLogger.log("LIFECYCLE", "MainActivity onDestroy")
        if (voiceReceiverRegistered) { try { unregisterReceiver(voiceReceiver) } catch (_: Exception) {} }
        io.shutdownNow()
        super.onDestroy()
    }

    private fun registerVoiceReceiver() {
        val filter = IntentFilter(BlackVoiceService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(voiceReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(voiceReceiver, filter)
        voiceReceiverRegistered = true
    }

    private fun isMediaAccessGranted(): Boolean {
        return try {
            val enabled = Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
            enabled.split(":").any { ComponentName.unflattenFromString(it) == ComponentName(this, MediaAccessService::class.java) }
        } catch (e: Exception) {
            AppLogger.log("PERMISSIONS", "Не удалось проверить доступ к медиасессиям", e)
            false
        }
    }

    private fun showFirstRunSetupIfNeeded() {
        val prefs = getSharedPreferences("black_setup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("intro_shown", false)) return
        android.app.AlertDialog.Builder(this)
            .setTitle("Первичная настройка Black Edition")
            .setMessage("Для голосового управления нужен доступ к микрофону. Для управления Яндекс Музыкой нужен специальный доступ к уведомлениям и медиасессиям. Android попросит включить его отдельно в системных настройках. Интернет используется для загрузки голосовой модели и погоды.")
            .setCancelable(false)
            .setPositiveButton("НАСТРОИТЬ") { _, _ ->
                prefs.edit().putBoolean("intro_shown", true).apply()
                if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1601)
                } else {
                    openMediaAccessSettingsIfNeeded()
                }
            }
            .setNegativeButton("ПОЗЖЕ") { _, _ -> prefs.edit().putBoolean("intro_shown", true).apply() }
            .show()
    }

    private fun openMediaAccessSettingsIfNeeded() {
        if (isMediaAccessGranted()) {
            AppLogger.log("PERMISSIONS", "Доступ к уведомлениям и медиасессиям уже включён")
            refreshMedia()
            return
        }
        AppLogger.log("PERMISSIONS", "Открываем системную настройку доступа к уведомлениям")
        voiceStatus.text = "BLACK VOICE: НУЖЕН ДОСТУП К МЕДИАСЕССИЯМ"
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            AppLogger.log("PERMISSIONS", "Не удалось открыть настройки доступа к уведомлениям", e)
        }
    }

    private fun toggleBlackVoice() {
        AppLogger.log("VOICE", "Нажата кнопка управления Black Voice")
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1601)
            return
        }
        val stopping = voiceEnabled
        if (!stopping && !isMediaAccessGranted()) {
            openMediaAccessSettingsIfNeeded()
            return
        }
        if (!stopping && Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            voiceStatus.text = "BLACK VOICE: НУЖНО РАЗРЕШЕНИЕ ДЛЯ ЯРКОСТИ"
            val settingsIntent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = android.net.Uri.parse("package:$packageName")
            }
            startActivity(settingsIntent)
            return
        }
        val intent = Intent(this, BlackVoiceService::class.java)
        if (voiceEnabled) {
            AppLogger.log("VOICE", "Запрошена остановка голосового сервиса")
            intent.action = BlackVoiceService.ACTION_STOP
            startService(intent)
            voiceEnabled = false
            voiceButton.invalidate()
            voiceStatus.text = "BLACK VOICE: ВЫКЛЮЧЕН"
        } else {
            AppLogger.log("VOICE", "Запрошен запуск голосового сервиса")
            intent.action = BlackVoiceService.ACTION_START
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            voiceEnabled = true
            voiceButton.invalidate()
            voiceStatus.text = "BLACK VOICE: ЗАПУСКАЮСЬ"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1601 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AppLogger.log("PERMISSIONS", "Доступ к микрофону выдан")
            openMediaAccessSettingsIfNeeded()
        } else if (requestCode == 1601) {
            voiceStatus.text = "BLACK VOICE: НУЖЕН ДОСТУП К МИКРОФОНУ"
            AppLogger.log("PERMISSIONS", "Пользователь не выдал доступ к микрофону")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestLogFolder && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val grantedFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                AppLogger.setFolder(uri, grantedFlags)
                val testOk = AppLogger.testFolder(this)
                android.widget.Toast.makeText(this,
                    if (testOk) "Папка выбрана и проверена: тестовый TXT сохранён" else "Доступ сохранён, но тестовая запись не удалась. Проверь папку через «ЛОГИ»",
                    android.widget.Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                AppLogger.log("DIAGNOSTICS", "Ошибка выбора папки", e)
                android.widget.Toast.makeText(this, "Не удалось сохранить папку", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun dialogSurface(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 20, 24, 20)
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(12, 18, 35), Color.rgb(43, 10, 28), Color.rgb(20, 12, 32))).apply {
            cornerRadius = 28f; setStroke(1, Color.rgb(145, 45, 82))
        }
    }

    private fun dialogHeader(title: String, subtitle: String? = null): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, 16) }
        box.addView(text(title, 22f, Color.rgb(255, 126, 174), true))
        if (!subtitle.isNullOrBlank()) box.addView(text(subtitle, 12f, muted).apply { setPadding(0, 8, 0, 0) })
        return box
    }

    private fun dialogRow(title: String, detail: String, action: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 15, 18, 15); isClickable = true; isFocusable = true
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(52, 18, 39), Color.rgb(31, 17, 37))).apply { cornerRadius = 18f; setStroke(1, Color.rgb(105, 42, 65)) }
            setOnClickListener { action() }
        }
        row.addView(text(title, 16f, Color.WHITE, true))
        row.addView(text(detail, 12f, muted).apply { setPadding(0, 6, 0, 0) })
        return row
    }

    private fun showDiagnostics() {
        val content = dialogSurface()
        content.addView(dialogHeader("ДИАГНОСТИКА", "Инструменты Black Edition"))
        val dialog = android.app.AlertDialog.Builder(this).setView(content).create()
        content.addView(dialogRow("Выбрать папку для логов", "Указать место сохранения журналов") {
            dialog.dismiss(); val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            startActivityForResult(intent, requestLogFolder)
        })
        content.addView(dialogRow("Проверить запись", "Создать тестовый TXT-файл") {
            val ok = AppLogger.testFolder(this); dialog.dismiss()
            android.widget.Toast.makeText(this, if (ok) "Проверка успешна: TXT-файл создан" else "Не удалось записать тестовый файл. Проверь разрешение и выбранную папку.", android.widget.Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        content.addView(dialogRow("Сохранить журнал", "Экспортировать текущий журнал") {
            val ok = AppLogger.export(this); dialog.dismiss()
            android.widget.Toast.makeText(this, if (ok) "Журнал сохранён" else "Ошибка сохранения. Выбери папку заново или проверь разрешение.", android.widget.Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        content.addView(dialogRow("Очистить журнал", "Удалить накопленные записи") {
            dialog.dismiss(); themedConfirm("Очистить журнал?", "Текущий журнал диагностики будет удалён.", "ОЧИСТИТЬ") { AppLogger.clear() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        dialog.show()
    }

    private fun themedConfirm(title: String, message: String, positive: String, action: () -> Unit) {
        val content = dialogSurface(); content.addView(dialogHeader(title, message))
        android.app.AlertDialog.Builder(this).setView(content)
            .setNegativeButton("ОТМЕНА", null).setPositiveButton(positive) { _, _ -> action() }.show()
    }

    private fun showSettingsDialog() {
        val content = dialogSurface()
        content.addView(dialogHeader("BLACK EDITION", "ЦЕНТР УПРАВЛЕНИЯ"))
        val dialog = android.app.AlertDialog.Builder(this).setView(content).create()
        content.addView(dialogRow("Проверить обновления", "Поиск новой версии приложения") { dialog.dismiss(); maybeCheckForUpdates(true) })
        content.addView(dialogRow("Доступ к медиасессиям", "Настройка управления музыкой") { dialog.dismiss(); startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        content.addView(dialogRow("Диагностика и журналы", "Логи, экспорт и проверка записи") { dialog.dismiss(); showDiagnostics() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        content.addView(text("BLACK EDITION  •  СЛУЖЕБНЫЕ НАСТРОЙКИ", 10f, muted).apply { gravity = Gravity.CENTER; setPadding(0, if (isTabletLayout) 18 else 4, 0, 0) })
        dialog.show()
    }

    private fun rounded(color: Int, radius: Float = 22f) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun burgundyCard(radius: Float = 26f) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(35, 10, 22), Color.rgb(69, 17, 39), Color.rgb(37, 14, 31))
    ).apply {
        cornerRadius = radius
        setStroke(1, Color.rgb(91, 35, 54))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = adaptiveSp(size)
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            includeFontPadding = false
        }


    private fun installedVersionCode(): Int {
        return try {
            val info = packageManager.getPackageInfo(packageName, 0)
            @Suppress("DEPRECATION")
            val legacyCode = info.versionCode
            if (Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt() else legacyCode
        } catch (_: Exception) { 0 }
    }

    private fun maybeCheckForUpdates(force: Boolean) {
        val prefs = getSharedPreferences("black_updates", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong("last_check", 0L)
        if (!force && now - last < 24L * 60L * 60L * 1000L) return
        AppLogger.log("UPDATER", if (force) "Ручная проверка обновлений" else "Автоматическая проверка обновлений")
        if (force) android.widget.Toast.makeText(this, "Проверяем обновления…", android.widget.Toast.LENGTH_SHORT).show()
        AppUpdater.check { result ->
            result.onFailure { error ->
                AppLogger.log("UPDATER", "Ошибка проверки обновления", error)
                if (force && !isFinishing) android.app.AlertDialog.Builder(this)
                    .setTitle("Не удалось проверить обновления")
                    .setMessage(error.message ?: "Проверь подключение к интернету")
                    .setPositiveButton("ПОНЯТНО", null).show()
            }
            result.onSuccess { update ->
                prefs.edit().putLong("last_check", System.currentTimeMillis()).apply()
                if (update == null) return@onSuccess
                val current = installedVersionCode()
                AppLogger.log("UPDATER", "Найдена версия ${update.versionName}, code=${update.versionCode}; установлена code=$current")
                if (update.versionCode <= current) {
                    if (force && !isFinishing) android.app.AlertDialog.Builder(this)
                        .setTitle("Обновлений нет")
                        .setMessage("Установлена актуальная версия Black Edition.")
                        .setPositiveButton("ОТЛИЧНО", null).show()
                    return@onSuccess
                }
                if (!isFinishing) showUpdateAvailable(update)
            }
        }
    }

    private fun showUpdateAvailable(update: AppUpdater.UpdateInfo) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Доступно обновление ${update.versionName}")
            .setMessage(update.notes.ifBlank { "Доступна новая версия Black Edition." })
            .setNegativeButton("ПОЗЖЕ", null)
            .setPositiveButton("СКАЧАТЬ") { _, _ -> downloadUpdate(update) }
            .show()
    }

    private fun downloadUpdate(update: AppUpdater.UpdateInfo) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 8)
        }
        val label = text("Подготовка загрузки…", 14f, Color.WHITE)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0 }
        layout.addView(label)
        layout.addView(bar, LinearLayout.LayoutParams(-1, 18).apply { topMargin = 16 })
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Загрузка Black Edition ${update.versionName}")
            .setView(layout)
            .create()
        dialog.setCancelable(false)
        dialog.show()
        AppUpdater.download(this, update, { percent ->
            if (dialog.isShowing) {
                bar.progress = percent
                label.text = "Загрузка: $percent%"
            }
        }) { result ->
            if (!dialog.isShowing && result.isSuccess) return@download
            result.onFailure { error ->
                if (dialog.isShowing) dialog.dismiss()
                AppLogger.log("UPDATER", "Ошибка загрузки или проверки APK", error)
                if (!isFinishing) android.app.AlertDialog.Builder(this)
                    .setTitle("Ошибка обновления")
                    .setMessage(error.message ?: "Не удалось загрузить APK")
                    .setPositiveButton("ЗАКРЫТЬ", null).show()
            }
            result.onSuccess { apk ->
                if (dialog.isShowing) dialog.dismiss()
                getSharedPreferences("black_updates", Context.MODE_PRIVATE).edit()
                    .putString("pending_apk", apk.absolutePath).apply()
                launchUpdateInstaller(apk)
            }
        }
    }

    private fun launchUpdateInstaller(apk: java.io.File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Разрешение на установку")
                .setMessage("Разреши Black Edition устанавливать обновления из этого источника. Android откроет системную настройку. После возвращения установка продолжится.")
                .setNegativeButton("ПОЗЖЕ", null)
                .setPositiveButton("ОТКРЫТЬ НАСТРОЙКИ") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                            data = android.net.Uri.parse("package:$packageName")
                        })
                    } catch (e: Exception) {
                        AppLogger.log("UPDATER", "Не удалось открыть настройку установки неизвестных приложений", e)
                    }
                }.show()
            return
        }
        try {
            AppLogger.log("UPDATER", "Передаём проверенный APK системному установщику: ${apk.name}")
            startActivity(AppUpdater.installerIntent(this, apk))
        } catch (e: Exception) {
            AppLogger.log("UPDATER", "Не удалось открыть системный установщик", e)
            android.app.AlertDialog.Builder(this).setTitle("Не удалось открыть установщик")
                .setMessage(e.message ?: "Проверь разрешение на установку приложений")
                .setPositiveButton("ЗАКРЫТЬ", null).show()
        }
    }

    private fun tryPendingUpdateInstall() {
        val prefs = getSharedPreferences("black_updates", Context.MODE_PRIVATE)
        val path = prefs.getString("pending_apk", null) ?: return
        val apk = java.io.File(path)
        if (!apk.exists()) {
            prefs.edit().remove("pending_apk").apply()
            return
        }
        if (Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls()) {
            prefs.edit().remove("pending_apk").apply()
            launchUpdateInstaller(apk)
        }
    }

    // Global adaptive layout profile. All screens use this instead of device-specific checks.
    private val screenWidthDp: Int get() = resources.configuration.screenWidthDp
    private val screenHeightDp: Int get() = resources.configuration.screenHeightDp
    // smallestScreenWidthDp avoids classifying a phone in landscape as a tablet.
    private val smallestWidthDp: Int get() = resources.configuration.smallestScreenWidthDp
    private val isTabletLayout: Boolean get() = smallestWidthDp >= 600
    private val isCompactMain: Boolean get() = smallestWidthDp < 420
    private val adaptiveScale: Float get() = when {
        smallestWidthDp >= 900 -> 1.25f
        smallestWidthDp >= 720 -> 1.18f
        smallestWidthDp >= 600 -> 1.10f
        else -> 1.0f
    }
    private fun adaptiveDp(value: Int): Int = (value * adaptiveScale).toInt()
    private fun adaptiveSp(value: Float): Float = value * adaptiveScale
    private val screenClass: String get() = when {
        smallestWidthDp >= 900 -> "large_tablet"
        smallestWidthDp >= 600 -> "tablet"
        smallestWidthDp < 360 -> "compact_phone"
        else -> "phone"
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(if (isTabletLayout) 28 else 14, if (isTabletLayout) 22 else 12, if (isTabletLayout) 28 else 14, if (isTabletLayout) 22 else 12)
            setBackgroundColor(bg)
        }

        // Верхняя половина: два равных самостоятельных блока.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val dateCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(if (isTabletLayout) 28 else 16, if (isTabletLayout) 22 else 12, if (isTabletLayout) 28 else 16, if (isTabletLayout) 22 else 12)
            background = burgundyCard(if (isTabletLayout) 26f else 18f)
        }
        dateCard.addView(text("BLACK EDITION  /  SYZRAN", 13f, orange, true))
        clock = text("--:--", if (isTabletLayout) 76f else 48f, Color.WHITE, true)
        date = text("Загрузка даты", if (isTabletLayout) 21f else 16f, muted)
        dateCard.addView(clock)
        dateCard.addView(date)
        dateCard.isClickable = true
        dateCard.isFocusable = true
        dateCard.setOnClickListener { showCalendarScreen() }
        top.addView(dateCard, LinearLayout.LayoutParams(0, -1, 1f))

        val gap = View(this)
        top.addView(gap, LinearLayout.LayoutParams(adaptiveDp(18), 1))

        val weatherCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(if (isTabletLayout) 28 else 16, if (isTabletLayout) 22 else 12, if (isTabletLayout) 28 else 16, if (isTabletLayout) 22 else 12)
            background = burgundyCard(if (isTabletLayout) 26f else 18f)
        }
        weatherCard.addView(text("ПОГОДА СЕЙЧАС  /  СЫЗРАНЬ", if (isTabletLayout) 13f else 11f, orange, true))
        val weatherMain = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, if (isTabletLayout) 8 else 2, 0, if (isTabletLayout) 6 else 2)
        }
        val weatherIconTile = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(78, 28, 48), 24f)
            elevation = 3f
        }
        weatherIcon = GlyphView("cloud", Color.WHITE, 52f)
        weatherIconTile.addView(weatherIcon, LinearLayout.LayoutParams(if (isTabletLayout) adaptiveDp(66) else 48, if (isTabletLayout) adaptiveDp(66) else 48))
        weatherMain.addView(weatherIconTile, LinearLayout.LayoutParams(if (isTabletLayout) adaptiveDp(88) else 60, if (isTabletLayout) adaptiveDp(88) else 60))
        weatherTemp = text("--°", if (isTabletLayout) 66f else 46f, Color.WHITE, true)
        weatherTemp.setPadding(16, 0, 0, 0)
        weatherMain.addView(weatherTemp)
        weatherCard.addView(weatherMain)
        weatherDesc = text("Получаем прогноз…", if (isTabletLayout) 20f else 16f, Color.WHITE, true)
        weatherExtra = text("Влажность --%   ·   Ветер -- м/с", if (isTabletLayout) 15f else 12f, muted)
        moonInfo = text("ЛУНА  ·  --", 12f, Color.rgb(246, 190, 205), true).apply {
            setPadding(if (isTabletLayout) 14 else 8, if (isTabletLayout) 9 else 4, if (isTabletLayout) 14 else 8, if (isTabletLayout) 9 else 4)
            background = rounded(Color.rgb(73, 28, 48), 18f)
        }
        weatherCard.addView(weatherDesc)
        weatherCard.addView(weatherExtra)
        val moonGap = View(this)
        weatherCard.addView(moonGap, LinearLayout.LayoutParams(1, if (isTabletLayout) 9 else 3))
        weatherCard.addView(moonInfo, LinearLayout.LayoutParams(-2, -2))
        weatherCard.isClickable = true
        weatherCard.isFocusable = true
        weatherCard.setOnClickListener { showWeatherScreen() }
        top.addView(weatherCard, LinearLayout.LayoutParams(0, -1, 1f))

        root.addView(top, LinearLayout.LayoutParams(-1, 0, if (isTabletLayout) 0.92f else 0.78f))

        // Нижняя половина: музыкальный центр занимает всю ширину.
        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(if (isTabletLayout) 30 else 14, if (isTabletLayout) 26 else 10, if (isTabletLayout) 30 else 14, if (isTabletLayout) 26 else 10)
            background = burgundyCard(if (isTabletLayout) 28f else 18f)
        }
        cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(Color.rgb(42, 23, 34))
                cornerRadius = 22f
                setStroke(2, Color.rgb(139, 58, 83))
            }
            clipToOutline = true
            elevation = 5f
        }
        playerCard.addView(cover, LinearLayout.LayoutParams(if (isTabletLayout) adaptiveDp(250) else 132, if (isTabletLayout) adaptiveDp(250) else 132))

        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(if (isTabletLayout) adaptiveDp(32) else 12, 0, if (isTabletLayout) adaptiveDp(8) else 4, 0)
        }
        details.addView(text("СЕЙЧАС ИГРАЕТ", if (isTabletLayout) 13f else 11f, orange, true))
        track = text("Ожидание музыки", if (isTabletLayout) 32f else 22f, Color.WHITE, true)
        artist = text("Запусти Яндекс Музыку", if (isTabletLayout) 21f else 15f, muted)
        playbackLabel = text("●  НЕ ПОДКЛЮЧЕНО", if (isTabletLayout) 13f else 10f, muted, true)
        details.addView(track)
        details.addView(artist)
        val statusGap = View(this)
        details.addView(statusGap, LinearLayout.LayoutParams(1, if (isTabletLayout) 12 else 3))
        details.addView(playbackLabel)

        val progressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, if (isTabletLayout) 18 else 4, 0, 0)
        }
        elapsed = text("00:00", if (isTabletLayout) 13f else 10f, muted)
        remaining = text("00:00", if (isTabletLayout) 13f else 10f, muted)
        progress = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(238, 111, 145))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 190, 207))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(105, 65, 80))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { isSeeking = true }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser && durationMs > 0) {
                        elapsed.text = formatTime(durationMs * value / 1000)
                    }
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val c = controller
                    if (c != null && durationMs > 0) {
                        c.transportControls.seekTo(durationMs * (seekBar?.progress ?: 0) / 1000)
                    }
                    isSeeking = false
                }
            })
        }
        progressRow.addView(elapsed)
        progressRow.addView(progress, LinearLayout.LayoutParams(0, -2, 1f).apply {
            setMargins(if (isTabletLayout) 14 else 5, 0, if (isTabletLayout) 14 else 5, 0)
        })
        progressRow.addView(remaining)
        details.addView(progressRow)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, if (isTabletLayout) 17 else 5, 0, 0)
        }
        controls.addView(control("previous", false) { command { it.skipToPrevious() } })
        playPause = control("pause", true) { togglePlayback() }
        controls.addView(playPause)
        controls.addView(control("next", false) { command { it.skipToNext() } })
        details.addView(controls)

        playerCard.addView(details, LinearLayout.LayoutParams(0, -1, 1f))

        // Full-surface volume control: the panel itself fills from bottom to top.
        volumeFill = VolumeFillView()
        playerCard.addView(volumeFill, LinearLayout.LayoutParams(if (isTabletLayout) 88 else 52, -1).apply {
            leftMargin = if (isTabletLayout) 16 else 6
        })
        syncVolumeSlider()

        root.addView(playerCard, LinearLayout.LayoutParams(-1, 0, if (isTabletLayout) 1.08f else 1.0f).apply {
            topMargin = if (isTabletLayout) 18 else 8
        })
        syncVolumeSlider()

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(2, if (isTabletLayout) 8 else 3, 2, 0)
        }
        val bottomInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        accessHint = text("Медиасессия: проверка…", if (isTabletLayout) 11f else 9f, muted)
        voiceStatus = text("BLACK VOICE: ВЫКЛЮЧЕН", if (isTabletLayout) 11f else 9f, Color.rgb(242, 143, 174), true)
        bottomInfo.addView(accessHint)
        bottomInfo.addView(voiceStatus)
        bottom.addView(bottomInfo, LinearLayout.LayoutParams(0, -2, 1f))
        voiceButton = IconActionView("mic", false) { toggleBlackVoice() }.apply {
            contentDescription = "Управление Black Voice"
        }
        bottom.addView(voiceButton, LinearLayout.LayoutParams(if (isTabletLayout) 58 else 44, if (isTabletLayout) 48 else 36).apply { leftMargin = if (isTabletLayout) 8 else 4 })
        val settings = IconActionView("settings", true) { showSettingsDialog() }.apply {
            contentDescription = "Настройки"
        }
        bottom.addView(settings, LinearLayout.LayoutParams(if (isTabletLayout) 58 else 44, if (isTabletLayout) 48 else 36).apply { leftMargin = if (isTabletLayout) 8 else 4 })
        root.addView(bottom)
        val productFooter = text("PEVKO_PROD", if (isTabletLayout) 10f else 8f, muted, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, if (isTabletLayout) 5 else 2, 0, 0)
            letterSpacing = 0.12f
        }
        root.addView(productFooter, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private inner class IconActionView(private val assetName: String, private val settingsStyle: Boolean, private val action: () -> Unit) : View(this@MainActivity) {
        private var svg: SVG? = null
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        init { setOnClickListener { action() }; isClickable = true; isFocusable = true }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                if (settingsStyle) intArrayOf(Color.rgb(42,20,34), Color.rgb(76,30,53)) else intArrayOf(Color.rgb(116,35,67), Color.rgb(221,75,143)))
            bg.cornerRadius = 18f
            bg.setStroke(2, Color.rgb(225,105,169))
            bg.setBounds(0,0,width,height); bg.draw(canvas)
            try {
                if (svg == null) svg = SVG.getFromAsset(assets, "icons/$assetName.svg")
                val size = minOf(width,height) * 0.58f
                val left = (width-size)/2f; val top=(height-size)/2f
                svg?.renderToCanvas(canvas, android.graphics.RectF(left,top,left+size,top+size))
            } catch (e: Exception) { AppLogger.log("UI", "Не удалось отрисовать иконку $assetName", e) }
            if (!settingsStyle && voiceEnabled) {
                paint.color = Color.rgb(255,190,220); paint.strokeWidth=3f
                canvas.drawCircle(width-9f,9f,4f,paint)
            }
        }
    }

    private fun control(icon: String, primary: Boolean = false, action: () -> Unit) = IconControlView(icon, primary, action)

    private inner class GlyphView(
        private var glyph: String,
        private val tint: Int,
        private val nominalSize: Float
    ) : View(this@MainActivity) {
        private var moonPhaseFraction: Double = 0.25
        private var cachedSvgGlyph: String? = null
        private var cachedSvg: SVG? = null

        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint; style = Paint.Style.STROKE; strokeWidth = 3.8f
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tint; style = Paint.Style.FILL }
        private val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(133, 205, 244); style = Paint.Style.FILL }
        private val cloudFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(154, 163, 176); style = Paint.Style.FILL }
        fun setGlyph(value: String, phaseFraction: Double? = null) {
            if (glyph != value) {
                cachedSvgGlyph = null
                cachedSvg = null
            }
            glyph = value
            if (phaseFraction != null) moonPhaseFraction = phaseFraction.coerceIn(0.0, 1.0)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // Static weather illustrations are rendered from the bundled SVG assets.
            // Moon phases remain procedural so the terminator matches the live illumination percentage.
            if (glyph != "speaker" && glyph != "moon" && glyph != "moon_cloud" && !glyph.startsWith("moon_")) {
                try {
                    if (cachedSvgGlyph != glyph || cachedSvg == null) {
                        cachedSvg = SVG.getFromAsset(this@MainActivity.assets, "weather/$glyph.svg")
                        cachedSvgGlyph = glyph
                    }
                    cachedSvg?.renderToCanvas(canvas, android.graphics.RectF(0f, 0f, width.toFloat(), height.toFloat()))
                    return
                } catch (e: Exception) {
                    AppLogger.log("WEATHER", "Не удалось загрузить SVG $glyph", e)
                }
            }
            val scale = minOf(width, height) / 76f
            canvas.save(); canvas.translate(width / 2f, height / 2f); canvas.scale(scale, scale)
            when {
                glyph == "speaker" -> drawSpeaker(canvas)
                glyph == "moon" || glyph.startsWith("moon_") -> drawMoon(canvas, moonPhaseFraction)
                glyph == "sun" -> drawSun(canvas, 0f, -7f, 13f)
                glyph == "mainly_clear" -> { drawSun(canvas, 0f, -8f, 12f); drawSmallCloud(canvas, 12f, 12f) }
                glyph == "partly" -> { drawSun(canvas, 15f, -20f, 11f); drawCloud(canvas) }
                glyph == "moon_mainly_cloud" -> { drawMoon(canvas, moonPhaseFraction, -12f, -17f, 27f); drawSmallCloud(canvas, 13f, 13f) }
                glyph == "moon_cloud" -> { drawMoon(canvas, moonPhaseFraction, -12f, -17f, 27f); drawCloud(canvas) }
                glyph == "cloud" -> drawCloud(canvas)
                glyph == "fog" -> { drawCloud(canvas); for (y in 18..30 step 7) canvas.drawLine(-24f, y.toFloat(), 24f, y.toFloat(), stroke) }
                glyph == "drizzle_light" -> { drawCloud(canvas); drawRain(canvas, 2) }
                glyph == "drizzle" || glyph == "rain" || glyph == "rain_light" -> { drawCloud(canvas); drawRain(canvas, 3) }
                glyph == "rain_moderate" || glyph == "heavy_rain" || glyph == "rain_heavy" -> { drawCloud(canvas); drawRain(canvas, 5) }
                glyph == "freezing_drizzle" || glyph == "freezing_rain" || glyph == "sleet" -> { drawCloud(canvas); drawRain(canvas, 2); drawSnow(canvas, 2) }
                glyph == "snow_light" || glyph == "snow_grains" -> { drawCloud(canvas); drawSnow(canvas, 2) }
                glyph == "snow" || glyph == "snow_moderate" -> { drawCloud(canvas); drawSnow(canvas, 3) }
                glyph == "snow_heavy" || glyph == "heavy_snow" -> { drawCloud(canvas); drawSnow(canvas, 5) }
                glyph == "storm" || glyph == "storm_heavy" -> { drawCloud(canvas); drawLightning(canvas); if (glyph == "storm_heavy") drawRain(canvas, 3) }
                glyph == "storm_hail" || glyph == "storm_hail_heavy" -> { drawCloud(canvas); drawLightning(canvas); drawHail(canvas, if (glyph == "storm_hail_heavy") 5 else 3) }
                glyph == "hail" -> { drawCloud(canvas); for (x in listOf(-13f, 0f, 13f)) canvas.drawCircle(x, 24f, 3.2f, blue) }
                else -> drawCloud(canvas)
            }
            canvas.restore()
        }

        private fun drawSpeaker(c: Canvas) {
            val p = stroke
            val path = Path().apply { moveTo(-22f,-10f); lineTo(-12f,-10f); lineTo(2f,-22f); lineTo(2f,22f); lineTo(-12f,10f); lineTo(-22f,10f); close() }
            c.drawPath(path, p); c.drawArc(0f,-17f,32f,17f,-58f,116f,false,p)
        }
        private fun drawSun(c: Canvas, cx: Float, cy: Float, r: Float) {
            c.drawCircle(cx,cy,r,fill)
            for (a in 0..7) { val rad=Math.toRadians(a*45.0); c.drawLine(cx+(r+7)*kotlin.math.cos(rad).toFloat(),cy+(r+7)*kotlin.math.sin(rad).toFloat(),cx+(r+14)*kotlin.math.cos(rad).toFloat(),cy+(r+14)*kotlin.math.sin(rad).toFloat(),stroke) }
        }
        private fun drawSmallCloud(c: Canvas, cx: Float, cy: Float) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(154, 163, 176); style = Paint.Style.FILL }
            c.drawOval(cx - 16f, cy - 5f, cx + 17f, cy + 10f, p)
            c.drawCircle(cx - 7f, cy - 4f, 9f, p)
            c.drawCircle(cx + 5f, cy - 7f, 11f, p)
            c.drawOval(cx - 17f, cy + 3f, cx + 18f, cy + 12f, p)
            c.drawArc(cx - 18f, cy - 14f, cx + 19f, cy + 14f, 0f, 180f, false, stroke)
        }

        private fun drawCloud(c: Canvas) {
            val path=Path().apply { moveTo(-25f,9f); cubicTo(-34f,7f,-32f,-7f,-21f,-10f); cubicTo(-19f,-27f,4f,-31f,12f,-15f); cubicTo(29f,-18f,34f,1f,22f,10f); close() }
            c.drawPath(path, cloudFill); c.drawPath(path, stroke)
        }
        private fun drawRain(c: Canvas, count: Int) {
            val xs=when(count){2->listOf(-10f,10f);5->listOf(-22f,-11f,0f,11f,22f);else->listOf(-15f,0f,15f)}
            xs.forEach { x -> val p=Path().apply { moveTo(x+3f,16f); cubicTo(x+5f,21f,x+1f,29f,x-2f,28f); cubicTo(x-7f,26f,x-1f,19f,x+3f,16f); close() }; c.drawPath(p,blue); c.drawPath(p,stroke) }
        }
        private fun drawSnow(c: Canvas, count: Int) {
            val xs=when(count){2->listOf(-11f,13f);5->listOf(-22f,-11f,0f,11f,22f);else->listOf(-16f,0f,16f)}
            xs.forEach { x -> c.drawLine(x-4f,20f,x+4f,28f,blue); c.drawLine(x+4f,20f,x-4f,28f,blue); c.drawLine(x,18f,x,30f,blue) }
        }
        private fun drawHail(c: Canvas, count: Int) {
            val positions = if (count >= 5) listOf(-22f to 24f, -11f to 31f, 0f to 22f, 11f to 31f, 22f to 24f) else listOf(-15f to 25f, 0f to 31f, 15f to 25f)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(145, 215, 255); style = Paint.Style.FILL }
            val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 1.8f }
            positions.forEach { (x, y) -> c.drawCircle(x, y, 3.8f, p); c.drawCircle(x, y, 3.8f, edge) }
        }

        private fun drawLightning(c: Canvas) {
            val p=Path().apply { moveTo(5f,14f); lineTo(-8f,29f); lineTo(1f,29f); lineTo(-5f,42f); lineTo(13f,23f); lineTo(4f,23f); close() }
            c.drawPath(p,blue); c.drawPath(p,stroke)
        }
        // Draw the illuminated lunar disk from the actual illumination fraction and waxing/waning direction.
        // The terminator is an ellipse; this avoids the old overlapping-circle approximation.
        private fun drawMoon(c: Canvas, phaseFraction: Double, cx: Float = 0f, cy: Float = 0f, radius: Float = 25f) {
            val phase = ((phaseFraction % 1.0) + 1.0) % 1.0
            val angle = 2.0 * Math.PI * phase
            val terminator = kotlin.math.cos(angle).toFloat()
            val waxing = phase < 0.5
            val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(65, 73, 86); style = Paint.Style.FILL }
            val light = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(239, 242, 248); style = Paint.Style.FILL }
            val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(248, 249, 252); style = Paint.Style.STROKE; strokeWidth = 2.8f }
            val bounds = android.graphics.RectF(cx-radius, cy-radius, cx+radius, cy+radius)
            c.drawCircle(cx, cy, radius, dark)

            if (phase < 0.002 || phase > 0.998) {
                // New moon: leave the disk dark.
            } else if (phase in 0.498..0.502) {
                c.drawCircle(cx, cy, radius, light)
            } else {
                val path = Path()
                path.moveTo(cx, cy - radius)
                if (waxing) {
                    path.arcTo(bounds, -90f, 180f, false) // bright outer right half
                    path.cubicTo(
                        cx + terminator * radius, cy + radius * 0.55f,
                        cx + terminator * radius, cy - radius * 0.55f,
                        cx, cy - radius
                    )
                } else {
                    path.arcTo(bounds, -90f, -180f, false) // bright outer left half
                    path.cubicTo(
                        cx - terminator * radius, cy + radius * 0.55f,
                        cx - terminator * radius, cy - radius * 0.55f,
                        cx, cy - radius
                    )
                }
                path.close()
                c.drawPath(path, light)
            }
            // Subtle lunar maria keep the icon close to the supplied monochrome moon set.
            val maria = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(38, 70, 78, 91); style = Paint.Style.FILL }
            c.drawCircle(cx - radius * 0.30f, cy - radius * 0.20f, radius * 0.17f, maria)
            c.drawCircle(cx + radius * 0.22f, cy + radius * 0.28f, radius * 0.12f, maria)
            c.drawCircle(cx + radius * 0.30f, cy - radius * 0.36f, radius * 0.08f, maria)
            c.drawCircle(cx, cy, radius, outline)
        }

    }

    private inner class IconControlView(icon: String, private val primary: Boolean, private val action: () -> Unit) : View(this@MainActivity) {
        private var iconName = icon
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = if (primary) 3.2f else 2.8f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        init {
            background = if (primary) GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(207, 66, 119), Color.rgb(126, 39, 79))).apply {
                cornerRadius = 24f; setStroke(1, Color.rgb(239, 142, 177))
            } else GradientDrawable().apply {
                setColor(Color.rgb(57, 26, 42)); cornerRadius = 22f; setStroke(1, Color.rgb(112, 61, 82))
            }
            isClickable = true; isFocusable = true; elevation = if (primary) 5f else 2f
            contentDescription = when (icon) { "previous" -> "Предыдущий трек"; "next" -> "Следующий трек"; else -> "Воспроизведение" }
            setOnClickListener {
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(75).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                }.start()
                action()
            }
            layoutParams = LinearLayout.LayoutParams(if (primary) 82 else 68, if (primary) 68 else 60).apply { setMargins(7, 0, 7, 0) }
        }
        fun setIcon(value: String) { iconName = value; contentDescription = if (value == "pause") "Пауза" else "Воспроизведение"; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); canvas.save(); canvas.translate(width / 2f, height / 2f)
            val scale = if (primary) 1f else 0.88f; canvas.scale(scale, scale)
            paint.color = if (primary) Color.WHITE else Color.rgb(244, 218, 229)
            val path = Path()
            when (iconName) {
                "previous" -> { canvas.drawLine(-13f, -13f, -13f, 13f, paint); path.moveTo(11f,-14f); path.lineTo(-5f,0f); path.lineTo(11f,14f); canvas.drawPath(path,paint) }
                "next" -> { canvas.drawLine(13f, -13f, 13f, 13f, paint); path.moveTo(-11f,-14f); path.lineTo(5f,0f); path.lineTo(-11f,14f); canvas.drawPath(path,paint) }
                "pause" -> { paint.style=Paint.Style.FILL; canvas.drawRoundRect(-9f,-14f,-3f,14f,2f,2f,paint); canvas.drawRoundRect(3f,-14f,9f,14f,2f,2f,paint) }
                else -> { paint.style=Paint.Style.FILL; path.moveTo(-7f,-15f); path.lineTo(14f,0f); path.lineTo(-7f,15f); path.close(); canvas.drawPath(path,paint) }
            }
            paint.style = Paint.Style.STROKE; canvas.restore()
        }
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale("ru")).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now)
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
    }

    private fun syncVolumeSlider() {
        if (!::volumeFill.isInitialized || volumeFill.isTrackingTouch) return
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            volumeFill.setVolumePercent(current * 100f / max)
        } catch (_: Exception) { }
    }

    /**
     * The complete rounded panel is the volume control. Touching anywhere on it
     * changes STREAM_MUSIC volume; the colored area grows upward from the bottom.
     */
    private inner class VolumeFillView : View(this@MainActivity) {
        private val density = resources.displayMetrics.density
        private var volumePercent = 0f
        var isTrackingTouch = false
            private set

        private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(53, 18, 37)
            style = Paint.Style.FILL
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(207, 91, 128)
            style = Paint.Style.STROKE
            strokeWidth = 1.2f * density
        }
        private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 2.2f * density
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val percentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = 13f * density
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        private val bounds = android.graphics.RectF()
        private val clipPath = Path()

        init {
            elevation = 4f * density
            isClickable = true
            contentDescription = "Регулятор громкости"
        }

        fun setVolumePercent(value: Float) {
            volumePercent = value.coerceIn(0f, 100f)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val inset = 1f * density
            bounds.set(inset, inset, width - inset, height - inset)
            val radius = 30f * density
            canvas.drawRoundRect(bounds, radius, radius, panelPaint)

            clipPath.reset()
            clipPath.addRoundRect(bounds, radius, radius, Path.Direction.CW)
            val save = canvas.save()
            canvas.clipPath(clipPath)
            val fillTop = bounds.bottom - bounds.height() * (volumePercent / 100f)
            fillPaint.shader = android.graphics.LinearGradient(
                0f, bounds.bottom, 0f, fillTop.coerceAtMost(bounds.bottom),
                intArrayOf(Color.rgb(177, 39, 83), Color.rgb(244, 91, 139), Color.rgb(255, 160, 190)),
                null, android.graphics.Shader.TileMode.CLAMP
            )
            if (volumePercent > 0f) canvas.drawRect(bounds.left, fillTop, bounds.right, bounds.bottom, fillPaint)
            fillPaint.shader = null
            canvas.restoreToCount(save)
            canvas.drawRoundRect(bounds, radius, radius, borderPaint)

            // Speaker symbol and level remain legible over both filled and empty areas.
            val cx = width / 2f
            val iconCy = 35f * density
            val speaker = Path().apply {
                moveTo(cx - 13f * density, iconCy - 6f * density)
                lineTo(cx - 6f * density, iconCy - 6f * density)
                lineTo(cx + 2f * density, iconCy - 13f * density)
                lineTo(cx + 2f * density, iconCy + 13f * density)
                lineTo(cx - 6f * density, iconCy + 6f * density)
                lineTo(cx - 13f * density, iconCy + 6f * density)
                close()
            }
            canvas.drawPath(speaker, iconPaint)
            val wave = Path().apply {
                moveTo(cx + 7f * density, iconCy - 7f * density)
                quadTo(cx + 17f * density, iconCy, cx + 7f * density, iconCy + 7f * density)
            }
            canvas.drawPath(wave, iconPaint)
            canvas.drawText("${volumePercent.toInt()}%", cx, iconCy + 36f * density, percentPaint)
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN,
                android.view.MotionEvent.ACTION_MOVE -> {
                    isTrackingTouch = true
                    val percent = ((height - event.y) / height.coerceAtLeast(1) * 100f).coerceIn(0f, 100f)
                    setVolumePercent(percent)
                    val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    val target = (max * percent / 100f).toInt().coerceIn(0, max)
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                    return true
                }
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> {
                    isTrackingTouch = false
                    syncVolumeSlider()
                    performClick()
                    return true
                }
            }
            return true
        }

        override fun performClick(): Boolean {
            super.performClick()
            return true
        }
    }

    private fun refreshMedia() {
        if (!isMediaAccessGranted()) {
            controller = null
            if (lastMediaSignature != "permission_missing") {
                AppLogger.log("PERMISSIONS", "Нет специального доступа к медиасессиям; опрос приостановлен")
                lastMediaSignature = "permission_missing"
            }
            track.text = "Ожидание доступа"
            artist.text = "Разреши Black Edition доступ к уведомлениям"
            playbackLabel.text = "●  НЕТ ДОСТУПА К МЕДИАСЕССИЯМ"
            accessHint.text = "Открой настройки и включи Black Edition"
            cover.setImageDrawable(null)
            durationMs = 0
            progress.progress = 0
            playPause.setIcon("play")
            return
        }
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(this, MediaAccessService::class.java))
            val active = sessions.firstOrNull { it.packageName.contains("yandex", true) }
            controller = active
            if (active == null) {
                if (lastMediaSignature != "none") AppLogger.log("MEDIA", "Активная медиасессия Яндекс Музыки не найдена")
                lastMediaSignature = "none"
                track.text = "Ожидание музыки"
                artist.text = "Запусти Яндекс Музыку"
                playbackLabel.text = "●  МЕДИАСЕССИЯ НЕ НАЙДЕНА"
                accessHint.text = "Нет активной медиасессии"
                cover.setImageDrawable(null)
                durationMs = 0
                progress.progress = 0
                playPause.setIcon("play")
                return
            }
            val meta = active.metadata
            track.text = meta?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Без названия"
            artist.text = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "Неизвестный исполнитель"
            val bitmap: Bitmap? = meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            if (bitmap != null) cover.setImageBitmap(bitmap)
            val state = active.playbackState
            val playing = state?.state == PlaybackState.STATE_PLAYING
            val signature = "${active.packageName}|${track.text}|${artist.text}|${state?.state}"
            if (signature != lastMediaSignature) {
                AppLogger.log("MEDIA", "Плеер=${active.packageName}; трек=${track.text}; исполнитель=${artist.text}; состояние=${state?.state}")
                lastMediaSignature = signature
            }
            playbackLabel.text = if (playing) "●  ВОСПРОИЗВОДИТСЯ" else "Ⅱ  ПАУЗА"
            playbackLabel.setTextColor(if (playing) orange else muted)
            playPause.setIcon(if (playing) "pause" else "play")
            durationMs = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            currentPosition = state?.position ?: 0L
            lastPositionAt = System.currentTimeMillis()
            accessHint.text = "Яндекс Музыка подключена  ·  ${active.packageName}"
            updateProgress()
        } catch (e: SecurityException) {
            AppLogger.log("MEDIA", "Нет разрешения на чтение медиасессии", e)
            accessHint.text = "Нет доступа к медиасессии. Проверь разрешение."
        } catch (e: Exception) {
            AppLogger.log("MEDIA", "Ошибка обновления медиасессии", e)
            accessHint.text = "Ошибка медиасессии: ${e.javaClass.simpleName}"
        }
    }

    private fun updateProgress() {
        if (durationMs <= 0) {
            elapsed.text = "00:00"
            remaining.text = "00:00"
            return
        }
        val state = controller?.playbackState
        val playing = state?.state == PlaybackState.STATE_PLAYING
        val pos = if (playing) {
            currentPosition + (System.currentTimeMillis() - lastPositionAt)
        } else currentPosition
        val safe = pos.coerceIn(0, durationMs)
        if (!isSeeking) progress.progress = (safe * 1000 / durationMs).toInt()
        elapsed.text = formatTime(safe)
        remaining.text = formatTime(durationMs)
    }

    private fun togglePlayback() {
        val state = controller?.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING) command { it.pause() }
        else command { it.play() }
    }

    private fun command(action: (MediaController.TransportControls) -> Unit) {
        AppLogger.log("MEDIA", "Отправлена команда управления воспроизведением")
        val c = controller
        if (c == null) {
            accessHint.text = "Сначала запусти Яндекс Музыку"
            return
        }
        try {
            action(c.transportControls)
            handler.postDelayed({ refreshMedia() }, 450)
        } catch (e: Exception) {
            AppLogger.log("MEDIA", "Ошибка команды управления плеером", e)
            accessHint.text = "Команда не выполнена: ${e.javaClass.simpleName}"
        }
    }

    private fun showCalendarScreen() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val wide = isTabletLayout
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(if (wide) 32 else 20, if (wide) 28 else 20, if (wide) 32 else 20, if (wide) 28 else 20)
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBlock.addView(text("BLACK EDITION", 13f, orange, true))
        titleBlock.addView(text("КАЛЕНДАРЬ", if (wide) 34f else 28f, Color.WHITE, true))
        header.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        val closeButton = Button(this).apply {
            text = "ЗАКРЫТЬ"
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(116, 35, 67), 18f)
            setOnClickListener { dialog.dismiss() }
        }
        header.addView(closeButton)
        screen.addView(header)

        val selectedDateText = text("", if (wide) 26f else 22f, Color.WHITE, true).apply {
            setPadding(0, if (wide) 16 else 22, 0, 12)
        }

        val calendar = CalendarView(this).apply {
            setBackgroundColor(bg)
            date = System.currentTimeMillis()
            firstDayOfWeek = java.util.Calendar.MONDAY
            setFocusedMonthDateColor(Color.rgb(239, 78, 111))
            setSelectedWeekBackgroundColor(Color.rgb(80, 25, 45))
            setWeekDayTextAppearance(android.R.style.TextAppearance_Material_Medium)
            setDateTextAppearance(android.R.style.TextAppearance_Material_Medium)
        }

        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            background = burgundyCard(24f)
        }
        details.addView(text("ВЫБРАННАЯ ДАТА", 12f, orange, true))
        val detailDate = text("", if (wide) 30f else 24f, Color.WHITE, true)
        details.addView(detailDate)
        val detailWeekday = text("", 16f, muted)
        details.addView(detailWeekday)

        val todayButton = Button(this).apply {
            text = "СЕГОДНЯ"
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(116, 35, 67), 18f)
        }

        if (wide) {
            val body = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val calendarColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            calendarColumn.addView(selectedDateText)
            calendarColumn.addView(calendar, LinearLayout.LayoutParams(-1, 0, 1f))
            body.addView(calendarColumn, LinearLayout.LayoutParams(0, -1, 1.45f))
            val side = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24, 0, 0, 0)
                gravity = Gravity.CENTER_VERTICAL
            }
            side.addView(details, LinearLayout.LayoutParams(-1, -2))
            side.addView(todayButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })
            body.addView(side, LinearLayout.LayoutParams(0, -1, 1f))
            screen.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            screen.addView(selectedDateText)
            screen.addView(calendar, LinearLayout.LayoutParams(-1, 0, 1f))
            screen.addView(details, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
            screen.addView(todayButton)
        }

        fun updateDate(timestamp: Long) {
            val selected = java.util.Calendar.getInstance().apply { timeInMillis = timestamp }
            val locale = Locale("ru", "RU")
            val dateFormat = SimpleDateFormat("d MMMM yyyy", locale)
            val weekdayFormat = SimpleDateFormat("EEEE", locale)
            selectedDateText.text = dateFormat.format(selected.time).replaceFirstChar { it.uppercase(locale) }
            detailDate.text = dateFormat.format(selected.time).replaceFirstChar { it.uppercase(locale) }
            detailWeekday.text = weekdayFormat.format(selected.time).replaceFirstChar { it.uppercase(locale) }
        }
        updateDate(System.currentTimeMillis())
        calendar.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val selected = java.util.Calendar.getInstance().apply {
                set(year, month, dayOfMonth, 12, 0, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }
            updateDate(selected.timeInMillis)
        }
        todayButton.setOnClickListener {
            calendar.date = System.currentTimeMillis()
            updateDate(System.currentTimeMillis())
        }

        dialog.setContentView(screen)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        dialog.window?.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dialog.window?.decorView?.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        dialog.show()
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun showWeatherScreen() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(if (isTabletLayout) 32 else 20, if (isTabletLayout) 28 else 20, if (isTabletLayout) 32 else 20, if (isTabletLayout) 28 else 20)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBlock.addView(text("BLACK EDITION  /  СЫЗРАНЬ", 13f, orange, true))
        titleBlock.addView(text("ПОГОДА НА 7 ДНЕЙ", if (isTabletLayout) 34f else 27f, Color.WHITE, true))
        header.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        val closeButton = Button(this).apply {
            text = "ЗАКРЫТЬ"
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(116, 35, 67), 18f)
            setOnClickListener { dialog.dismiss() }
        }
        header.addView(closeButton)
        screen.addView(header)

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            background = burgundyCard(24f)
        }
        summary.addView(text("СЕЙЧАС", 12f, orange, true))
        summary.addView(text(weatherTemp.text.toString(), 54f, Color.WHITE, true))
        summary.addView(text(weatherDesc.text.toString(), 20f, Color.WHITE, true))
        summary.addView(text(weatherExtra.text.toString(), 15f, muted))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val daily = forecastDaily
        val dates = daily?.optJSONArray("time")
        val codes = daily?.optJSONArray("weather_code") ?: daily?.optJSONArray("weathercode")
        val maxTemps = daily?.optJSONArray("temperature_2m_max")
        val minTemps = daily?.optJSONArray("temperature_2m_min")
        val precip = daily?.optJSONArray("precipitation_probability_max")
        val winds = daily?.optJSONArray("wind_speed_10m_max")
        if (dates != null && dates.length() > 0) {
            val locale = Locale("ru", "RU")
            for (i in 0 until minOf(7, dates.length())) {
                val dateString = dates.optString(i)
                val parsed = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateString) } catch (_: Exception) { null }
                val dayName = if (i == 0) "Сегодня" else if (i == 1) "Завтра" else parsed?.let {
                    SimpleDateFormat("EEEE, d MMM", locale).format(it).replaceFirstChar { c -> c.uppercase(locale) }
                } ?: dateString
                val code = codes?.optInt(i, -1) ?: -1
                val presentation = weatherPresentation(code, true)
                val high = maxTemps?.optDouble(i, Double.NaN)?.let { if (it.isNaN()) "--" else "${it.toInt()}°" } ?: "--"
                val low = minTemps?.optDouble(i, Double.NaN)?.let { if (it.isNaN()) "--" else "${it.toInt()}°" } ?: "--"
                val probability = precip?.optInt(i, -1) ?: -1
                val wind = winds?.optDouble(i, Double.NaN) ?: Double.NaN
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(18, 13, 18, 13)
                    background = burgundyCard(20f)
                }
                val glyph = GlyphView(presentation.glyph, Color.WHITE, 30f)
                row.addView(glyph, LinearLayout.LayoutParams(54, 54))
                val dayColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                dayColumn.addView(text(dayName, 17f, Color.WHITE, true))
                dayColumn.addView(text(presentation.description, 13f, muted))
                row.addView(dayColumn, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 10 })
                row.addView(text("$high / $low", 19f, Color.WHITE, true))
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
                val detail = "Осадки ${if (probability >= 0) "$probability%" else "--"}  ·  Ветер ${if (wind.isNaN()) "--" else wind.toInt().toString()} м/с"
                list.addView(text(detail, 12f, muted).apply { setPadding(20, 0, 0, 8) })
            }
        } else {
            list.addView(text("Прогноз на неделю пока не загружен. Проверь интернет и обнови приложение.", 16f, muted).apply {
                setPadding(18, 20, 18, 20)
                background = burgundyCard(20f)
            })
        }
        val scroll = android.widget.ScrollView(this).apply { isFillViewport = false }
        scroll.addView(list)
        val forecastColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        forecastColumn.addView(text("ПРОГНОЗ", 13f, orange, true).apply { setPadding(2, 22, 0, 10) })
        forecastColumn.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        if (isTabletLayout) {
            val body = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }
            val currentColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 18, 20, 0)
            }
            currentColumn.addView(summary, LinearLayout.LayoutParams(-1, -2))
            body.addView(currentColumn, LinearLayout.LayoutParams(0, -1, 0.9f))
            body.addView(forecastColumn, LinearLayout.LayoutParams(0, -1, 1.3f))
            screen.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            screen.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })
            screen.addView(forecastColumn, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        dialog.setContentView(screen)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        dialog.window?.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dialog.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        dialog.show()
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun refreshWeather() {
        io.execute {
            try {
                val url = URL("https://yandex-weather-proxy.mr-maloy163.workers.dev/")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                val raw = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val jsonText = raw.trim().let {
                    if (it.startsWith("{")) it
                    else it.substringAfter("(").substringBeforeLast(")").trim()
                }
                val json = JSONObject(jsonText)
                val current = json.optJSONObject("current") ?: json
                val proxyDaily = json.optJSONObject("daily")
                val daily = try {
                    val forecastUrl = URL("https://api.open-meteo.com/v1/forecast?latitude=53.1558&longitude=48.4744&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max&forecast_days=7&timezone=Europe%2FMoscow")
                    val forecastConn = (forecastUrl.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 8000
                        readTimeout = 8000
                        requestMethod = "GET"
                    }
                    val forecastJson = JSONObject(forecastConn.inputStream.bufferedReader().use { it.readText() })
                    forecastConn.disconnect()
                    forecastJson.optJSONObject("daily") ?: proxyDaily
                } catch (forecastError: Exception) {
                    AppLogger.log("WEATHER", "Не удалось получить прогноз на 7 дней из Open-Meteo, используем резервные данные", forecastError)
                    proxyDaily
                }
                val temp = current.optDouble("temperature_2m", Double.NaN)
                    .takeIf { !it.isNaN() } ?: current.optDouble("temperature", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val wind = current.optDouble("wind_speed_10m", Double.NaN)
                val code = current.optInt("weather_code", current.optInt("weathercode", -1))
                val now = System.currentTimeMillis()
                val isDay = resolveDaylight(current, now)
                val phase = moonPhase(now)
                AppLogger.log("WEATHER", "WMO=$code, is_day=$isDay, moon=${phase.name} ${phase.illumination}%, phase=${String.format(Locale.US, "%.3f", phase.fraction)}")
                runOnUiThread {
                    forecastDaily = daily
                    weatherTemp.text = if (temp.isNaN()) "--°" else "${temp.toInt()}°"
                    val presentation = weatherPresentation(code, isDay)
                    weatherDesc.text = presentation.description
                    weatherIcon.setGlyph(presentation.glyph, phase.fraction)
                    weatherExtra.text = "Влажность ${if (humidity >= 0) "$humidity%" else "--"}   ·   Ветер ${if (wind.isNaN()) "--" else wind.toInt().toString()} м/с"
                    moonInfo.text = "ЛУНА  ·  ${phase.name}  ·  ${phase.illumination}%"
                }
            } catch (e: Exception) {
                AppLogger.log("WEATHER", "Не удалось получить текущую погоду", e)
                val now = System.currentTimeMillis()
                val isDay = resolveDaylight(JSONObject(), now)
                val phase = moonPhase(now)
                runOnUiThread {
                    weatherTemp.text = "--°"
                    weatherDesc.text = "Погода временно недоступна"
                    weatherExtra.text = "Проверь подключение к интернету"
                    weatherIcon.setGlyph(if (isDay) "cloud" else "moon", phase.fraction)
                    moonInfo.text = "ЛУНА  ·  ${phase.name}  ·  ${phase.illumination}%"
                }
            }
        }
    }

    private data class MoonPhase(
        val name: String,
        val illumination: Int,
        val fraction: Double
    )

    // Synodic phase estimate anchored to the known 2000-01-06 new moon.
    // Illumination is calculated continuously; the icon uses the same phase fraction.
    private fun moonPhase(nowMs: Long): MoonPhase {
        val synodicMonth = 29.530588853
        val knownNewMoon = 947182440000.0 // 2000-01-06 18:14 UTC
        val days = (nowMs - knownNewMoon) / 86400000.0
        val fraction = (((days % synodicMonth) + synodicMonth) % synodicMonth) / synodicMonth
        val illuminationValue = ((1.0 - kotlin.math.cos(2.0 * Math.PI * fraction)) / 2.0 * 100.0)
        val illumination = illuminationValue.toInt().coerceIn(0, 100)
        val name = when {
            illumination <= 1 -> "Новолуние"
            illumination >= 99 -> "Полнолуние"
            fraction < 0.5 && illumination in 48..52 -> "Первая четверть"
            fraction < 0.5 && illumination < 50 -> "Растущий серп"
            fraction < 0.5 -> "Растущая выпуклая"
            illumination in 48..52 -> "Последняя четверть"
            illumination < 50 -> "Убывающий серп"
            else -> "Убывающая выпуклая"
        }
        return MoonPhase(name, illumination, fraction)
    }

    private data class WeatherPresentation(val description: String, val glyph: String)

    // One source of truth: every WMO code selects both the Russian description and its SVG family.
    private fun weatherPresentation(code: Int, isDay: Boolean): WeatherPresentation = when (code) {
        0 -> WeatherPresentation("Ясно", if (isDay) "sun" else "moon")
        1 -> WeatherPresentation("Преимущественно ясно", if (isDay) "mainly_clear" else "moon_mainly_cloud")
        2 -> WeatherPresentation("Переменная облачность", if (isDay) "partly" else "moon_cloud")
        3 -> WeatherPresentation("Пасмурно", "cloud")
        45 -> WeatherPresentation("Туман", "fog")
        48 -> WeatherPresentation("Переохлаждённый туман", "fog")
        51 -> WeatherPresentation("Слабая морось", "drizzle_light")
        53 -> WeatherPresentation("Умеренная морось", "drizzle")
        55 -> WeatherPresentation("Сильная морось", "rain")
        56 -> WeatherPresentation("Слабая ледяная морось", "freezing_drizzle_light")
        57 -> WeatherPresentation("Сильная ледяная морось", "freezing_drizzle_heavy")
        61 -> WeatherPresentation("Небольшой дождь", "rain_light")
        63 -> WeatherPresentation("Умеренный дождь", "rain_moderate")
        65 -> WeatherPresentation("Сильный дождь", "rain_heavy")
        66 -> WeatherPresentation("Слабый ледяной дождь", "freezing_rain_light")
        67 -> WeatherPresentation("Сильный ледяной дождь", "freezing_rain_heavy")
        71 -> WeatherPresentation("Небольшой снег", "snow_light")
        73 -> WeatherPresentation("Умеренный снегопад", "snow_moderate")
        75 -> WeatherPresentation("Сильный снегопад", "snow_heavy")
        77 -> WeatherPresentation("Снежная крупа", "snow_grains")
        80 -> WeatherPresentation("Небольшой ливень", "rain_shower_light")
        81 -> WeatherPresentation("Умеренный ливень", "rain_shower_moderate")
        82 -> WeatherPresentation("Сильный ливень", "rain_shower_heavy")
        85 -> WeatherPresentation("Небольшой снежный заряд", "snow_shower_light")
        86 -> WeatherPresentation("Сильный снежный заряд", "snow_shower_heavy")
        95 -> WeatherPresentation("Гроза", "storm")
        96 -> WeatherPresentation("Гроза с небольшим градом", "storm_hail")
        97 -> WeatherPresentation("Сильная гроза", "storm_heavy")
        99 -> WeatherPresentation("Гроза с сильным градом", "storm_hail_heavy")
        else -> WeatherPresentation("Погодные условия не определены", "cloud")
    }

    // Open-Meteo is_day follows the local sunrise/sunset and seasonal daylight duration.
    private fun resolveDaylight(current: JSONObject, nowMs: Long): Boolean {
        if (current.has("is_day") && !current.isNull("is_day")) {
            return current.optInt("is_day", 1) == 1
        }
        val sunrise = current.optString("sunrise", "")
        val sunset = current.optString("sunset", "")
        if (sunrise.length >= 16 && sunset.length >= 16) {
            val local = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).format(Date(nowMs))
            val now = local.substring(11, 16)
            return now >= sunrise.substring(11, 16) && now < sunset.substring(11, 16)
        }
        // If the source omits daylight data, avoid fixed seasonal hours: use civil solar elevation approximation.
        val calendar = java.util.Calendar.getInstance()
        val hour = calendar.get(java.util.Calendar.HOUR_OF_DAY) + calendar.get(java.util.Calendar.MINUTE) / 60.0
        val dayOfYear = calendar.get(java.util.Calendar.DAY_OF_YEAR)
        val latitude = 53.1 // Syzran latitude, fallback only; normal path uses provider is_day.
        val declination = Math.toRadians(23.44) * kotlin.math.sin(2.0 * Math.PI * (284 + dayOfYear) / 365.0)
        val hourAngle = Math.toRadians((hour - 12.0) * 15.0)
        val lat = Math.toRadians(latitude)
        val sinElevation = kotlin.math.sin(lat) * kotlin.math.sin(declination) + kotlin.math.cos(lat) * kotlin.math.cos(declination) * kotlin.math.cos(hourAngle)
        return sinElevation > 0.0
    }

    private fun formatTime(ms: Long): String {
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0))
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    companion object {
        @Volatile private var current: MainActivity? = null
        fun requestRefresh() { current?.runOnUiThread { current?.refreshMedia() } }
    }

    override fun onStart() { super.onStart(); current = this }
    override fun onStop() { if (current === this) current = null; super.onStop() }
}
